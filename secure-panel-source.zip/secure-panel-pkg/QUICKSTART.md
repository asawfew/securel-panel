# 🚀 Quick Start Guide (English)

## Prerequisites
- Node.js 18+ (or Bun runtime)
- npm / bun / pnpm

## Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/secure-panel.git
cd secure-panel

# Install dependencies (choose one)
bun install     # recommended
# OR
npm install
# OR
pnpm install

# Setup environment
cp .env.example .env
# Edit .env with your settings (especially SESSION_SECRET for production)

# Initialize database
bun run db:push
# OR: npx prisma db push

# Seed default admin user
bun run scripts/seed.ts
# OR: npx tsx scripts/seed.ts
```

## Running

```bash
# Development
bun run dev
# OR
npm run dev

# Production build
bun run build
bun run start
# OR
npm run build
npm run start
```

Visit http://localhost:3000

**Default login:**
- Username: `admin`
- Password: `Admin@2024`

⚠️ **IMPORTANT:** Change the password and enable 2FA immediately after first login!

## Deploy to Production

### Using PM2 (recommended for VPS)
```bash
npm install -g pm2
npm run build
pm2 start "npm run start" --name secure-panel
pm2 save
pm2 startup  # to enable on boot
```

### Using Docker (optional)
Create a `Dockerfile`:
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### Nginx Reverse Proxy
```nginx
server {
    listen 443 ssl http2;
    server_name panel.yourdomain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Features

- Multi-server VPN management (VLESS, VMess, Trojan, Shadowsocks)
- 2FA authentication (TOTP)
- Audit logging
- IP whitelist
- Multi-admin with roles
- Persian UI (RTL)
- Dark/Light theme

See `download/README.md` for full documentation.
