# راهنمای آپلود روی گیت‌هاب

## مرحله ۱: دانلود و استخراج پروژه

فایل `secure-panel-source.zip` (یا `.tar.gz`) را دانلود و استخراج کنید:

```bash
# استخراج zip
unzip secure-panel-source.zip
cd secure-panel-pkg

# یا استخراج tar.gz
tar -xzf secure-panel-source.tar.gz
cd secure-panel-pkg
```

## مرحله ۲: ایجاد ریپازیتوری گیت‌هاب

۱. به [github.com/new](https://github.com/new) بروید
۲. نام ریپازیتوری: `secure-panel` (یا هر نام دلخواه)
۳. **Private** را انتخاب کنید (چون پروژه پنل VPN است، بهتر است private باشد)
۴. **ایجاد ریپازیتوری** را کلیک کنید

## مرحله ۳: آپلود کد

```bash
# وارد پوشه پروژه شوید
cd secure-panel-pkg

# راه‌اندازی گیت
git init
git add .
git commit -m "Initial commit: SecurePanel - VPN management panel"

# اتصال به ریپازیتوری گیت‌هاب (آدرس را با ریپازیتوری خود جایگزین کنید)
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/secure-panel.git

# آپلود
git push -u origin main
```

اگر برای اولین بار از گیت استفاده می‌کنید:
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

## مرحله ۴: کلون روی سرور و راه‌اندازی

```bash
# روی سرور
git clone https://github.com/YOUR_USERNAME/secure-panel.git
cd secure-panel

# نصب وابستگی‌ها
bun install  # یا npm install

# راه‌اندازی دیتابیس
cp .env.example .env
# .env را ویرایش کنید
bun run db:push
bun run scripts/seed.ts

# اجرا
bun run dev    # توسعه
# یا
bun run build  # تولید
bun run start  # اجرای production
```

## نکات مهم امنیتی

- ⚠️ ریپازیتوری را **Private** کنید (چون شامل کد پنل VPN است)
- ⚠️ هرگز `.env` واقعی را commit نکنید (در `.gitignore` مستثنی شده)
- ⚠️ رمز عبور پیش‌فرض (Admin@2024) را بعد از اولین ورود تغییر دهید
- ⚠️ 2FA را فعال کنید
- ⚠️ برای production، `SESSION_SECRET` در `.env` را با `openssl rand -hex 32` تولید کنید

## ساختار فایل‌های دانلود شده

```
secure-panel-pkg/
├── .env.example          ← قالب متغیرهای محیطی
├── .gitignore            ← تنظیمات گیت
├── README.md             ← راهنمای کامل پروژه
├── QUICKSTART.md         ← راهنمای سریع (انگلیسی)
├── GITHUB.md             ← همین فایل
├── package.json          ← وابستگی‌ها و اسکریپت‌ها
├── prisma/
│   └── schema.prisma     ← ساختار دیتابیس
├── src/                  ← کد منبع (22 API + 11 view)
│   ├── app/
│   │   ├── api/          ← API routes
│   │   ├── layout.tsx
│   │   ├── page.tsx      ← صفحه اصلی
│   │   └── globals.css
│   ├── components/
│   │   ├── auth/         ← فرم ورود
│   │   ├── panel/        ← سایدبار، هدر
│   │   │   └── views/    ← 11 ویوی پنل
│   │   └── ui/           ← کامپوننت‌های shadcn
│   └── lib/
│       ├── crypto.ts     ← هش رمز عبور (scrypt)
│       ├── totp.ts       ← 2FA (RFC 6238)
│       ├── session.ts    ← نشست‌ها
│       ├── audit.ts      ← لاگ امنیتی
│       └── ...
├── scripts/              ← اسکریپت‌های کمکی
│   ├── seed.ts           ← ایجاد ادمین پیش‌فرض
│   ├── reset-password.ts ← بازنشانی رمز
│   └── clear-login-attempts.ts
├── public/               ← فایل‌های استاتیک
└── db/                   ← دیتابیس SQLite (پوشه خالی)
```

## برای به‌روزرسانی آینده

```bash
# تغییرات را بگیرید
git add .
git commit -m "Description of changes"
git push
```
