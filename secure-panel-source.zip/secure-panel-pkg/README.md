# SecurePanel — پنل مدیریت امن VPN

پنل مدیریت VPN پیشرفته و امن، مشابه پنل سنایی (3x-ui) اما با قابلیت‌های بیشتر و امنیت بالاتر.

## ویژگی‌های اصلی

### عملیاتی
- مدیریت چند سرور (Multi-Server)
- پشتیبانی از پروتکل‌های: VLESS, VMess, Trojan, Shadowsocks, SOCKS, HTTP, Dokodemo-door
- مدیریت کاربران با محدودیت حجم و تاریخ انقضا
- چارت ترافیک ۱۴ روز اخیر
- توزیع پروتکل‌ها و آمار سرورها
- کد کانفیگ خودکار برای هر کاربر

### امنیتی (ارتقا نسبت به 3x-ui)
- احراز هویت دومرحله‌ای (2FA/TOTP) با کدهای پشتیبان
- قفل حساب پس از ۵ تلاش ناموفق (۱۵ دقیقه)
- محدودیت نرخ ورود (Rate Limiting) بر اساس IP و کاربر
- لیست سفید IP (IP Whitelist) با پشتیبانی از CIDR
- لاگ امنیتی کامل (Audit Log) از تمام فعالیت‌ها
- مدیریت نشست‌ها (Sessions) با امکان لغو
- رمز عبور با حداقل ۱۲ کاراکتر و بررسی قدرت
- هش رمز با scrypt (بهتر از bcrypt)
- نقش‌های کاربری (SUPER_ADMIN, ADMIN, OPERATOR, AUDITOR)
- Cookie امن (httpOnly, sameSite, secure)
- ردیابی IP و User-Agent در همه درخواست‌ها

### رابط کاربری
- پشتیبانی کامل از فارسی و RTL
- تم تاریک/روشن با رنگ‌بندی امنیتی (emerald/teal)
- طراحی واکنش‌گرا (Responsive)
- فریم‌ورک Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui

## تکنولوژی‌ها

| بخش | تکنولوژی |
|------|-----------|
| Frontend | Next.js 16, React 19, TypeScript 5 |
| UI | Tailwind CSS 4, shadcn/ui, Lucide Icons |
| Backend | Next.js API Routes (Node.js runtime) |
| Database | Prisma ORM + SQLite (قابل تغییر به PostgreSQL/MySQL) |
| Charts | Recharts |
| State | Zustand, TanStack Query |
| Auth | Session-based با httpOnly cookies |
| 2FA | TOTP (RFC 6238) — بدون وابستگی خارجی |

## راه‌اندازی روی سرور

### پیش‌نیازها
- Node.js 18+ یا Bun
- سیستم‌عامل: Ubuntu 22.04+ / Debian 12+ / CentOS 9+
- حداقل ۱ گیگابایت RAM

### نصب

```bash
# کلون کردن پروژه
git clone <your-repo-url> secure-panel
cd secure-panel

# نصب وابستگی‌ها
bun install  # یا npm install

# تنظیم متغیرهای محیطی
cp .env.example .env
# فایل .env را ویرایش کنید:
# - DATABASE_URL: مسیر فایل دیتابیس SQLite
# - یک کلید امن برای session encryption

# اعمال schema دیتابیس
bun run db:push

# ایجاد ادمین پیش‌فرض و داده‌های نمونه
bun run scripts/seed.ts

# build پروژه
bun run build

# اجرای سرور
bun run start
# یا با pm2:
pm2 start "bun run start" --name secure-panel
```

### پیکربندی Reverse Proxy (Nginx)

```nginx
server {
    listen 80;
    server_name panel.yourdomain.com;

    # Redirect to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name panel.yourdomain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "same-origin" always;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

### اطلاعات ورود پیش‌فرض

- نام کاربری: `admin`
- رمز عبور: `Admin@2024`

**مهم:** بلافاصله پس از اولین ورود، رمز عبور را تغییر دهید و 2FA را فعال کنید.

## اتصال به سرور VPN واقعی

این پنل یک سیستم مدیریت مستقل است. برای اتصال به سرور VPN واقعی (Xray/V2Ray):

1. آدرس و اطلاعات API سرور VPN را در بخش «سرورها» اضافه کنید.
2. برای هر سرور، اینباند‌ها (Inbounds) ایجاد کنید.
3. کاربران را در اینباند‌ها اضافه کنید.
4. لینک کانفیگ هر کاربر از طریق API قابل دسترسی است.

برای همکاری کامل با Xray API، می‌توانید در فایل `src/app/api/servers/[id]/route.ts` در متد POST کد واقعی اتصال به API سرور را اضافه کنید (Xray API Documentation).

## ساختار پروژه

```
src/
├── app/
│   ├── api/                    # API routes
│   │   ├── auth/               # login, logout, 2FA, sessions, change-password
│   │   ├── dashboard/          # آمار داشبورد
│   │   ├── inbounds/           # مدیریت اینباند‌ها
│   │   ├── clients/            # مدیریت کاربران
│   │   ├── servers/            # مدیریت سرورها
│   │   ├── admins/             # مدیریت ادمین‌ها
│   │   ├── settings/            # تنظیمات پنل
│   │   └── security/           # audit-logs, ip-whitelist, login-attempts, overview
│   ├── layout.tsx              # RTL + Vazirmatn font + Theme provider
│   ├── page.tsx                # main entry with auth state
│   └── globals.css             # تم تاریک/روشن + RTL
├── components/
│   ├── auth/                   # login form
│   ├── panel/                  # sidebar, header
│   │   └── views/              # 11 ویو: dashboard, inbounds, clients, ...
│   ├── ui/                     # shadcn/ui components
│   └── theme-provider.tsx
├── lib/
│   ├── crypto.ts               # scrypt password hashing
│   ├── totp.ts                 # TOTP/2FA implementation (RFC 6238)
│   ├── session.ts              # session management with cookies
│   ├── audit.ts                # audit log + IP whitelist + rate limit
│   ├── api.ts                  # API helpers (auth wrapper, validate, json)
│   ├── db.ts                   # Prisma client
│   ├── format.ts               # formatBytes, formatDate, timeAgo, etc.
│   ├── store.ts                # Zustand store
│   ├── use-api.ts              # useApi hook + apiFetch helper
│   └── seed.ts                 # seed initial data
└── prisma/
    └── schema.prisma           # Admin, Session, Server, Inbound, Client, TrafficStat,
                                # AuditLog, LoginAttempt, IpWhitelist, Setting
```

## امنیت

### توصیه‌ها پس از deploy

1. **رمز عبور ادمین را تغییر دهید** — به بخش «پروفایل من» بروید
2. **2FA را فعال کنید** — به بخش «نمای امنیتی» بروید
3. **IP خود را به لیست سفید اضافه کنید** — در صورت نیاز به محدود کردن دسترسی
4. **HTTPS فعال کنید** — با Let's Encrypt یا گواهی SSL
5. **فایروال فعال کنید** — فقط پورت‌های 80, 443 و SSH باز باشند
6. ** backups منظم** از فایل دیتابیس SQLite بگیرید

### محدودیت‌های شناخته شده

- دیتابیس SQLite برای محیط production با حجم بالا مناسب نیست — برای مقیاس بالا به PostgreSQL/MySQL مهاجرت کنید
- QR کد نمایش داده شده در هنگام فعال‌سازی 2FA ممکن است با همه authenticator apps کار نکند — در صورت نیاز، کلید مخفی را به‌صورت دستی وارد کنید
- این نسخه connection واقعی به API سرور VPN را شبیه‌سازی می‌کند — برای production باید کد اتصال واقعی به Xray/V2Ray API را اضافه کنید

## لایسنس

MIT
