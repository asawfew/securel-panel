import { db } from '../src/lib/db'
import { hashPassword } from '../src/lib/crypto'

async function main() {
  // Reset password to default (using a 12+ char password)
  const newPassword = 'Admin@2024'
  const newHash = hashPassword(newPassword)
  
  await db.admin.update({
    where: { username: 'admin' },
    data: { 
      passwordHash: newHash,
      failedAttempts: 0,
      lockedUntil: null,
      twoFactorEnabled: false,
      twoFactorSecret: null,
      backupCodes: null,
    },
  })
  console.log(`Password reset to: ${newPassword}`)
  console.log('2FA disabled')
  console.log('Account unlocked')
  
  // Clear all sessions
  await db.session.deleteMany({})
  console.log('All sessions cleared')
  
  process.exit(0)
}
main().catch(e => { console.error(e); process.exit(1) })
