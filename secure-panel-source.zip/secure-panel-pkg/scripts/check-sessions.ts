import { db } from '../src/lib/db'

async function main() {
  const sessions = await db.session.findMany({
    where: { revoked: false },
    include: { admin: { select: { username: true } } },
  })
  console.log(`Active sessions: ${sessions.length}`)
  for (const s of sessions) {
    const expired = s.expiresAt < new Date()
    console.log(`  - Token: ${s.token.slice(0, 12)}... | Admin: ${s.admin.username} | Expires: ${s.expiresAt.toISOString()} | Expired: ${expired} | Last used: ${s.lastUsedAt.toISOString()}`)
  }
  
  const revoked = await db.session.count({ where: { revoked: true } })
  console.log(`\nRevoked sessions: ${revoked}`)
  
  // Clean up old revoked sessions
  const deleted = await db.session.deleteMany({ where: { revoked: true } })
  console.log(`Deleted ${deleted.count} old revoked sessions`)
  
  process.exit(0)
}
main().catch(e => { console.error(e); process.exit(1) })
