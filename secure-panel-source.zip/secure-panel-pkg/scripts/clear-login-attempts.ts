import { db } from '../src/lib/db'

async function main() {
  const deleted = await db.loginAttempt.deleteMany({})
  console.log(`Deleted ${deleted.count} login attempts`)
  
  // Also unlock any locked accounts
  const unlocked = await db.admin.updateMany({
    where: { lockedUntil: { not: null } },
    data: { lockedUntil: null, failedAttempts: 0 },
  })
  console.log(`Unlocked ${unlocked.count} accounts`)
  
  process.exit(0)
}
main().catch(e => { console.error(e); process.exit(1) })
