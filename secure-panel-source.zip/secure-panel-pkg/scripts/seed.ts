import { seedDatabase } from '../src/lib/seed'

async function main() {
  console.log('Seeding database...')
  await seedDatabase()
  console.log('Done.')
  process.exit(0)
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
