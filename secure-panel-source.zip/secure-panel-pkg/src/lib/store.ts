'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ViewKey =
  | 'dashboard'
  | 'inbounds'
  | 'clients'
  | 'servers'
  | 'security'
  | 'audit-logs'
  | 'ip-whitelist'
  | 'sessions'
  | 'admins'
  | 'settings'
  | 'profile'

interface AppState {
  view: ViewKey
  setView: (v: ViewKey) => void
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
  // Admin info from login response
  admin: { id: string; username: string; role: string; twoFactorEnabled: boolean } | null
  setAdmin: (a: AppState['admin']) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      view: 'dashboard',
      setView: (v) => set({ view: v }),
      sidebarOpen: true,
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      admin: null,
      setAdmin: (a) => set({ admin: a }),
    }),
    {
      name: 'secure-panel-store',
      partialize: (s) => ({ view: s.view, admin: s.admin }),
    },
  ),
)
