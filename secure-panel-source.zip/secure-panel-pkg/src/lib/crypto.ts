import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'crypto'

/**
 * Password hashing using scrypt (better than bcrypt for cross-platform deployment).
 * Format: scrypt$<saltHex>$<hashHex>
 */
export function hashPassword(password: string): string {
  const salt = randomBytes(16)
  const hash = scryptSync(password, salt, 64)
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const parts = stored.split('$')
    if (parts.length !== 3 || parts[0] !== 'scrypt') return false
    const salt = Buffer.from(parts[1], 'hex')
    const hash = Buffer.from(parts[2], 'hex')
    const test = scryptSync(password, salt, 64)
    if (hash.length !== test.length) return false
    return timingSafeEqual(hash, test)
  } catch {
    return false
  }
}

/**
 * Password strength check. Returns score 0..5 and reasons.
 */
export interface PasswordStrength {
  score: number
  reasons: string[]
  ok: boolean
}

export function checkPasswordStrength(password: string): PasswordStrength {
  const reasons: string[] = []
  let score = 0
  if (password.length >= 12) score++
  else reasons.push('حداقل ۱۲ کاراکتر')
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++
  else reasons.push('حروف بزرگ و کوچک')
  if (/\d/.test(password)) score++
  else reasons.push('حداقل یک عدد')
  if (/[^A-Za-z0-9]/.test(password)) score++
  else reasons.push('حداقل یک کاراکتر خاص')
  if (password.length >= 16) score++
  return { score, reasons, ok: score >= 4 }
}

/**
 * Session token generator (256-bit).
 */
export function generateToken(): string {
  return randomBytes(32).toString('hex')
}

/**
 * SHA-256 of a string.
 */
export function sha256(input: string): string {
  return createHash('sha256').update(input).digest('hex')
}

/**
 * Constant-time string comparison.
 */
export function safeCompare(a: string, b: string): boolean {
  const ba = Buffer.from(a)
  const bb = Buffer.from(b)
  if (ba.length !== bb.length) return false
  return timingSafeEqual(ba, bb)
}
