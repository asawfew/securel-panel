import { NextResponse } from 'next/server'
import { getAuthenticatedAdmin, getClientIp } from '@/lib/session'
import { checkIpAllowed, auditLog } from '@/lib/audit'
import { db } from '@/lib/db'

/**
 * Wrap an API handler with auth, IP whitelist and audit logging.
 * Returns { admin, request } on success, or a NextResponse on failure.
 */
export async function requireAuth(request: Request): Promise<{ admin: Awaited<ReturnType<typeof getAuthenticatedAdmin>> } | NextResponse> {
  // 1. IP whitelist check
  const ip = getClientIp(request)
  const ipCheck = await checkIpAllowed(ip)
  if (!ipCheck.allowed) {
    return NextResponse.json({ error: ipCheck.reason ?? 'دسترسی غیرمجاز' }, { status: 403 })
  }
  // 2. Auth check
  const admin = await getAuthenticatedAdmin()
  if (!admin) {
    return NextResponse.json({ error: 'احراز هویت نشده', code: 'UNAUTHORIZED' }, { status: 401 })
  }
  return { admin }
}

/**
 * Helper to handle GET/POST etc. with auth wrapper and try/catch.
 */
export function withAuth(
  handler: (req: Request, ctx: { admin: NonNullable<Awaited<ReturnType<typeof getAuthenticatedAdmin>>>; params: Record<string, string> }) => Promise<NextResponse> | NextResponse,
) {
  return async (req: Request, { params }: { params?: Promise<Record<string, string>> } = {}) => {
    try {
      const auth = await requireAuth(req)
      if (auth instanceof NextResponse) return auth
      if (!auth.admin) {
        return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 })
      }
      const resolvedParams = params ? await params : {}
      return await handler(req, { admin: auth.admin, params: resolvedParams })
    } catch (e) {
      console.error('API error:', e)
      const msg = e instanceof Error ? e.message : 'خطای سرور'
      return NextResponse.json({ error: msg }, { status: 500 })
    }
  }
}

/**
 * Validate request body with a Zod-like schema (manual).
 */
export function validate<T extends Record<string, unknown>>(
  body: unknown,
  fields: Record<string, 'string' | 'number' | 'boolean' | 'bigint' | 'object' | 'string?'>,
): { ok: true; data: Record<string, unknown> } | { ok: false; error: string } {
  if (typeof body !== 'object' || body === null) return { ok: false, error: 'بدنه درخواست نامعتبر' }
  const obj = body as Record<string, unknown>
  const out: Record<string, unknown> = {}
  for (const [key, type] of Object.entries(fields)) {
    const optional = type.endsWith('?')
    const baseType = optional ? type.slice(0, -1) : type
    const val = obj[key]
    if (val === undefined || val === null) {
      if (optional) continue
      return { ok: false, error: `فیلد ${key} الزامی است` }
    }
    if (baseType === 'bigint') {
      // Accept number or string for bigint
      if (typeof val === 'number' || typeof val === 'string') {
        out[key] = BigInt(val)
      } else {
        return { ok: false, error: `فیلد ${key} باید عدد باشد` }
      }
    } else if (typeof val !== baseType) {
      // number accepts numeric strings too
      if (baseType === 'number' && typeof val === 'string' && !isNaN(Number(val))) {
        out[key] = Number(val)
      } else {
        return { ok: false, error: `فیلد ${key} باید از نوع ${baseType} باشد` }
      }
    } else {
      out[key] = val
    }
  }
  return { ok: true, data: out }
}

export interface JsonOptions {
  status?: number
}

export function json(data: unknown, opts: JsonOptions = {}): NextResponse {
  return NextResponse.json(data, {
    status: opts.status ?? 200,
    headers: {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'same-origin',
    },
  })
}

/**
 * Convert BigInt fields to strings for JSON serialization.
 */
export function serializeForJson<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj, (_k, v) => (typeof v === 'bigint' ? v.toString() : v))) as T
}

/**
 * Helper to get query params from URL.
 */
export function getQueryParam(req: Request, key: string): string | null {
  const url = new URL(req.url)
  return url.searchParams.get(key)
}

export function getQueryInt(req: Request, key: string, def: number): number {
  const v = getQueryParam(req, key)
  if (!v) return def
  const n = parseInt(v, 10)
  return isNaN(n) ? def : n
}
