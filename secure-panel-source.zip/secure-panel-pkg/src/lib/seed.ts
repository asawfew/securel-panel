import { db } from '@/lib/db'
import { hashPassword } from '@/lib/crypto'

/**
 * Seed initial data:
 * - Default super admin (username: admin, password: Admin@2024)
 * - Default settings
 * - A demo server + inbound + clients so the panel is not empty on first login.
 */
export async function seedDatabase() {
  // 1. Default super admin
  const existingAdmin = await db.admin.findUnique({ where: { username: 'admin' } })
  if (!existingAdmin) {
    const passwordHash = hashPassword('Admin@2024')
    await db.admin.create({
      data: {
        username: 'admin',
        passwordHash,
        role: 'SUPER_ADMIN',
        twoFactorEnabled: false,
      },
    })
    console.log('[seed] Default admin created (admin / Admin@2024)')
  }

  // 2. Default settings
  const settingsDefaults: Record<string, { value: string; category: string }> = {
    'panel.title': { value: 'SecurePanel', category: 'PANEL' },
    'panel.subtitle': { value: 'پنل مدیریت امن VPN', category: 'PANEL' },
    'panel.theme': { value: 'dark', category: 'PANEL' },
    'panel.language': { value: 'fa', category: 'PANEL' },
    'security.ip_whitelist_enabled': { value: 'false', category: 'SECURITY' },
    'security.session_timeout': { value: '28800', category: 'SECURITY' },
    'security.min_password_length': { value: '12', category: 'SECURITY' },
    'security.max_login_attempts': { value: '5', category: 'SECURITY' },
    'security.lock_duration': { value: '900', category: 'SECURITY' },
    'security.rate_limit_per_hour': { value: '10', category: 'SECURITY' },
    'security.audit_log_retention_days': { value: '180', category: 'SECURITY' },
  }
  for (const [key, info] of Object.entries(settingsDefaults)) {
    const exists = await db.setting.findUnique({ where: { key } })
    if (!exists) {
      await db.setting.create({ data: { key, value: info.value, category: info.category } })
    }
  }

  // 3. Demo server + inbound + clients (only if no servers exist yet)
  const serverCount = await db.server.count()
  if (serverCount === 0) {
    const server = await db.server.create({
      data: {
        name: 'سرور اصلی - فرانکفورت',
        address: '185.94.10.20',
        apiHost: '185.94.10.20',
        apiPort: 2053,
        apiUser: 'admin',
        apiPass: '',
        apiPath: '/xui/API/inbounds/list',
        status: 'ONLINE',
        country: 'آلمان',
        flag: 'de',
        cpuUsage: 12.4,
        memUsage: 38.7,
        diskUsage: 21.3,
        netUpload: 4.2,
        netDownload: 12.8,
        uptime: 86400 * 12,
        lastCheckedAt: new Date(),
      },
    })

    // Generate demo daily stats for the last 14 days
    const now = Date.now()
    const day = 24 * 60 * 60 * 1000
    const inbound = await db.inbound.create({
      data: {
        serverId: server.id,
        protocol: 'vless',
        remark: 'Main-VLESS-443',
        port: 443,
        tls: 'reality',
        security: 'reality',
        network: 'tcp',
        settings: JSON.stringify({
          clients: [],
          decryption: 'none',
          fallbacks: [],
        }),
        streamSettings: JSON.stringify({
          network: 'tcp',
          security: 'reality',
          realitySettings: {
            show: false,
            dest: 'www.microsoft.com:443',
            serverNames: ['www.microsoft.com'],
            privateKey: 'some-private-key',
            shortIds: ['abcd1234'],
          },
        }),
        enable: true,
        up: BigInt(0),
        down: BigInt(0),
        total: BigInt(0),
      },
    })

    // Demo clients
    const clients = [
      { clientId: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', email: 'user1@example.com', name: 'کاربر نمونه ۱', totalGB: BigInt(50 * 1024 * 1024 * 1024), expiryTime: BigInt(now + 30 * day), up: BigInt(15 * 1024 * 1024 * 1024), down: BigInt(22 * 1024 * 1024 * 1024) },
      { clientId: 'b2c3d4e5-f6a7-8901-bcde-f12345678901', email: 'user2@example.com', name: 'کاربر نمونه ۲', totalGB: BigInt(100 * 1024 * 1024 * 1024), expiryTime: BigInt(now + 60 * day), up: BigInt(45 * 1024 * 1024 * 1024), down: BigInt(33 * 1024 * 1024 * 1024) },
      { clientId: 'c3d4e5f6-a7b8-9012-cdef-123456789012', email: 'user3@example.com', name: 'کاربر نمونه ۳', totalGB: null, expiryTime: null, up: BigInt(2 * 1024 * 1024 * 1024), down: BigInt(1 * 1024 * 1024 * 1024) },
      { clientId: 'd4e5f6a7-b8c9-0123-defa-234567890123', email: 'user4@example.com', name: 'کاربر منقضی شده', totalGB: BigInt(20 * 1024 * 1024 * 1024), expiryTime: BigInt(now - 5 * day), up: BigInt(18 * 1024 * 1024 * 1024), down: BigInt(19 * 1024 * 1024 * 1024) },
      { clientId: 'e5f6a7b8-c9d0-1234-efab-345678901234', email: 'user5@example.com', name: 'کاربر نمونه ۵', totalGB: BigInt(200 * 1024 * 1024 * 1024), expiryTime: BigInt(now + 90 * day), up: BigInt(110 * 1024 * 1024 * 1024), down: BigInt(75 * 1024 * 1024 * 1024) },
    ]

    for (const c of clients) {
      const created = await db.client.create({
        data: {
          inboundId: inbound.id,
          clientId: c.clientId,
          email: c.email,
          name: c.name,
          totalGB: c.totalGB,
          expiryTime: c.expiryTime,
          up: c.up,
          down: c.down,
          total: c.up + c.down,
          enable: true,
          subId: 'sub_' + Math.random().toString(36).slice(2, 12),
        },
      })

      // Generate daily stats for last 14 days
      const stats = []
      for (let i = 13; i >= 0; i--) {
        const date = new Date(now - i * day)
        date.setHours(0, 0, 0, 0)
        const upDay = BigInt(Math.floor(Math.random() * 2 * 1024 * 1024 * 1024))
        const downDay = BigInt(Math.floor(Math.random() * 4 * 1024 * 1024 * 1024))
        stats.push({
          inboundId: inbound.id,
          clientId: created.id,
          date,
          up: upDay,
          down: downDay,
          total: upDay + downDay,
        })
      }
      await db.trafficStat.createMany({ data: stats })
    }

    // Update inbound totals
    const totals = await db.client.aggregate({
      where: { inboundId: inbound.id },
      _sum: { up: true, down: true, total: true },
    })
    await db.inbound.update({
      where: { id: inbound.id },
      data: {
        up: totals._sum.up ?? BigInt(0),
        down: totals._sum.down ?? BigInt(0),
        total: totals._sum.total ?? BigInt(0),
      },
    })

    console.log('[seed] Demo server, inbound, and clients created')
  }
}
