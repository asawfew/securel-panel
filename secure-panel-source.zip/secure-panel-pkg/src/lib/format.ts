/**
 * Format helpers for the panel.
 */

export function formatBytes(bytes: number | bigint | undefined | null, decimals = 2): string {
  if (bytes === undefined || bytes === null) return '—'
  const b = typeof bytes === 'bigint' ? Number(bytes) : bytes
  if (b === 0) return '0 B'
  if (b < 0) return '—'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
  const i = Math.floor(Math.log(b) / Math.log(k))
  const val = b / Math.pow(k, i)
  return `${val.toFixed(i === 0 ? 0 : decimals)} ${sizes[i]}`
}

export function formatBytesShort(bytes: number | bigint | undefined | null): string {
  if (bytes === undefined || bytes === null) return '—'
  const b = typeof bytes === 'bigint' ? Number(bytes) : bytes
  if (b === 0) return '0'
  if (b < 0) return '—'
  const k = 1024
  const sizes = ['B', 'K', 'M', 'G', 'T', 'P']
  const i = Math.floor(Math.log(b) / Math.log(k))
  const val = b / Math.pow(k, i)
  return `${val.toFixed(i === 0 ? 0 : 1)}${sizes[i]}`
}

export function formatNumber(n: number | undefined | null): string {
  if (n === undefined || n === null) return '—'
  return n.toLocaleString('fa-IR')
}

export function formatDate(d: Date | string | number | undefined | null): string {
  if (!d) return '—'
  const date = typeof d === 'string' || typeof d === 'number' ? new Date(d) : d
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date)
  } catch {
    return date.toLocaleString()
  }
}

export function formatDateShort(d: Date | string | number | undefined | null): string {
  if (!d) return '—'
  const date = typeof d === 'string' || typeof d === 'number' ? new Date(d) : d
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      month: 'short',
      day: 'numeric',
    }).format(date)
  } catch {
    return date.toLocaleDateString()
  }
}

export function timeAgo(d: Date | string | undefined | null): string {
  if (!d) return '—'
  const date = typeof d === 'string' ? new Date(d) : d
  const diff = Date.now() - date.getTime()
  const sec = Math.floor(diff / 1000)
  if (sec < 60) return 'همین حالا'
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min} دقیقه پیش`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `${hr} ساعت پیش`
  const days = Math.floor(hr / 24)
  if (days < 30) return `${days} روز پیش`
  const months = Math.floor(days / 30)
  if (months < 12) return `${months} ماه پیش`
  return `${Math.floor(months / 12)} سال پیش`
}

export function msToExpiry(ms: number | bigint | undefined | null): { expired: boolean; daysLeft: number; label: string } {
  if (!ms) return { expired: false, daysLeft: Infinity, label: 'نامحدود' }
  const n = typeof ms === 'bigint' ? Number(ms) : ms
  const diff = n - Date.now()
  if (diff <= 0) return { expired: true, daysLeft: 0, label: 'منقضی شده' }
  const days = Math.ceil(diff / (24 * 60 * 60 * 1000))
  if (days >= 30) {
    const months = Math.floor(days / 30)
    return { expired: false, daysLeft: days, label: `${months} ماه` }
  }
  return { expired: false, daysLeft: days, label: `${days} روز` }
}

export function percent(used: number, total: number | null | undefined): number {
  if (!total || total === 0) return 0
  return Math.min(100, Math.round((used / total) * 100 * 10) / 10)
}

export function randomUuid(): string {
  // Simple uuid v4 generator
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

export function randomString(len: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let out = ''
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)]
  }
  return out
}

export function randomPassword(len = 16): string {
  const lower = 'abcdefghijklmnopqrstuvwxyz'
  const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const digits = '0123456789'
  const special = '!@#$%^&*()-_=+'
  const all = lower + upper + digits + special
  let out = ''
  out += lower[Math.floor(Math.random() * lower.length)]
  out += upper[Math.floor(Math.random() * upper.length)]
  out += digits[Math.floor(Math.random() * digits.length)]
  out += special[Math.floor(Math.random() * special.length)]
  for (let i = 4; i < len; i++) {
    out += all[Math.floor(Math.random() * all.length)]
  }
  return out.split('').sort(() => Math.random() - 0.5).join('')
}

export function maskString(s: string, visibleStart = 4, visibleEnd = 4): string {
  if (!s) return ''
  if (s.length <= visibleStart + visibleEnd) return s
  return `${s.slice(0, visibleStart)}${'•'.repeat(6)}${s.slice(-visibleEnd)}`
}
