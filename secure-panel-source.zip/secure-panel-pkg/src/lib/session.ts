import { cookies } from 'next/headers'
import { headers } from 'next/headers'
import { db } from '@/lib/db'
import { generateToken } from '@/lib/crypto'

export const SESSION_COOKIE = 'sp_session'
const SESSION_MAX_AGE = 60 * 60 * 8 // 8 hours

export interface AuthenticatedAdmin {
  id: string
  username: string
  role: string
  twoFactorEnabled: boolean
}

/**
 * Determine if the current request was made over HTTPS, considering reverse proxy.
 * Caddy sets X-Forwarded-Proto: https when the original request was HTTPS.
 */
async function isHttps(): Promise<boolean> {
  try {
    const h = await headers()
    const forwardedProto = h.get('x-forwarded-proto')
    if (forwardedProto === 'https') return true
    // Fallback: check the request URL scheme (only works in some setups)
    return false
  } catch {
    return false
  }
}

/**
 * Create a new session for an admin and set the cookie.
 */
export async function createSession(adminId: string, ip?: string, userAgent?: string) {
  const token = generateToken()
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE * 1000)
  const session = await db.session.create({
    data: {
      adminId,
      token,
      ip,
      userAgent,
      expiresAt,
      lastUsedAt: new Date(),
    },
  })
  const cookieStore = await cookies()
  // Determine the actual scheme from the proxy headers.
  // In preview/production behind a TLS-terminating reverse proxy,
  // the browser connects via HTTPS, but internally the app runs HTTP.
  // We MUST set Secure=true in that case so the browser keeps the cookie,
  // because the connection between browser and gateway is HTTPS.
  const https = await isHttps()
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    // Set Secure whenever the user-facing connection is HTTPS.
    // This handles both production AND the preview environment behind Caddy.
    secure: https || process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_MAX_AGE,
  })
  return session
}

/**
 * Get the current authenticated admin from the cookie.
 * Returns null if not authenticated or session expired/revoked.
 */
export async function getAuthenticatedAdmin(): Promise<AuthenticatedAdmin | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE)?.value
    if (!token) return null

    const session = await db.session.findUnique({
      where: { token },
      include: { admin: true },
    })
    if (!session) return null
    if (session.revoked) return null
    if (session.expiresAt < new Date()) return null

    // Update lastUsedAt (throttled - only every 5 min)
    const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000)
    if (session.lastUsedAt < fiveMinAgo) {
      await db.session.update({
        where: { id: session.id },
        data: { lastUsedAt: new Date() },
      })
    }

    return {
      id: session.admin.id,
      username: session.admin.username,
      role: session.admin.role,
      twoFactorEnabled: session.admin.twoFactorEnabled,
    }
  } catch {
    return null
  }
}

/**
 * Destroy current session (logout).
 */
export async function destroySession(): Promise<void> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE)?.value
    if (token) {
      await db.session.updateMany({
        where: { token },
        data: { revoked: true },
      })
    }
    cookieStore.delete(SESSION_COOKIE)
  } catch {
    // ignore
  }
}

/**
 * Get client IP from request, considering proxy headers.
 */
export function getClientIp(request: Request): string {
  const forwarded = request.headers.get('x-forwarded-for')
  if (forwarded) return forwarded.split(',')[0].trim()
  const realIp = request.headers.get('x-real-ip')
  if (realIp) return realIp.trim()
  return 'unknown'
}

/**
 * Get user agent safely.
 */
export function getUserAgent(request: Request): string {
  return request.headers.get('user-agent') ?? 'unknown'
}
