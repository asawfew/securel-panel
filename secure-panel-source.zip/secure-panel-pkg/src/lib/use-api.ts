'use client'

import { useState, useCallback, useEffect } from 'react'

interface ApiState<T> {
  data: T | null
  loading: boolean
  error: string | null
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  body?: unknown
}

/**
 * Hook to call an API endpoint.
 */
export function useApi<T>(endpoint: string | null, options: ApiOptions = {}): ApiState<T> & { refetch: () => void } {
  const [state, setState] = useState<ApiState<T>>({ data: null, loading: !!endpoint, error: null })

  const bodyStr = options.body ? JSON.stringify(options.body) : null
  const fetchData = useCallback(async () => {
    if (!endpoint) {
      setState({ data: null, loading: false, error: null })
      return
    }
    setState((s) => ({ ...s, loading: true, error: null }))
    try {
      const res = await fetch(endpoint, {
        method: options.method ?? 'GET',
        headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
        body: bodyStr ? JSON.stringify(JSON.parse(bodyStr)) : undefined,
        credentials: 'include',
      })
      const json = await res.json().catch(() => ({}))
      if (!res.ok) {
        // On 401, clear local store and reload to show login page
        if (res.status === 401) {
          try {
            localStorage.removeItem('secure-panel-store')
          } catch {}
          if (typeof window !== 'undefined') {
            window.location.reload()
          }
          return
        }
        const err = (json && json.error) || `خطای سرور (${res.status})`
        setState({ data: null, loading: false, error: err })
      } else {
        setState({ data: json as T, loading: false, error: null })
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'خطای شبکه'
      setState({ data: null, loading: false, error: msg })
    }
  }, [endpoint, options.method, bodyStr])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  return { ...state, refetch: fetchData }
}

/**
 * Imperative fetch helper for one-off API calls.
 * On 401, automatically reloads the page to show login screen (unless skipAuthRedirect is true).
 */
export async function apiFetch<T = unknown>(
  endpoint: string,
  options: ApiOptions & { skipAuthRedirect?: boolean } = {},
): Promise<{ ok: true; data: T } | { ok: false; error: string; status?: number; code?: string }> {
  try {
    const res = await fetch(endpoint, {
      method: options.method ?? 'GET',
      headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
      body: options.body ? JSON.stringify(options.body) : undefined,
      credentials: 'include',
    })
    const json = await res.json().catch(() => ({}))
    if (!res.ok) {
      // On 401, the session is expired/revoked - redirect to login
      if (res.status === 401 && !options.skipAuthRedirect) {
        // Clear local store and reload
        try {
          localStorage.removeItem('secure-panel-store')
        } catch {}
        if (typeof window !== 'undefined') {
          window.location.reload()
        }
      }
      return { ok: false, error: (json && json.error) || `خطای سرور (${res.status})`, status: res.status, code: json?.code }
    }
    return { ok: true, data: json as T }
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'خطای شبکه'
    return { ok: false, error: msg }
  }
}
