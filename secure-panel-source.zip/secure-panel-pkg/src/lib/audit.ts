import { db } from '@/lib/db'
import { getClientIp, getUserAgent } from '@/lib/session'

export interface AuditParams {
  adminId?: string
  action: string
  category?: string
  description: string
  targetType?: string
  targetId?: string
  status?: 'SUCCESS' | 'FAILURE' | 'WARNING'
  metadata?: Record<string, unknown>
  request?: Request
}

/**
 * Write a structured audit log entry.
 */
export async function auditLog(params: AuditParams) {
  try {
    const ip = params.request ? getClientIp(params.request) : null
    const userAgent = params.request ? getUserAgent(params.request) : null
    await db.auditLog.create({
      data: {
        adminId: params.adminId ?? null,
        action: params.action,
        category: params.category ?? 'GENERAL',
        description: params.description,
        targetType: params.targetType,
        targetId: params.targetId,
        status: params.status ?? 'SUCCESS',
        metadata: JSON.stringify(params.metadata ?? {}),
        ip,
        userAgent,
      },
    })
  } catch (e) {
    // Audit log failures should never break the request
    console.error('Audit log failed:', e)
  }
}

/**
 * Check whether the IP is allowed to access the panel (if whitelist enabled).
 * Returns { allowed: true } if no restriction or IP matches.
 */
export async function checkIpAllowed(ip: string): Promise<{ allowed: boolean; reason?: string }> {
  const list = await db.ipWhitelist.findMany({ where: { enabled: true } })
  if (list.length === 0) return { allowed: true } // no whitelist = allow all
  for (const entry of list) {
    if (matchIp(ip, entry.ip)) return { allowed: true }
  }
  return { allowed: false, reason: 'آی‌پی شما در لیست مجاز قرار ندارد' }
}

function matchIp(ip: string, pattern: string): boolean {
  if (ip === 'unknown') return false
  // CIDR matching
  if (pattern.includes('/')) {
    return matchCidr(ip, pattern)
  }
  // Single IP
  return ip === pattern
}

function matchCidr(ip: string, cidr: string): boolean {
  try {
    const [base, bitsStr] = cidr.split('/')
    const bits = parseInt(bitsStr, 10)
    const isV6 = ip.includes(':') || base.includes(':')
    if (isV6) {
      // Simplified IPv6 CIDR match - parse groups
      const ipGroups = expandIpv6(ip)
      const baseGroups = expandIpv6(base)
      if (!ipGroups || !baseGroups) return false
      const totalBits = bits
      let remaining = totalBits
      for (let i = 0; i < 8 && remaining > 0; i++) {
        const groupBits = Math.min(16, remaining)
        const mask = (0xffff << (16 - groupBits)) & 0xffff
        if ((ipGroups[i] & mask) !== (baseGroups[i] & mask)) return false
        remaining -= groupBits
      }
      return true
    } else {
      const ipParts = ip.split('.').map(Number)
      const baseParts = base.split('.').map(Number)
      if (ipParts.length !== 4 || baseParts.length !== 4) return false
      const ipNum = (ipParts[0] << 24) | (ipParts[1] << 16) | (ipParts[2] << 8) | ipParts[3]
      const baseNum = (baseParts[0] << 24) | (baseParts[1] << 16) | (baseParts[2] << 8) | baseParts[3]
      const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0
      return (ipNum & mask) === (baseNum & mask)
    }
  } catch {
    return false
  }
}

function expandIpv6(ip: string): number[] | null {
  try {
    // Handle :: shorthand
    const parts = ip.split('::')
    let groups: number[] = []
    if (parts.length === 2) {
      const left = parts[0] ? parts[0].split(':') : []
      const right = parts[1] ? parts[1].split(':') : []
      const missing = 8 - left.length - right.length
      for (const g of left) groups.push(parseInt(g, 16))
      for (let i = 0; i < missing; i++) groups.push(0)
      for (const g of right) groups.push(parseInt(g, 16))
    } else {
      const segs = ip.split(':')
      for (const g of segs) groups.push(parseInt(g, 16))
    }
    if (groups.length !== 8) return null
    return groups
  } catch {
    return null
  }
}

/**
 * Rate-limit login attempts per IP and per username.
 * Returns { allowed, retryAfterSec }.
 */
const MAX_ATTEMPTS_PER_IP = 20   // per hour
const MAX_ATTEMPTS_PER_USER = 10 // per hour
const WINDOW_MS = 60 * 60 * 1000

export async function checkLoginRateLimit(ip: string, username: string): Promise<{ allowed: boolean; retryAfterSec: number }> {
  const since = new Date(Date.now() - WINDOW_MS)
  const [ipCount, userCount] = await Promise.all([
    db.loginAttempt.count({ where: { ip, createdAt: { gt: since } } }),
    db.loginAttempt.count({ where: { username, createdAt: { gt: since } } }),
  ])
  if (ipCount >= MAX_ATTEMPTS_PER_IP) {
    return { allowed: false, retryAfterSec: 3600 }
  }
  if (userCount >= MAX_ATTEMPTS_PER_USER) {
    return { allowed: false, retryAfterSec: 3600 }
  }
  return { allowed: true, retryAfterSec: 0 }
}

export async function recordLoginAttempt(ip: string, username: string, success: boolean, userAgent?: string) {
  try {
    await db.loginAttempt.create({
      data: { ip, username, success, userAgent },
    })
    // Keep only recent records (clean up older than 24h)
    await db.loginAttempt.deleteMany({
      where: { createdAt: { lt: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
    })
  } catch {
    // ignore
  }
}

/**
 * Check if an admin account is locked (too many failed attempts).
 */
export async function checkAccountLock(adminId: string): Promise<{ locked: boolean; unlockIn?: number }> {
  const admin = await db.admin.findUnique({ where: { id: adminId } })
  if (!admin) return { locked: false }
  if (admin.lockedUntil && admin.lockedUntil > new Date()) {
    return { locked: true, unlockIn: Math.ceil((admin.lockedUntil.getTime() - Date.now()) / 1000) }
  }
  return { locked: false }
}

const MAX_FAILED = 5
const LOCK_DURATION = 15 * 60 * 1000 // 15 minutes

export async function recordFailedLogin(adminId: string) {
  const admin = await db.admin.findUnique({ where: { id: adminId } })
  if (!admin) return
  const attempts = admin.failedAttempts + 1
  if (attempts >= MAX_FAILED) {
    await db.admin.update({
      where: { id: adminId },
      data: {
        failedAttempts: 0,
        lockedUntil: new Date(Date.now() + LOCK_DURATION),
      },
    })
  } else {
    await db.admin.update({
      where: { id: adminId },
      data: { failedAttempts: attempts },
    })
  }
}

export async function recordSuccessfulLogin(adminId: string, ip: string) {
  await db.admin.update({
    where: { id: adminId },
    data: {
      failedAttempts: 0,
      lockedUntil: null,
      lastLoginAt: new Date(),
      lastLoginIp: ip,
    },
  })
}
