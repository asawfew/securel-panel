import { createHash, randomBytes, timingSafeEqual, createHmac } from 'crypto'

/**
 * TOTP (RFC 6238) implementation for 2FA.
 * No external deps - uses Node crypto.
 */

const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'

export function base32Encode(buffer: Buffer): string {
  let result = ''
  let bits = 0
  let value = 0
  for (const byte of buffer) {
    value = (value << 8) | byte
    bits += 8
    while (bits >= 5) {
      result += BASE32_CHARS[(value >>> (bits - 5)) & 31]
      bits -= 5
    }
  }
  if (bits > 0) {
    result += BASE32_CHARS[(value << (5 - bits)) & 31]
  }
  return result
}

export function base32Decode(encoded: string): Buffer {
  const clean = encoded.replace(/=+$/, '').toUpperCase()
  let bits = 0
  let value = 0
  const bytes: number[] = []
  for (const c of clean) {
    const idx = BASE32_CHARS.indexOf(c)
    if (idx === -1) continue
    value = (value << 5) | idx
    bits += 5
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff)
      bits -= 8
    }
  }
  return Buffer.from(bytes)
}

/**
 * Generate a new TOTP secret (20 bytes / 160 bits as recommended).
 */
export function generateTotpSecret(): string {
  return base32Encode(randomBytes(20))
}

/**
 * Generate otpauth:// URI for QR codes.
 */
export function buildTotpUri(secret: string, account: string, issuer = 'SecurePanel'): string {
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`
}

/**
 * Compute TOTP code for a given counter.
 */
function totpCode(secret: string, counter: number, digits = 6): string {
  const key = base32Decode(secret)
  const buf = Buffer.alloc(8)
  // Write counter as 64-bit big-endian
  buf.writeBigUInt64BE(BigInt(counter))
  const hmac = createHmac('sha1', key).update(buf).digest()
  const offset = hmac[hmac.length - 1] & 0xf
  const binary = ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff)
  return (binary % 10 ** digits).toString().padStart(digits, '0')
}

/**
 * Verify a TOTP token with a +/- window of time steps.
 */
export function verifyTotp(token: string, secret: string, window = 1): boolean {
  if (!/^\d{6}$/.test(token)) return false
  const now = Math.floor(Date.now() / 1000)
  const step = Math.floor(now / 30)
  for (let i = -window; i <= window; i++) {
    const expected = totpCode(secret, step + i)
    if (timingSafeEqual(Buffer.from(token), Buffer.from(expected))) {
      return true
    }
  }
  return false
}

/**
 * Generate 8 backup codes (8 chars each, alnum).
 * Returns plain codes (to show user once) - store hashed.
 */
export function generateBackupCodes(): string[] {
  const codes: string[] = []
  for (let i = 0; i < 8; i++) {
    codes.push(randomBytes(5).toString('hex').toUpperCase().slice(0, 8).replace(/(.{4})/, '$1-').slice(0, 9))
  }
  return codes
}

export function hashBackupCodes(codes: string[]): string {
  return codes.map(c => createHash('sha256').update(c.replace(/-/g, '')).digest('hex')).join(',')
}
