'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ShieldCheck, Loader2, Lock, User, KeyRound, AlertCircle, Eye, EyeOff, Fingerprint } from 'lucide-react'
import { apiFetch } from '@/lib/use-api'
import { useAppStore } from '@/lib/store'
import { useTheme } from 'next-themes'
import { Sun, Moon } from 'lucide-react'

export function LoginForm({ onAuthed }: { onAuthed: () => void }) {
  const [step, setStep] = useState<'credentials' | '2fa'>('credentials')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [totpCode, setTotpCode] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lockCountdown, setLockCountdown] = useState(0)
  const setAdmin = useAppStore((s) => s.setAdmin)
  const { theme, setTheme } = useTheme()

  useEffect(() => {
    if (lockCountdown <= 0) return
    const t = setInterval(() => {
      setLockCountdown((c) => Math.max(0, c - 1))
    }, 1000)
    return () => clearInterval(t)
  }, [lockCountdown])

  async function handleCredentialsSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (lockCountdown > 0) return
    setError(null)
    setLoading(true)
    const res = await apiFetch<{ requiresTwoFactor?: boolean; admin?: unknown; ok?: boolean; unlockIn?: number }>('/api/auth/login', {
      method: 'POST',
      body: { username, password },
    })
    setLoading(false)
    if (!res.ok) {
      setError(res.error)
      if (res.code === 'ACCOUNT_LOCKED' && res.unlockIn) {
        setLockCountdown(Math.ceil(res.unlockIn / 60))
      }
      return
    }
    if (res.data.requiresTwoFactor) {
      setStep('2fa')
      return
    }
    if (res.data.admin) {
      setAdmin(res.data.admin as never)
      onAuthed()
    }
  }

  async function handle2FASubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    const res = await apiFetch<{ admin?: unknown }>('/api/auth/login', {
      method: 'POST',
      body: { username, password, totpCode },
    })
    setLoading(false)
    if (!res.ok) {
      setError(res.error)
      return
    }
    if (res.data.admin) {
      setAdmin(res.data.admin as never)
      onAuthed()
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 login-bg relative overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-30 pointer-events-none" />
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-4 left-4 z-10"
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      >
        {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </Button>

      <Card className="w-full max-w-md relative gradient-border backdrop-blur-sm shadow-2xl">
        <CardHeader className="space-y-3 text-center pb-2">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="h-7 w-7 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">SecurePanel</CardTitle>
          <CardDescription className="text-sm">
            {step === 'credentials'
              ? 'پنل مدیریت امن VPN — لطفاً وارد شوید'
              : 'کد تأیید دومرحله‌ای را وارد کنید'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {step === 'credentials' ? (
            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-xs font-medium">نام کاربری</Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="username"
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pr-9"
                    placeholder="admin"
                    required
                    disabled={loading}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-xs font-medium">رمز عبور</Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pr-9 pl-9"
                    placeholder="••••••••"
                    required
                    disabled={loading}
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPassword((s) => !s)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="flex items-start gap-2 text-destructive text-xs bg-destructive/10 p-2.5 rounded-md border border-destructive/20">
                  <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                  <span className="leading-relaxed">{error}</span>
                </div>
              )}

              {lockCountdown > 0 && (
                <div className="text-xs text-warning bg-warning/10 p-2.5 rounded-md border border-warning/20">
                  حساب شما قفل شده است. {lockCountdown} دقیقه دیگر تلاش کنید.
                </div>
              )}

              <Button
                type="submit"
                className="w-full glow-primary"
                disabled={loading || lockCountdown > 0}
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                    در حال ورود...
                  </>
                ) : (
                  'ورود به پنل'
                )}
              </Button>

              <p className="text-[10px] text-muted-foreground text-center leading-relaxed">
                اطلاعات پیش‌فرض: admin / Admin@2024 — پس از اولین ورود حتماً تغییر دهید
              </p>
            </form>
          ) : (
            <form onSubmit={handle2FASubmit} className="space-y-4">
              <div className="flex flex-col items-center gap-3 py-2">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Fingerprint className="h-7 w-7 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground text-center leading-relaxed">
                  کد ۶ رقمی از اپلیکیشن تأیید هویت خود را وارد کنید
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="totp" className="text-xs font-medium">کد تأیید</Label>
                <div className="relative">
                  <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="totp"
                    type="text"
                    inputMode="numeric"
                    pattern="\d{6}"
                    maxLength={6}
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="pr-9 text-center text-lg tracking-[0.4em] font-mono"
                    placeholder="000000"
                    required
                    disabled={loading}
                    autoFocus
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-start gap-2 text-destructive text-xs bg-destructive/10 p-2.5 rounded-md border border-destructive/20">
                  <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                  <span className="leading-relaxed">{error}</span>
                </div>
              )}

              <Button type="submit" className="w-full glow-primary" disabled={loading || totpCode.length !== 6}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                    در حال تأیید...
                  </>
                ) : (
                  'تأیید و ورود'
                )}
              </Button>

              <Button
                type="button"
                variant="ghost"
                className="w-full"
                onClick={() => {
                  setStep('credentials')
                  setTotpCode('')
                  setError(null)
                }}
              >
                بازگشت
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
