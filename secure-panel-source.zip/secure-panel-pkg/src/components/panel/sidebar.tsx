'use client'

import { useAppStore, type ViewKey } from '@/lib/store'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Inbox,
  Users,
  Server,
  ShieldCheck,
  ScrollText,
  Globe2,
  MonitorSmartphone,
  UserCog,
  Settings,
  UserRound,
  ShieldAlert,
} from 'lucide-react'

interface NavItem {
  key: ViewKey
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: string
  section: 'main' | 'security' | 'system'
  superAdminOnly?: boolean
}

const navItems: NavItem[] = [
  { key: 'dashboard', label: 'داشبورد', icon: LayoutDashboard, section: 'main' },
  { key: 'inbounds', label: 'اینباند‌ها', icon: Inbox, section: 'main' },
  { key: 'clients', label: 'کاربران', icon: Users, section: 'main' },
  { key: 'servers', label: 'سرورها', icon: Server, section: 'main' },
  { key: 'security', label: 'نمای امنیتی', icon: ShieldCheck, section: 'security' },
  { key: 'audit-logs', label: 'لاگ‌های امنیتی', icon: ScrollText, section: 'security' },
  { key: 'ip-whitelist', label: 'لیست سفید IP', icon: Globe2, section: 'security' },
  { key: 'sessions', label: 'نشست‌های فعال', icon: MonitorSmartphone, section: 'security' },
  { key: 'admins', label: 'مدیران', icon: UserCog, section: 'system', superAdminOnly: true },
  { key: 'settings', label: 'تنظیمات', icon: Settings, section: 'system' },
  { key: 'profile', label: 'پروفایل من', icon: UserRound, section: 'system' },
]

const sectionLabels: Record<NavItem['section'], string> = {
  main: 'عملیات',
  security: 'امنیت',
  system: 'سیستم',
}

export function Sidebar() {
  const view = useAppStore((s) => s.view)
  const setView = useAppStore((s) => s.setView)
  const admin = useAppStore((s) => s.admin)
  const isSuperAdmin = admin?.role === 'SUPER_ADMIN'

  const sections: NavItem['section'][] = ['main', 'security', 'system']

  return (
    <aside className="w-64 shrink-0 border-l border-border bg-sidebar flex flex-col h-full">
      {/* Brand */}
      <div className="h-16 flex items-center gap-3 px-5 border-b border-sidebar-border shrink-0">
        <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center">
          <ShieldAlert className="h-5 w-5 text-primary" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="font-bold text-sm">SecurePanel</span>
          <span className="text-[10px] text-muted-foreground">پنل مدیریت امن</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
        {sections.map((section) => {
          const items = navItems.filter((i) => i.section === section && (!i.superAdminOnly || isSuperAdmin))
          if (items.length === 0) return null
          return (
            <div key={section} className="space-y-1">
              <p className="px-3 text-[10px] uppercase tracking-wider text-muted-foreground/70 font-medium mb-2">
                {sectionLabels[section]}
              </p>
              {items.map((item) => {
                const Icon = item.icon
                const active = view === item.key
                return (
                  <button
                    key={item.key}
                    onClick={() => setView(item.key)}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all',
                      'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                      active && 'bg-sidebar-accent text-sidebar-accent-foreground font-medium',
                    )}
                  >
                    <Icon className={cn('h-4 w-4 shrink-0', active ? 'text-primary' : 'text-muted-foreground')} />
                    <span className="flex-1 text-right">{item.label}</span>
                    {item.badge && (
                      <span className="text-[10px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </button>
                )
              })}
            </div>
          )
        })}
      </nav>

      {/* Footer version */}
      <div className="p-4 border-t border-sidebar-border text-center shrink-0">
        <p className="text-[10px] text-muted-foreground">SecurePanel v1.0.0</p>
        <p className="text-[10px] text-muted-foreground/70 mt-0.5">Next.js 16 · Prisma · 2FA</p>
      </div>
    </aside>
  )
}
