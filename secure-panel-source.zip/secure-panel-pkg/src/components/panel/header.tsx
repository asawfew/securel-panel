'use client'

import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useAppStore } from '@/lib/store'
import { useTheme } from 'next-themes'
import { apiFetch } from '@/lib/use-api'
import { toast } from 'sonner'
import {
  Sun, Moon, LogOut, UserRound, ShieldCheck, Settings as SettingsIcon, ChevronDown,
} from 'lucide-react'

interface HeaderProps {
  onLogout: () => void
}

export function Header({ onLogout }: HeaderProps) {
  const admin = useAppStore((s) => s.admin)
  const setView = useAppStore((s) => s.setView)
  const { theme, setTheme } = useTheme()

  const initials = (admin?.username ?? 'A').slice(0, 2).toUpperCase()

  const roleLabels: Record<string, string> = {
    SUPER_ADMIN: 'ادمین ارشد',
    ADMIN: 'ادمین',
    OPERATOR: 'اپراتور',
    AUDITOR: 'حسابرسی',
  }

  async function handleLogout() {
    await apiFetch('/api/auth/logout', { method: 'POST' })
    onLogout()
  }

  return (
    <header className="h-16 border-b border-border bg-card/60 backdrop-blur-xl flex items-center justify-between px-6 shrink-0">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-success pulse-glow" />
          <span className="text-xs text-muted-foreground">سیستم فعال</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Theme toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="h-9 w-9"
          title="تغییر تم"
        >
          {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 gap-2 px-2 hover:bg-accent">
              <Avatar className="h-7 w-7">
                <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col items-start gap-0.5">
                <span className="text-xs font-medium leading-none">{admin?.username}</span>
                <span className="text-[10px] text-muted-foreground leading-none">
                  {roleLabels[admin?.role ?? 'ADMIN']}
                </span>
              </div>
              <ChevronDown className="h-3 w-3 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="flex items-center gap-2">
              <UserRound className="h-4 w-4" />
              <span>حساب کاربری</span>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setView('profile')}>
              <UserRound className="h-4 w-4 ml-2" />
              پروفایل و امنیت
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setView('sessions')}>
              <ShieldCheck className="h-4 w-4 ml-2" />
              نشست‌های فعال
            </DropdownMenuItem>
            {admin?.role === 'SUPER_ADMIN' && (
              <DropdownMenuItem onClick={() => setView('settings')}>
                <SettingsIcon className="h-4 w-4 ml-2" />
                تنظیمات پنل
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={handleLogout}
              className="text-destructive focus:text-destructive"
            >
              <LogOut className="h-4 w-4 ml-2" />
              خروج از حساب
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
