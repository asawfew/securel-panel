'use client'

import { useState } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { formatBytes, formatNumber } from '@/lib/format'
import { toast } from 'sonner'
import {
  Plus, Search, Users, MoreVertical, Pencil, Trash2, ArrowDown, ArrowUp,
  Copy, CheckCircle2, AlertTriangle, Clock, RefreshCw, Eye, EyeOff, QrCode,
} from 'lucide-react'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { QRCode } from '@/components/qr-code'
import { useState as useReactState } from 'react'

interface Client {
  id: string
  clientId: string
  email: string | null
  name: string | null
  totalGB: string | null
  expiryTime: string | null
  up: string
  down: string
  total: string
  enable: boolean
  subId: string | null
  status: string
  usedPercent: number
  daysLeft: number | null
  inbound: {
    id: string
    protocol: string
    remark: string
    port: number
    server: { id: string; name: string; address: string }
  }
}

interface Inbound {
  id: string
  protocol: string
  remark: string
  port: number
  server: { id: string; name: string; address: string }
}

export function ClientsView() {
  const [search, setSearch] = useState('')
  const [filterInbound, setFilterInbound] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<Client | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null)
  const [linkDialog, setLinkDialog] = useState<{ name: string; link: string } | null>(null)
  const [qrDialog, setQrDialog] = useState<{ name: string; link: string } | null>(null)

  const query = new URLSearchParams()
  if (filterInbound) query.set('inboundId', filterInbound)
  if (filterStatus) query.set('status', filterStatus)
  if (search) query.set('q', search)

  const { data, loading, error, refetch } = useApi<{ clients: Client[] }>(`/api/clients?${query.toString()}`)
  const { data: inboundsData } = useApi<{ inbounds: Inbound[] }>('/api/inbounds')
  const [togglingId, setTogglingId] = useState<string | null>(null)

  async function handleToggle(client: Client) {
    setTogglingId(client.id)
    const res = await apiFetch(`/api/clients/${client.id}`, {
      method: 'PATCH',
      body: { enable: !client.enable },
    })
    setTogglingId(null)
    if (res.ok) {
      toast.success(`کاربر ${client.name ?? client.email} ${client.enable ? 'غیرفعال' : 'فعال'} شد`)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleResetTraffic(client: Client) {
    const res = await apiFetch(`/api/clients/${client.id}`, {
      method: 'PATCH',
      body: { resetTraffic: true },
    })
    if (res.ok) {
      toast.success('ترافیک کاربر صفر شد')
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    const res = await apiFetch(`/api/clients/${deleteTarget.id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success(`کاربر ${deleteTarget.name ?? deleteTarget.email} حذف شد`)
      setDeleteTarget(null)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  function copyLink(link: string) {
    navigator.clipboard.writeText(link)
    toast.success('لینک کپی شد')
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            کاربران
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            مدیریت کاربران VPN با محدودیت حجم و تاریخ انقضا
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="glow-primary">
              <Plus className="h-4 w-4 ml-1" />
              افزودن کاربر
            </Button>
          </DialogTrigger>
          <CreateClientDialog inbounds={inboundsData?.inbounds ?? []} onSuccess={(name, link) => {
            setCreateOpen(false)
            refetch()
            if (link) setLinkDialog({ name, link })
          }} />
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="md:col-span-2 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="جستجو بر اساس نام، ایمیل یا شناسه..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-9" />
            </div>
            <Select value={filterInbound || undefined} onValueChange={(v) => setFilterInbound(v === "__all__" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="همه اینباند‌ها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه اینباند‌ها</SelectItem>
                {inboundsData?.inbounds.map((ib) => (
                  <SelectItem key={ib.id} value={ib.id}>{ib.remark} ({ib.protocol})</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus || undefined} onValueChange={(v) => setFilterStatus(v === "__all__" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="همه وضعیت‌ها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="EXPIRED">منقضی</SelectItem>
                <SelectItem value="LIMIT_EXCEEDED">تمام شده</SelectItem>
                <SelectItem value="DISABLED">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data || data.clients.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">کاربری یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">کاربر</TableHead>
                    <TableHead className="text-right">اینباند</TableHead>
                    <TableHead className="text-right">حجم کل</TableHead>
                    <TableHead className="text-right">مصرف</TableHead>
                    <TableHead className="text-right">انقضا</TableHead>
                    <TableHead className="text-right">وضعیت</TableHead>
                    <TableHead className="text-center">فعال</TableHead>
                    <TableHead className="text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.clients.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <div className="flex flex-col gap-0.5">
                          <span className="font-medium text-sm">{c.name ?? c.email ?? 'بدون نام'}</span>
                          {c.email && c.name && (
                            <span className="text-[10px] text-muted-foreground">{c.email}</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <span className="text-xs">{c.inbound.remark}</span>
                          <Badge variant="outline" className="text-[10px] w-fit">{c.inbound.protocol.toUpperCase()}</Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        {c.totalGB ? (
                          <div className="space-y-1 min-w-[100px]">
                            <p className="text-xs font-medium tabular-nums">{formatBytes(Number(c.totalGB))}</p>
                            <Progress value={c.usedPercent} className="h-1.5" />
                            <p className="text-[10px] text-muted-foreground tabular-nums">{c.usedPercent}%</p>
                          </div>
                        ) : (
                          <Badge variant="outline" className="text-[10px] text-success border-success/30">نامحدود</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-0.5 min-w-[110px]">
                          <p className="text-xs font-medium tabular-nums">{formatBytes(Number(c.total))}</p>
                          <div className="text-[10px] tabular-nums flex items-center gap-2">
                            <span className="text-success flex items-center gap-0.5"><ArrowUp className="h-3 w-3" />{formatBytes(Number(c.up))}</span>
                            <span className="text-chart-2 flex items-center gap-0.5"><ArrowDown className="h-3 w-3" />{formatBytes(Number(c.down))}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {c.daysLeft !== null ? (
                          <div className="flex flex-col gap-0.5">
                            <span className="text-xs">{c.daysLeft} روز</span>
                            {c.daysLeft === 0 && (
                              <span className="text-[10px] text-destructive flex items-center gap-1">
                                <AlertTriangle className="h-3 w-3" /> منقضی
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">نامحدود</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={c.status} />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center">
                          <Switch checked={c.enable} disabled={togglingId === c.id} onCheckedChange={() => handleToggle(c)} />
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="h-4 w-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setEditTarget(c)}>
                              <Pencil className="h-4 w-4 ml-2" /> ویرایش
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleResetTraffic(c)}>
                              <RefreshCw className="h-4 w-4 ml-2" /> صفر کردن ترافیک
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setLinkDialog({ name: c.name ?? c.email ?? 'کاربر', link: buildLink(c) })}>
                              <Copy className="h-4 w-4 ml-2" /> کپی لینک کانفیگ
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setQrDialog({ name: c.name ?? c.email ?? 'کاربر', link: buildLink(c) })}>
                              <QrCode className="h-4 w-4 ml-2" /> نمایش QR کد
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteTarget(c)}>
                              <Trash2 className="h-4 w-4 ml-2" /> حذف
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent className="max-w-lg">
          {editTarget && <EditClientDialog client={editTarget} onSuccess={() => { setEditTarget(null); refetch() }} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کاربر</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف کاربر «{deleteTarget?.name ?? deleteTarget?.email}» مطمئن هستید؟ این عملیات غیرقابل بازگشت است.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Config link dialog */}
      <Dialog open={!!linkDialog} onOpenChange={(o) => !o && setLinkDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              کاربر با موفقیت ایجاد شد
            </DialogTitle>
            <DialogDescription>لینک کانفیگ برای {linkDialog?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label>لینک کانفیگ</Label>
            <div className="relative">
              <Input readOnly value={linkDialog?.link ?? ''} className="pr-9 font-mono text-xs" />
              <button
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
                onClick={() => linkDialog && copyLink(linkDialog.link)}
              >
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
            <p className="text-[10px] text-muted-foreground">این لینک را به کاربر بدهید تا در اپلیکیشن VPN خود وارد کند</p>
          </div>
          <DialogFooter>
            <Button onClick={() => setLinkDialog(null)}>بستن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR code dialog */}
      <Dialog open={!!qrDialog} onOpenChange={(o) => !o && setQrDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-4 w-4 text-primary" />
              QR کد کانفیگ
            </DialogTitle>
            <DialogDescription>برای {qrDialog?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2 flex flex-col items-center">
            <div className="p-3 bg-white rounded-lg">
              <QRCode text={qrDialog?.link ?? ''} size={220} />
            </div>
            <div className="w-full">
              <Label className="text-xs">لینک کانفیگ</Label>
              <div className="relative mt-1">
                <Input readOnly value={qrDialog?.link ?? ''} className="pr-9 font-mono text-xs" />
                <button
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
                  onClick={() => qrDialog && copyLink(qrDialog.link)}
                >
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
            <p className="text-[10px] text-muted-foreground text-center">
              این QR کد را با اپلیکیشن VPN خود (v2rayNG، Streisand و...) اسکن کنید
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setQrDialog(null)}>بستن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, { label: string; cls: string }> = {
    ACTIVE: { label: 'فعال', cls: 'text-success border-success/30 bg-success/5' },
    EXPIRED: { label: 'منقضی', cls: 'text-destructive border-destructive/30 bg-destructive/5' },
    LIMIT_EXCEEDED: { label: 'تمام شده', cls: 'text-warning border-warning/30 bg-warning/5' },
    DISABLED: { label: 'غیرفعال', cls: 'text-muted-foreground border-muted-foreground/30' },
  }
  const info = labels[status] ?? { label: status, cls: '' }
  return <Badge variant="outline" className={`text-[10px] ${info.cls}`}>{info.label}</Badge>
}

function buildLink(c: Client): string {
  const addr = c.inbound.server.address
  const port = c.inbound.port
  const name = encodeURIComponent(c.name ?? c.email ?? 'client')
  switch (c.inbound.protocol) {
    case 'vless':
      return `vless://${c.clientId}@${addr}:${port}?type=tcp&security=reality&sni=www.microsoft.com&fp=chrome#${name}`
    case 'vmess':
      return `vmess://${btoa(JSON.stringify({ v: '2', ps: c.name ?? 'client', add: addr, port: String(port), id: c.clientId, aid: '0', scy: 'auto', net: 'tcp', type: 'none', host: '', path: '', tls: '' }))}`
    case 'trojan':
      return `trojan://${c.clientId}@${addr}:${port}?security=tls&sni=${addr}#${name}`
    case 'shadowsocks':
      return `ss://${btoa(`aes-256-gcm:${c.clientId}`)}@${addr}:${port}#${name}`
    default:
      return ''
  }
}

function CreateClientDialog({ inbounds, onSuccess }: { inbounds: Inbound[]; onSuccess: (name: string, link: string) => void }) {
  const [form, setForm] = useState({
    inboundId: '',
    name: '',
    email: '',
    totalGB: 0,
    expiryDays: 30,
    enable: true,
    resetCycle: 0,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    if (!form.inboundId) return setError('انتخاب اینباند الزامی است')
    setLoading(true)
    setError(null)
    const res = await apiFetch<{ ok: boolean; link: string; client: { name: string | null; email: string | null } }>('/api/clients', {
      method: 'POST',
      body: form,
    })
    setLoading(false)
    if (res.ok) {
      toast.success('کاربر با موفقیت ایجاد شد')
      const c = res.data.client
      onSuccess(c.name ?? c.email ?? 'کاربر', res.data.link ?? '')
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Plus className="h-4 w-4 text-primary" /> افزودن کاربر جدید</DialogTitle>
        <DialogDescription>یک کاربر جدید روی اینباند انتخاب شده ایجاد کنید</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="space-y-2">
          <Label>اینباند</Label>
          <Select value={form.inboundId} onValueChange={(v) => setForm({ ...form, inboundId: v })}>
            <SelectTrigger><SelectValue placeholder="انتخاب اینباند..." /></SelectTrigger>
            <SelectContent>
              {inbounds.map((ib) => (
                <SelectItem key={ib.id} value={ib.id}>
                  {ib.remark} — {ib.protocol.toUpperCase()}:{ib.port} ({ib.server.name})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>نام (اختیاری)</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثلاً علی احمدی" />
          </div>
          <div className="space-y-2">
            <Label>ایمیل / شناسه (اختیاری)</Label>
            <Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="user@example.com" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>سهمیه حجم (GB)</Label>
            <Input type="number" min={0} value={form.totalGB} onChange={(e) => setForm({ ...form, totalGB: parseInt(e.target.value, 10) || 0 })} placeholder="0 = نامحدود" />
            <p className="text-[10px] text-muted-foreground">۰ برای نامحدود</p>
          </div>
          <div className="space-y-2">
            <Label>مدت اعتبار (روز)</Label>
            <Input type="number" min={0} value={form.expiryDays} onChange={(e) => setForm({ ...form, expiryDays: parseInt(e.target.value, 10) || 0 })} placeholder="0 = همیشگی" />
            <p className="text-[10px] text-muted-foreground">۰ برای همیشگی</p>
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md border border-destructive/20">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ایجاد...' : 'ایجاد کاربر'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}

function EditClientDialog({ client, onSuccess }: { client: Client; onSuccess: () => void }) {
  const [form, setForm] = useState({
    name: client.name ?? '',
    email: client.email ?? '',
    totalGB: client.totalGB ? Math.ceil(Number(client.totalGB) / (1024 * 1024 * 1024)) : 0,
    expiryDays: client.daysLeft ?? 0,
    enable: client.enable,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    setLoading(true)
    setError(null)
    const res = await apiFetch(`/api/clients/${client.id}`, { method: 'PATCH', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('کاربر به‌روزرسانی شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Pencil className="h-4 w-4 text-primary" /> ویرایش کاربر</DialogTitle>
        <DialogDescription>{client.email ?? client.name ?? client.clientId}</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>نام</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>ایمیل</Label>
            <Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>سهمیه (GB)</Label>
            <Input type="number" value={form.totalGB} onChange={(e) => setForm({ ...form, totalGB: parseInt(e.target.value, 10) || 0 })} />
          </div>
          <div className="space-y-2">
            <Label>مدت اعتبار (روز)</Label>
            <Input type="number" value={form.expiryDays} onChange={(e) => setForm({ ...form, expiryDays: parseInt(e.target.value, 10) || 0 })} />
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ذخیره...' : 'ذخیره'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}
