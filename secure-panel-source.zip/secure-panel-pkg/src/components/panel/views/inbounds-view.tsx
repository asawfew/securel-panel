'use client'

import { useState } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatBytes, formatDateShort } from '@/lib/format'
import { toast } from 'sonner'
import { Plus, Search, Inbox, MoreVertical, Pencil, Trash2, ArrowDown, ArrowUp, Server as ServerIcon, RefreshCw, Network } from 'lucide-react'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'

interface Inbound {
  id: string
  protocol: string
  remark: string
  port: number
  network: string
  tls: string
  security: string
  enable: boolean
  up: string
  down: string
  total: string
  createdAt: string
  server: { name: string }
  _count: { clients: number }
}

interface Server {
  id: string
  name: string
  address: string
}

const PROTOCOL_OPTIONS = [
  { value: 'vless', label: 'VLESS' },
  { value: 'vmess', label: 'VMess' },
  { value: 'trojan', label: 'Trojan' },
  { value: 'shadowsocks', label: 'Shadowsocks' },
  { value: 'dokodemo-door', label: 'Dokodemo-door' },
  { value: 'socks', label: 'SOCKS' },
  { value: 'http', label: 'HTTP' },
]

const NETWORK_OPTIONS = ['tcp', 'kcp', 'ws', 'http', 'grpc', 'quic']
const SECURITY_OPTIONS = ['none', 'tls', 'reality']

export function InboundsView() {
  const [search, setSearch] = useState('')
  const [filterServer, setFilterServer] = useState<string>('')
  const [filterProtocol, setFilterProtocol] = useState<string>('')
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<Inbound | null>(null)
  const [editTarget, setEditTarget] = useState<Inbound | null>(null)

  const query = new URLSearchParams()
  if (filterServer) query.set('serverId', filterServer)
  if (filterProtocol) query.set('protocol', filterProtocol)
  if (search) query.set('q', search)

  const { data, loading, error, refetch } = useApi<{ inbounds: Inbound[] }>(`/api/inbounds?${query.toString()}`)
  const { data: serversData } = useApi<{ servers: Server[] }>('/api/servers')
  const [togglingId, setTogglingId] = useState<string | null>(null)

  async function handleToggle(inbound: Inbound) {
    setTogglingId(inbound.id)
    const res = await apiFetch(`/api/inbounds/${inbound.id}`, {
      method: 'PATCH',
      body: { enable: !inbound.enable },
    })
    setTogglingId(null)
    if (res.ok) {
      toast.success(`اینباند ${inbound.remark} ${inbound.enable ? 'غیرفعال' : 'فعال'} شد`)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    const res = await apiFetch(`/api/inbounds/${deleteTarget.id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success(`اینباند ${deleteTarget.remark} حذف شد`)
      setDeleteTarget(null)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Inbox className="h-5 w-5 text-primary" />
            اینباند‌ها
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            مدیریت کانفیگ‌های VPN — پشتیبانی از VLESS، VMess، Trojan، Shadowsocks
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="glow-primary">
              <Plus className="h-4 w-4 ml-1" />
              افزودن اینباند
            </Button>
          </DialogTrigger>
          <CreateInboundDialog servers={serversData?.servers ?? []} onSuccess={() => { setCreateOpen(false); refetch() }} />
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="md:col-span-2 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجوی اینباند..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9"
              />
            </div>
            <Select value={filterServer || undefined} onValueChange={(v) => setFilterServer(v === "__all__" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="همه سرورها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه سرورها</SelectItem>
                {serversData?.servers.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterProtocol || undefined} onValueChange={(v) => setFilterProtocol(v === "__all__" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="همه پروتکل‌ها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">همه پروتکل‌ها</SelectItem>
                {PROTOCOL_OPTIONS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">
              {[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data || data.inbounds.length === 0 ? (
            <div className="p-12 text-center">
              <Inbox className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">هیچ اینباندی یافت نشد</p>
              <Button variant="outline" className="mt-3" onClick={() => setCreateOpen(true)}>
                <Plus className="h-4 w-4 ml-1" /> افزودن اولین اینباند
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نام / پروتکل</TableHead>
                  <TableHead className="text-right">سرور</TableHead>
                  <TableHead className="text-right">پورت</TableHead>
                  <TableHead className="text-right">شبکه / امنیت</TableHead>
                  <TableHead className="text-right">کاربران</TableHead>
                  <TableHead className="text-right">ترافیک</TableHead>
                  <TableHead className="text-center">فعال</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.inbounds.map((ib) => (
                  <TableRow key={ib.id}>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <span className="font-medium text-sm">{ib.remark}</span>
                        <Badge variant="outline" className="text-[10px] w-fit">{ib.protocol.toUpperCase()}</Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">{ib.server.name}</TableCell>
                    <TableCell className="text-xs tabular-nums">{ib.port}</TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1 text-[10px] text-muted-foreground">
                        <span className="flex items-center gap-1"><Network className="h-3 w-3" /> {ib.network}</span>
                        <span className="flex items-center gap-1"><ServerIcon className="h-3 w-3" /> {ib.security}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs tabular-nums">{ib._count.clients}</TableCell>
                    <TableCell>
                      <div className="text-[10px] tabular-nums space-y-0.5">
                        <div className="flex items-center gap-1 text-success">
                          <ArrowUp className="h-3 w-3" /> {formatBytes(Number(ib.up))}
                        </div>
                        <div className="flex items-center gap-1 text-chart-2">
                          <ArrowDown className="h-3 w-3" /> {formatBytes(Number(ib.down))}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center">
                        <Switch
                          checked={ib.enable}
                          disabled={togglingId === ib.id}
                          onCheckedChange={() => handleToggle(ib)}
                        />
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => setEditTarget(ib)}>
                            <Pencil className="h-4 w-4 ml-2" /> ویرایش
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setDeleteTarget(ib)}
                          >
                            <Trash2 className="h-4 w-4 ml-2" /> حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit dialog */}
      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent className="max-w-lg">
          {editTarget && <EditInboundDialog inbound={editTarget} onSuccess={() => { setEditTarget(null); refetch() }} />}
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف اینباند</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف اینباند «{deleteTarget?.remark}» مطمئن هستید؟ تمام کاربران و آمار مرتبط حذف خواهند شد. این عملیات غیرقابل بازگشت است.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function CreateInboundDialog({ servers, onSuccess }: { servers: Server[]; onSuccess: () => void }) {
  const [form, setForm] = useState({
    serverId: '',
    protocol: 'vless',
    remark: '',
    port: 443,
    network: 'tcp',
    tls: 'reality',
    security: 'reality',
    enable: true,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    if (!form.serverId) return setError('انتخاب سرور الزامی است')
    if (!form.remark.trim()) return setError('نام اینباند الزامی است')
    setLoading(true)
    setError(null)
    const res = await apiFetch('/api/inbounds', { method: 'POST', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('اینباند با موفقیت ایجاد شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Plus className="h-4 w-4 text-primary" />
          ایجاد اینباند جدید
        </DialogTitle>
        <DialogDescription>یک کانفیگ VPN جدید روی سرور انتخاب شده ایجاد کنید</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="space-y-2">
          <Label>سرور</Label>
          <Select value={form.serverId} onValueChange={(v) => setForm({ ...form, serverId: v })}>
            <SelectTrigger><SelectValue placeholder="انتخاب سرور..." /></SelectTrigger>
            <SelectContent>
              {servers.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name} — {s.address}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>نام (Remark)</Label>
            <Input value={form.remark} onChange={(e) => setForm({ ...form, remark: e.target.value })} placeholder="مثلاً Main-VLESS-443" />
          </div>
          <div className="space-y-2">
            <Label>پورت</Label>
            <Input type="number" min={1} max={65535} value={form.port} onChange={(e) => setForm({ ...form, port: parseInt(e.target.value, 10) || 0 })} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="space-y-2">
            <Label>پروتکل</Label>
            <Select value={form.protocol} onValueChange={(v) => setForm({ ...form, protocol: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PROTOCOL_OPTIONS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>شبکه</Label>
            <Select value={form.network} onValueChange={(v) => setForm({ ...form, network: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {NETWORK_OPTIONS.map((n) => (
                  <SelectItem key={n} value={n}>{n.toUpperCase()}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>امنیت</Label>
            <Select value={form.security} onValueChange={(v) => setForm({ ...form, security: v, tls: v === 'none' ? 'none' : v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SECURITY_OPTIONS.map((s) => (
                  <SelectItem key={s} value={s}>{s.toUpperCase()}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        {error && (
          <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md border border-destructive/20">{error}</div>
        )}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>
          {loading ? 'در حال ایجاد...' : 'ایجاد اینباند'}
        </Button>
      </DialogFooter>
    </DialogContent>
  )
}

function EditInboundDialog({ inbound, onSuccess }: { inbound: Inbound; onSuccess: () => void }) {
  const [form, setForm] = useState({
    remark: inbound.remark,
    port: inbound.port,
    network: inbound.network,
    security: inbound.security,
    enable: inbound.enable,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    setLoading(true)
    setError(null)
    const res = await apiFetch(`/api/inbounds/${inbound.id}`, { method: 'PATCH', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('اینباند به‌روزرسانی شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Pencil className="h-4 w-4 text-primary" />
          ویرایش اینباند
        </DialogTitle>
        <DialogDescription>{inbound.protocol.toUpperCase()} — پورت {inbound.port}</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="space-y-2">
          <Label>نام (Remark)</Label>
          <Input value={form.remark} onChange={(e) => setForm({ ...form, remark: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>پورت</Label>
            <Input type="number" value={form.port} onChange={(e) => setForm({ ...form, port: parseInt(e.target.value, 10) || 0 })} />
          </div>
          <div className="space-y-2">
            <Label>شبکه</Label>
            <Select value={form.network} onValueChange={(v) => setForm({ ...form, network: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {NETWORK_OPTIONS.map((n) => <SelectItem key={n} value={n}>{n.toUpperCase()}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ذخیره...' : 'ذخیره تغییرات'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}
