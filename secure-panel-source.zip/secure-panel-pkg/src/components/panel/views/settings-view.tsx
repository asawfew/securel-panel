'use client'

import { useState, useEffect } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { Settings as SettingsIcon, Save, Shield, Palette, Globe2, Clock, AlertTriangle } from 'lucide-react'

interface Settings {
  settings: Record<string, Record<string, string>>
}

export function SettingsView() {
  const { data, loading, refetch } = useApi<Settings>('/api/settings')
  const [form, setForm] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (data?.settings) {
      const flat: Record<string, string> = {}
      for (const cat of Object.values(data.settings)) {
        for (const [k, v] of Object.entries(cat)) {
          flat[k] = v
        }
      }
      setForm(flat)
    }
  }, [data])

  async function save() {
    setSaving(true)
    const res = await apiFetch('/api/settings', { method: 'PATCH', body: { settings: form } })
    setSaving(false)
    if (res.ok) {
      toast.success('تنظیمات ذخیره شد')
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  if (loading) {
    return <div className="space-y-4">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}</div>
  }

  const get = (key: string, def = '') => form[key] ?? def
  const set = (key: string, val: string) => setForm((f) => ({ ...f, [key]: val }))

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-primary" />
            تنظیمات پنل
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">پیکربندی عمومی و امنیتی پنل</p>
        </div>
        <Button onClick={save} disabled={saving} className="glow-primary">
          <Save className="h-4 w-4 ml-1" /> {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات'}
        </Button>
      </div>

      {/* Panel section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Palette className="h-4 w-4 text-primary" />
            تنظیمات عمومی
          </CardTitle>
          <CardDescription className="text-xs">عنوان و ظاهر پنل</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>عنوان پنل</Label>
              <Input value={get('panel.title')} onChange={(e) => set('panel.title', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>زیرعنوان</Label>
              <Input value={get('panel.subtitle')} onChange={(e) => set('panel.subtitle', e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            تنظیمات امنیتی
          </CardTitle>
          <CardDescription className="text-xs">کنترل خط‌مشی‌های امنیتی پنل</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>حداقل طول رمز عبور</Label>
              <Input type="number" value={get('security.min_password_length', '12')} onChange={(e) => set('security.min_password_length', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>حداکثر تلاش ورود</Label>
              <Input type="number" value={get('security.max_login_attempts', '5')} onChange={(e) => set('security.max_login_attempts', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>مدت قفل (ثانیه)</Label>
              <Input type="number" value={get('security.lock_duration', '900')} onChange={(e) => set('security.lock_duration', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>محدودیت نرخ در ساعت</Label>
              <Input type="number" value={get('security.rate_limit_per_hour', '10')} onChange={(e) => set('security.rate_limit_per_hour', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>مدت نشست (ثانیه)</Label>
              <Input type="number" value={get('security.session_timeout', '28800')} onChange={(e) => set('security.session_timeout', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>نگهداری لاگ (روز)</Label>
              <Input type="number" value={get('security.audit_log_retention_days', '180')} onChange={(e) => set('security.audit_log_retention_days', e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-warning/30 bg-warning/5">
        <CardContent className="p-3 flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
          <div className="text-xs leading-relaxed">
            <strong>توجه:</strong> تغییر برخی تنظیمات امنیتی ممکن است روی نشست فعلی شما تأثیر بگذارد. اعداد بسیار کم امنیت را کاهش می‌دهند و اعداد بسیار بزرگ تجربه کاربری را بدتر می‌کنند.
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
