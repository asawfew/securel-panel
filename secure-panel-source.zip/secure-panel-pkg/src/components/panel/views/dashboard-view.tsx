'use client'

import { useApi } from '@/lib/use-api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { formatBytes, formatNumber, timeAgo, msToExpiry, percent } from '@/lib/format'
import {
  Server, Users, Inbox, Activity, ArrowDown, ArrowUp, Clock,
  AlertTriangle, ShieldCheck, TrendingUp, Cpu, HardDrive, Network, Globe2,
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend,
} from 'recharts'

interface DashboardData {
  stats: {
    totalServers: number
    onlineServers: number
    totalInbounds: number
    enabledInbounds: number
    disabledInbounds: number
    totalClients: number
    activeClients: number
    expiredClients: number
    limitedClients: number
    unlimitedClients: number
    totalUp: string
    totalDown: string
    totalTraffic: string
    loginAttempts24h: number
    loginFailures24h: number
    activeSessions: number
  }
  servers: Array<{
    id: string
    name: string
    status: string
    address: string
    country: string | null
    flag: string | null
    cpuUsage: number | null
    memUsage: number | null
    diskUsage: number | null
    netUpload: number | null
    netDownload: number | null
    uptime: number | null
    lastCheckedAt: string | null
  }>
  dailyTraffic: Array<{ date: string; up: number; down: number; total: number }>
  topClients: Array<{ id: string; name: string; total: string; up: string; down: string }>
  protocolDistribution: Array<{ protocol: string; count: number }>
  recentAuditLogs: Array<{
    id: string
    action: string
    description: string
    status: string
    admin: string
    ip: string | null
    createdAt: string
  }>
}

const PIE_COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)']

const PROTOCOL_LABELS: Record<string, string> = {
  vless: 'VLESS',
  vmess: 'VMess',
  trojan: 'Trojan',
  shadowsocks: 'Shadowsocks',
  'dokodemo-door': 'Dokodemo',
  socks: 'SOCKS',
  http: 'HTTP',
}

export function DashboardView() {
  const { data, loading, error } = useApi<DashboardData>('/api/dashboard?days=14')

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
        <Skeleton className="h-80 rounded-xl" />
        <div className="grid md:grid-cols-2 gap-4">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          خطا در بارگذاری داده‌ها: {error ?? 'نامشخص'}
        </CardContent>
      </Card>
    )
  }

  const stats = data.stats
  const totalTrafficNum = Number(stats.totalTraffic)

  const cards = [
    {
      label: 'سرورهای آنلاین',
      value: `${stats.onlineServers} / ${stats.totalServers}`,
      icon: Server,
      color: 'text-success',
      bg: 'bg-success/10',
    },
    {
      label: 'اینباند‌های فعال',
      value: `${stats.enabledInbounds} / ${stats.totalInbounds}`,
      icon: Inbox,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      label: 'کاربران فعال',
      value: formatNumber(stats.activeClients),
      sub: `${formatNumber(stats.expiredClients)} منقضی`,
      icon: Users,
      color: 'text-chart-2',
      bg: 'bg-chart-2/10',
    },
    {
      label: 'ترافیک کل',
      value: formatBytes(totalTrafficNum),
      sub: `↑ ${formatBytes(Number(stats.totalUp))} ↓ ${formatBytes(Number(stats.totalDown))}`,
      icon: Activity,
      color: 'text-chart-3',
      bg: 'bg-chart-3/10',
    },
  ]

  // Format daily traffic for chart
  const chartData = data.dailyTraffic.map((d) => ({
    ...d,
    upMB: +(d.up / (1024 * 1024)).toFixed(2),
    downMB: +(d.down / (1024 * 1024)).toFixed(2),
    totalGB: +(d.total / (1024 * 1024 * 1024)).toFixed(2),
    label: new Date(d.date).toLocaleDateString('fa-IR', { month: 'numeric', day: 'numeric' }),
  }))

  // Top clients data
  const topClientsData = data.topClients.map((c) => ({
    name: c.name,
    total: +(Number(c.total) / (1024 * 1024 * 1024)).toFixed(1),
    up: +(Number(c.up) / (1024 * 1024 * 1024)).toFixed(1),
    down: +(Number(c.down) / (1024 * 1024 * 1024)).toFixed(1),
  }))

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((c, i) => {
          const Icon = c.icon
          return (
            <Card key={i} className="card-hover overflow-hidden">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">{c.label}</p>
                    <p className="text-2xl font-bold tabular-nums">{c.value}</p>
                    {c.sub && <p className="text-[10px] text-muted-foreground">{c.sub}</p>}
                  </div>
                  <div className={`w-10 h-10 rounded-xl ${c.bg} flex items-center justify-center`}>
                    <Icon className={`h-5 w-5 ${c.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Security alerts */}
      {(stats.loginFailures24h > 0 || stats.expiredClients > 0) && (
        <div className="grid md:grid-cols-2 gap-3">
          {stats.loginFailures24h > 0 && (
            <Card className="border-warning/30 bg-warning/5">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-warning/15 flex items-center justify-center shrink-0">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">تلاش‌های ورود ناموفق</p>
                  <p className="text-xs text-muted-foreground">
                    {formatNumber(stats.loginFailures24h)} تلاش ناموفق در ۲۴ ساعت گذشته
                  </p>
                </div>
                <Badge variant="outline" className="text-warning border-warning/30">
                  {formatNumber(stats.loginFailures24h)}
                </Badge>
              </CardContent>
            </Card>
          )}
          {stats.activeSessions > 0 && (
            <Card className="border-success/30 bg-success/5">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-success/15 flex items-center justify-center shrink-0">
                  <ShieldCheck className="h-4 w-4 text-success" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">نشست‌های فعال</p>
                  <p className="text-xs text-muted-foreground">نشست‌های فعال ادمین‌ها</p>
                </div>
                <Badge variant="outline" className="text-success border-success/30">
                  {formatNumber(stats.activeSessions)}
                </Badge>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Traffic chart */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                ترافیک ۱۴ روز اخیر
              </CardTitle>
              <CardDescription className="text-xs mt-1">
                حجم آپلود و دانلود روزانه به مگابایت
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--chart-1)' }} />
                <span className="text-muted-foreground">آپلود</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--chart-2)' }} />
                <span className="text-muted-foreground">دانلود</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="upGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--chart-1)" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="downGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--chart-2)" stopOpacity={0.5} />
                  <stop offset="95%" stopColor="var(--chart-2)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} width={50} />
              <Tooltip
                contentStyle={{
                  background: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '8px',
                  fontSize: 12,
                }}
                labelStyle={{ color: 'var(--foreground)' }}
                formatter={(v: number, n: string) => [`${v} MB`, n === 'upMB' ? 'آپلود' : 'دانلود']}
              />
              <Area type="monotone" dataKey="upMB" stroke="var(--chart-1)" strokeWidth={2} fill="url(#upGrad)" />
              <Area type="monotone" dataKey="downMB" stroke="var(--chart-2)" strokeWidth={2} fill="url(#downGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Two columns: servers + protocols */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Servers status */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Server className="h-4 w-4 text-primary" />
              وضعیت سرورها
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.servers.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-6">هیچ سروری ثبت نشده</p>
            ) : (
              data.servers.map((s) => (
                <div key={s.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/40 hover:bg-muted transition-colors">
                  <div className="flex items-center gap-2 shrink-0">
                    {s.flag ? (
                      <span className="text-lg">{flagEmoji(s.flag)}</span>
                    ) : (
                      <Globe2 className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">{s.name}</p>
                      <Badge
                        variant="outline"
                        className={
                          s.status === 'ONLINE' ? 'text-success border-success/30' :
                          s.status === 'DEGRADED' ? 'text-warning border-warning/30' :
                          'text-destructive border-destructive/30'
                        }
                      >
                        {s.status === 'ONLINE' ? 'آنلاین' : s.status === 'DEGRADED' ? 'ضعیف' : 'آفلاین'}
                      </Badge>
                    </div>
                    <p className="text-[10px] text-muted-foreground tabular-nums">{s.address}</p>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground shrink-0">
                    {s.cpuUsage !== null && (
                      <div className="flex items-center gap-1">
                        <Cpu className="h-3 w-3" />
                        <span className="tabular-nums">{s.cpuUsage.toFixed(1)}%</span>
                      </div>
                    )}
                    {s.memUsage !== null && (
                      <div className="flex items-center gap-1">
                        <HardDrive className="h-3 w-3" />
                        <span className="tabular-nums">{s.memUsage.toFixed(1)}%</span>
                      </div>
                    )}
                    {s.uptime !== null && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{formatUptime(s.uptime)}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Protocol distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Network className="h-4 w-4 text-primary" />
              توزیع پروتکل‌ها
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.protocolDistribution.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-6">داده‌ای موجود نیست</p>
            ) : (
              <>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={data.protocolDistribution.map(p => ({ name: PROTOCOL_LABELS[p.protocol] ?? p.protocol, value: p.count }))}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={3}
                    >
                      {data.protocolDistribution.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: 'var(--card)',
                        border: '1px solid var(--border)',
                        borderRadius: '8px',
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-1.5 mt-2">
                  {data.protocolDistribution.map((p, i) => (
                    <div key={p.protocol} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <span>{PROTOCOL_LABELS[p.protocol] ?? p.protocol}</span>
                      </div>
                      <span className="tabular-nums font-medium">{p.count}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            فعالیت‌های اخیر
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.recentAuditLogs.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">هیچ فعالیت‌ای ثبت نشده</p>
          ) : (
            <div className="space-y-2 max-h-72 overflow-y-auto pl-2">
              {data.recentAuditLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-3 py-2 border-b border-border/50 last:border-0">
                  <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                    log.status === 'FAILURE' ? 'bg-destructive' :
                    log.status === 'WARNING' ? 'bg-warning' : 'bg-success'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs">{log.description}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {log.admin} · {log.ip ?? 'سیستم'} · {timeAgo(log.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function flagEmoji(code: string): string {
  if (!code || code.length !== 2) return '🌐'
  const base = 0x1f1e6
  const A = 'A'.charCodeAt(0)
  return String.fromCodePoint(base + (code.toUpperCase().charCodeAt(0) - A)) +
         String.fromCodePoint(base + (code.toUpperCase().charCodeAt(1) - A))
}

function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  if (days > 0) return `${days}ر`
  return `${hours}س`
}
