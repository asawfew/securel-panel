'use client'

import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { Smartphone, Monitor, Globe, Clock, Trash2, LogOut, MonitorSmartphone, CheckCircle2 } from 'lucide-react'
import { timeAgo } from '@/lib/format'

interface Session {
  id: string
  ip: string | null
  userAgent: string | null
  createdAt: string
  lastUsedAt: string
  expiresAt: string
  isCurrent: boolean
}

export function SessionsView() {
  const { data, loading, error, refetch } = useApi<{ sessions: Session[] }>('/api/auth/sessions')

  async function handleRevoke(id: string) {
    const res = await apiFetch(`/api/auth/sessions?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success('نشست لغو شد')
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleRevokeAll() {
    const res = await apiFetch('/api/auth/sessions', { method: 'DELETE' })
    if (res.ok) {
      toast.success('سایر نشست‌ها لغو شدند')
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <MonitorSmartphone className="h-5 w-5 text-primary" />
            نشست‌های فعال
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">مدیریت دستگاه‌های وارد شده به حساب</p>
        </div>
        {data && data.sessions.filter((s) => !s.isCurrent).length > 0 && (
          <Button variant="outline" size="sm" onClick={handleRevokeAll}>
            <LogOut className="h-3.5 w-3.5 ml-1" /> لغو همه نشست‌های دیگر
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data || data.sessions.length === 0 ? (
            <div className="p-12 text-center">
              <MonitorSmartphone className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">هیچ نشست فعالی موجود نیست</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {data.sessions.map((s) => (
                <div key={s.id} className="p-4 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.isCurrent ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
                    {parseDevice(s.userAgent) === 'mobile' ? <Smartphone className="h-4 w-4" /> : <Monitor className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium">{parseUserAgent(s.userAgent)}</span>
                      {s.isCurrent && (
                        <Badge variant="outline" className="text-success border-success/30 bg-success/5">
                          <CheckCircle2 className="h-3 w-3 ml-1" /> این دستگاه
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                      {s.ip && <span className="flex items-center gap-1"><Globe className="h-3 w-3" />{s.ip}</span>}
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />آخرین استفاده: {timeAgo(s.lastUsedAt)}</span>
                    </div>
                  </div>
                  {!s.isCurrent && (
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleRevoke(s.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function parseUserAgent(ua: string | null): string {
  if (!ua) return 'نامشخص'
  if (/Windows/i.test(ua)) return 'ویندوز'
  if (/Macintosh|Mac OS X/i.test(ua)) return 'مک'
  if (/Linux/i.test(ua)) return 'لینوکس'
  if (/Android/i.test(ua)) return 'اندروید'
  if (/iPhone|iPad/i.test(ua)) return 'iOS'
  return 'نامشخص'
}

function parseDevice(ua: string | null): 'mobile' | 'desktop' {
  if (!ua) return 'desktop'
  if (/Mobile|Android|iPhone|iPad/i.test(ua)) return 'mobile'
  return 'desktop'
}
