'use client'

import { useState } from 'react'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import { UserRound, KeyRound, ShieldCheck, Eye, EyeOff, Check, X, AlertTriangle } from 'lucide-react'

export function ProfileView() {
  const admin = useAppStore((s) => s.admin)

  const [currentPass, setCurrentPass] = useState('')
  const [newPass, setNewPass] = useState('')
  const [confirmPass, setConfirmPass] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)

  const strength = checkStrength(newPass)

  async function changePassword() {
    if (newPass !== confirmPass) return toast.error('رمز عبور جدید و تأیید آن یکسان نیستند')
    if (strength.score < 4) return toast.error('رمز عبور ضعیف است. حداقل ۱۲ کاراکتر با حروف بزرگ، کوچک، عدد و کاراکتر خاص')
    setLoading(true)
    const res = await apiFetch<{ code?: string }>('/api/auth/change-password', {
      method: 'POST',
      body: { currentPassword: currentPass, newPassword: newPass },
    })
    setLoading(false)
    if (res.ok) {
      toast.success('رمز عبور با موفقیت تغییر کرد. نشست شما فعال باقی می‌ماند.')
      setCurrentPass('')
      setNewPass('')
      setConfirmPass('')
    } else {
      // If session expired, reload to show login page
      if (res.code === 'UNAUTHORIZED' || res.status === 401) {
        toast.error('نشست شما منقضی شده است. به صفحه ورود هدایت می‌شوید...')
        setTimeout(() => window.location.reload(), 1500)
        return
      }
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <UserRound className="h-5 w-5 text-primary" />
          پروفایل من
        </h2>
        <p className="text-xs text-muted-foreground mt-0.5">مدیریت حساب کاربری و امنیت شخصی</p>
      </div>

      {/* Profile card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">اطلاعات حساب</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <span className="text-2xl font-bold text-primary">
                {(admin?.username ?? 'A').slice(0, 2).toUpperCase()}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-lg font-medium">{admin?.username}</p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5">
                  {roleLabel(admin?.role)}
                </Badge>
                {admin?.twoFactorEnabled ? (
                  <Badge variant="outline" className="text-success border-success/30 bg-success/5">
                    <ShieldCheck className="h-3 w-3 ml-1" /> 2FA فعال
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-warning border-warning/30 bg-warning/5">
                    <AlertTriangle className="h-3 w-3 ml-1" /> 2FA غیرفعال
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change password */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-primary" />
            تغییر رمز عبور
          </CardTitle>
          <CardDescription className="text-xs">
            رمز عبور باید حداقل ۱۲ کاراکتر و شامل حروف بزرگ، کوچک، عدد و کاراکتر خاص باشد
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <Label>رمز عبور فعلی</Label>
            <div className="relative">
              <Input
                type={showPass ? 'text' : 'password'}
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                className="pl-9"
                autoComplete="current-password"
              />
              <button type="button" tabIndex={-1} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" onClick={() => setShowPass((s) => !s)}>
                {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div className="space-y-2">
            <Label>رمز عبور جدید</Label>
            <Input
              type={showPass ? 'text' : 'password'}
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              className="font-mono"
              autoComplete="new-password"
            />
            {newPass.length > 0 && (
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <Progress value={strength.score * 20} className="h-1.5" />
                  <span className={`text-xs font-medium ${strength.score >= 4 ? 'text-success' : strength.score >= 2 ? 'text-warning' : 'text-destructive'}`}>
                    {strength.score >= 4 ? 'قوی' : strength.score >= 2 ? 'متوسط' : 'ضعیف'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1">
                  <StrengthItem label="حداقل ۱۲ کاراکتر" ok={newPass.length >= 12} />
                  <StrengthItem label="حروف بزرگ و کوچک" ok={/[a-z]/.test(newPass) && /[A-Z]/.test(newPass)} />
                  <StrengthItem label="حداقل یک عدد" ok={/\d/.test(newPass)} />
                  <StrengthItem label="کاراکتر خاص" ok={/[^A-Za-z0-9]/.test(newPass)} />
                </div>
              </div>
            )}
          </div>
          <div className="space-y-2">
            <Label>تأیید رمز عبور جدید</Label>
            <Input
              type={showPass ? 'text' : 'password'}
              value={confirmPass}
              onChange={(e) => setConfirmPass(e.target.value)}
              autoComplete="new-password"
            />
            {confirmPass && confirmPass !== newPass && (
              <p className="text-xs text-destructive flex items-center gap-1"><X className="h-3 w-3" /> رمزها یکسان نیستند</p>
            )}
          </div>
          <Button
            onClick={changePassword}
            disabled={loading || !currentPass || !newPass || newPass !== confirmPass || strength.score < 4}
            className="glow-primary"
          >
            {loading ? 'در حال تغییر...' : 'تغییر رمز عبور'}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function StrengthItem({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className="flex items-center gap-1.5 text-[10px]">
      <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center ${ok ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
        {ok ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5" />}
      </div>
      <span className={ok ? '' : 'text-muted-foreground'}>{label}</span>
    </div>
  )
}

function checkStrength(p: string): { score: number } {
  let s = 0
  if (p.length >= 12) s++
  if (/[a-z]/.test(p) && /[A-Z]/.test(p)) s++
  if (/\d/.test(p)) s++
  if (/[^A-Za-z0-9]/.test(p)) s++
  if (p.length >= 16) s++
  return { score: s }
}

function roleLabel(r?: string): string {
  switch (r) {
    case 'SUPER_ADMIN': return 'ادمین ارشد'
    case 'ADMIN': return 'ادمین'
    case 'OPERATOR': return 'اپراتور'
    case 'AUDITOR': return 'حسابرسی'
    default: return 'نامشخص'
  }
}
