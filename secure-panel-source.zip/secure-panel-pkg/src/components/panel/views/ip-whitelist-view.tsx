'use client'

import { useState } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { Globe2, Plus, Trash2, ShieldCheck, AlertTriangle, Clock } from 'lucide-react'
import { timeAgo } from '@/lib/format'

interface IpEntry {
  id: string
  ip: string
  note: string | null
  enabled: boolean
  createdAt: string
}

export function IpWhitelistView() {
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<IpEntry | null>(null)
  const [togglingId, setTogglingId] = useState<string | null>(null)

  const { data, loading, error, refetch } = useApi<{ entries: IpEntry[] }>('/api/security/ip-whitelist')

  async function handleToggle(entry: IpEntry) {
    setTogglingId(entry.id)
    const res = await apiFetch(`/api/security/ip-whitelist/${entry.id}`, {
      method: 'PATCH',
      body: { enabled: !entry.enabled },
    })
    setTogglingId(null)
    if (res.ok) {
      toast.success(`IP ${entry.ip} ${entry.enabled ? 'غیرفعال' : 'فعال'} شد`)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    const res = await apiFetch(`/api/security/ip-whitelist/${deleteTarget.id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success('IP حذف شد')
      setDeleteTarget(null)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Globe2 className="h-5 w-5 text-primary" />
            لیست سفید IP
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">محدود کردن دسترسی پنل فقط به IPهای مجاز</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="glow-primary"><Plus className="h-4 w-4 ml-1" /> افزودن IP</Button>
          </DialogTrigger>
          <CreateIpDialog onSuccess={() => { setCreateOpen(false); refetch() }} />
        </Dialog>
      </div>

      {/* Info banner */}
      <Card className="border-warning/30 bg-warning/5">
        <CardContent className="p-3 flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
          <div className="text-xs leading-relaxed">
            <strong>توجه:</strong> وقتی لیست سفید IP خالی باشد، تمام IPها مجاز هستند. به‌محض افزودن اولین IP، فقط IPهای داخل لیست می‌توانند به پنل دسترسی داشته باشند.
            مطمئن شوید IP فعلی خود را قبل از فعال‌سازی اضافه کرده‌اید تا قفل نشوید.
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data || data.entries.length === 0 ? (
            <div className="p-12 text-center">
              <Globe2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">لیست سفید خالی است — همه IPها مجاز هستند</p>
              <Button variant="outline" className="mt-3" onClick={() => setCreateOpen(true)}>
                <Plus className="h-4 w-4 ml-1" /> افزودن اولین IP
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {data.entries.map((entry) => (
                <div key={entry.id} className="p-4 flex items-center gap-3 hover:bg-muted/30">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${entry.enabled ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
                    <ShieldCheck className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm tabular-nums">{entry.ip}</p>
                    {entry.note && <p className="text-[10px] text-muted-foreground">{entry.note}</p>}
                    <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Clock className="h-3 w-3" /> {timeAgo(entry.createdAt)}
                    </p>
                  </div>
                  <div className="flex items-center">
                    <Switch
                      checked={entry.enabled}
                      disabled={togglingId === entry.id}
                      onCheckedChange={() => handleToggle(entry)}
                    />
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeleteTarget(entry)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف IP</AlertDialogTitle>
            <AlertDialogDescription>آیا از حذف IP «{deleteTarget?.ip}» مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function CreateIpDialog({ onSuccess }: { onSuccess: () => void }) {
  const [ip, setIp] = useState('')
  const [note, setNote] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    if (!ip.trim()) return setError('IP الزامی است')
    setLoading(true)
    setError(null)
    const res = await apiFetch('/api/security/ip-whitelist', { method: 'POST', body: { ip, note } })
    setLoading(false)
    if (res.ok) {
      toast.success('IP اضافه شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Plus className="h-4 w-4 text-primary" /> افزودن IP به لیست سفید</DialogTitle>
        <DialogDescription>یک IP یا CIDR اضافه کنید (مثلاً 192.168.1.1 یا 10.0.0.0/8)</DialogDescription>
      </DialogHeader>
      <div className="space-y-3 py-2">
        <div className="space-y-2">
          <Label>آدرس IP یا CIDR</Label>
          <Input value={ip} onChange={(e) => setIp(e.target.value)} placeholder="192.168.1.1 یا 10.0.0.0/8" autoFocus />
        </div>
        <div className="space-y-2">
          <Label>توضیح (اختیاری)</Label>
          <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="مثلاً دفتر مرکزی" />
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md border border-destructive/20">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال افزودن...' : 'افزودن'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}
