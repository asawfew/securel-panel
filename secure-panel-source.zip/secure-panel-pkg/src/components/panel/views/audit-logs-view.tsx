'use client'

import { useState } from 'react'
import { useApi } from '@/lib/use-api'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { timeAgo } from '@/lib/format'
import { ScrollText, Filter, RefreshCw, ChevronRight, ChevronLeft, ShieldCheck, ShieldAlert, ShieldX, User, Globe2, Clock } from 'lucide-react'

interface AuditLog {
  id: string
  action: string
  category: string
  description: string
  status: string
  admin: string
  ip: string | null
  userAgent: string | null
  createdAt: string
  metadata: string
}

const CATEGORY_LABELS: Record<string, string> = {
  AUTH: 'احراز هویت',
  INBOUND: 'اینباند',
  CLIENT: 'کاربر',
  SERVER: 'سرور',
  SECURITY: 'امنیت',
  SETTINGS: 'تنظیمات',
  GENERAL: 'عمومی',
}

const ACTION_LABELS: Record<string, string> = {
  LOGIN_SUCCESS: 'ورود موفق',
  LOGIN_FAILED: 'ورود ناموفق',
  LOGIN_2FA_FAILED: 'کد 2FA اشتباه',
  LOGIN_LOCKED: 'حساب قفل شد',
  LOGIN_RATE_LIMITED: 'محدودیت نرخ',
  LOGOUT: 'خروج',
  CREATE_INBOUND: 'ایجاد اینباند',
  UPDATE_INBOUND: 'ویرایش اینباند',
  DELETE_INBOUND: 'حذف اینباند',
  CREATE_CLIENT: 'ایجاد کاربر',
  UPDATE_CLIENT: 'ویرایش کاربر',
  DELETE_CLIENT: 'حذف کاربر',
  CREATE_SERVER: 'افزودن سرور',
  UPDATE_SERVER: 'ویرایش سرور',
  DELETE_SERVER: 'حذف سرور',
  SERVER_CHECK: 'بررسی سرور',
  PASSWORD_CHANGED: 'تغییر رمز',
  '2FA_ENABLED': 'فعال‌سازی 2FA',
  '2FA_DISABLED': 'غیرفعال‌سازی 2FA',
  '2FA_SETUP_FAILED': 'خطای راه‌اندازی 2FA',
  '2FA_DISABLE_FAILED': 'خطای غیرفعال‌سازی 2FA',
  SESSION_REVOKED: 'لغو نشست',
  ALL_OTHER_SESSIONS_REVOKED: 'لغو همه نشست‌ها',
  IP_WHITELIST_ADD: 'افزودن IP مجاز',
  IP_WHITELIST_UPDATE: 'ویرایش IP مجاز',
  IP_WHITELIST_REMOVE: 'حذف IP مجاز',
  CREATE_ADMIN: 'افزودن ادمین',
  UPDATE_ADMIN: 'ویرایش ادمین',
  DELETE_ADMIN: 'حذف ادمین',
  SETTINGS_UPDATED: 'به‌روزرسانی تنظیمات',
}

export function AuditLogsView() {
  const [page, setPage] = useState(1)
  const [filterCategory, setFilterCategory] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  const query = new URLSearchParams()
  query.set('page', String(page))
  query.set('limit', '30')
  if (filterCategory) query.set('category', filterCategory)
  if (filterStatus) query.set('status', filterStatus)

  const { data, loading, error, refetch } = useApi<{ logs: AuditLog[]; pagination: { page: number; limit: number; total: number; totalPages: number } }>(`/api/security/audit-logs?${query.toString()}`)

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <ScrollText className="h-5 w-5 text-primary" />
            لاگ‌های امنیتی
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">ثبت تمام فعالیت‌های حساس پنل</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-3.5 w-3.5 ml-1" /> به‌روزرسانی
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-3">
          <div className="flex items-center gap-3">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={filterCategory} onValueChange={(v) => { setFilterCategory(v === 'all' ? '' : v); setPage(1) }}>
              <SelectTrigger className="w-44"><SelectValue placeholder="همه دسته‌بندی‌ها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه دسته‌بندی‌ها</SelectItem>
                {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={(v) => { setFilterStatus(v === 'all' ? '' : v); setPage(1) }}>
              <SelectTrigger className="w-40"><SelectValue placeholder="همه وضعیت‌ها" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="SUCCESS">موفق</SelectItem>
                <SelectItem value="FAILURE">ناموفق</SelectItem>
                <SelectItem value="WARNING">هشدار</SelectItem>
              </SelectContent>
            </Select>
            {data && (
              <span className="text-xs text-muted-foreground mr-auto">
                {data.pagination.total} رخداد
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Logs */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data || data.logs.length === 0 ? (
            <div className="p-12 text-center">
              <ScrollText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">هیچ لاگی موجود نیست</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {data.logs.map((log) => (
                <div key={log.id} className="p-4 flex items-start gap-3 hover:bg-muted/30 transition-colors">
                  <div className="shrink-0 mt-0.5">
                    <StatusIcon status={log.status} />
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium">{ACTION_LABELS[log.action] ?? log.action}</span>
                      <Badge variant="outline" className="text-[10px]">{CATEGORY_LABELS[log.category] ?? log.category}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{log.description}</p>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                      <span className="flex items-center gap-1"><User className="h-3 w-3" />{log.admin ?? "سیستم"}</span>
                      {log.ip && <span className="flex items-center gap-1"><Globe2 className="h-3 w-3" />{log.ip}</span>}
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{timeAgo(log.createdAt)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {data && data.pagination.totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
            <ChevronRight className="h-4 w-4" /> قبلی
          </Button>
          <span className="text-xs text-muted-foreground">
            صفحه {page} از {data.pagination.totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= data.pagination.totalPages} onClick={() => setPage((p) => p + 1)}>
            بعدی <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}

function StatusIcon({ status }: { status: string }) {
  if (status === 'SUCCESS') return <div className="w-8 h-8 rounded-lg bg-success/15 flex items-center justify-center"><ShieldCheck className="h-4 w-4 text-success" /></div>
  if (status === 'WARNING') return <div className="w-8 h-8 rounded-lg bg-warning/15 flex items-center justify-center"><ShieldAlert className="h-4 w-4 text-warning" /></div>
  return <div className="w-8 h-8 rounded-lg bg-destructive/15 flex items-center justify-center"><ShieldX className="h-4 w-4 text-destructive" /></div>
}
