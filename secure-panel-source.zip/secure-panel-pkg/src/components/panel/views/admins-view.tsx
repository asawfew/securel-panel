'use client'

import { useState } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'
import { Plus, UserCog, MoreVertical, Trash2, KeyRound, Lock, ShieldCheck, Fingerprint } from 'lucide-react'
import { timeAgo } from '@/lib/format'

interface Admin {
  id: string
  username: string
  role: string
  twoFactorEnabled: boolean
  failedAttempts: number
  lockedUntil: string | null
  lastLoginAt: string | null
  lastLoginIp: string | null
  createdAt: string
}

const ROLE_LABELS: Record<string, { label: string; cls: string }> = {
  SUPER_ADMIN: { label: 'ادمین ارشد', cls: 'text-primary border-primary/30 bg-primary/5' },
  ADMIN: { label: 'ادمین', cls: 'text-chart-2 border-chart-2/30 bg-chart-2/5' },
  OPERATOR: { label: 'اپراتور', cls: 'text-warning border-warning/30 bg-warning/5' },
  AUDITOR: { label: 'حسابرسی', cls: 'text-muted-foreground border-muted-foreground/30' },
}

export function AdminsView() {
  const [createOpen, setCreateOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<Admin | null>(null)
  const [editTarget, setEditTarget] = useState<Admin | null>(null)

  const { data, loading, error, refetch } = useApi<{ admins: Admin[] }>('/api/admins')

  async function handleDelete() {
    if (!deleteTarget) return
    const res = await apiFetch(`/api/admins/${deleteTarget.id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success('ادمین حذف شد')
      setDeleteTarget(null)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <UserCog className="h-5 w-5 text-primary" />
            مدیران پنل
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">مدیریت کاربران ادمین و سطوح دسترسی</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="glow-primary"><Plus className="h-4 w-4 ml-1" /> افزودن ادمین</Button>
          </DialogTrigger>
          <CreateAdminDialog onSuccess={() => { setCreateOpen(false); refetch() }} />
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
          ) : error ? (
            <div className="p-6 text-center text-destructive text-sm">{error}</div>
          ) : !data ? null : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">کاربر</TableHead>
                  <TableHead className="text-right">نقش</TableHead>
                  <TableHead className="text-right">2FA</TableHead>
                  <TableHead className="text-right">آخرین ورود</TableHead>
                  <TableHead className="text-right">وضعیت</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.admins.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell>
                      <div className="flex flex-col gap-0.5">
                        <span className="font-medium text-sm">{a.username}</span>
                        {a.lastLoginIp && <span className="text-[10px] text-muted-foreground tabular-nums">{a.lastLoginIp}</span>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`text-[10px] ${ROLE_LABELS[a.role]?.cls ?? ''}`}>
                        {ROLE_LABELS[a.role]?.label ?? a.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {a.twoFactorEnabled ? (
                        <Badge variant="outline" className="text-success border-success/30 bg-success/5 text-[10px]">
                          <ShieldCheck className="h-3 w-3 ml-1" /> فعال
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-muted-foreground text-[10px]">غیرفعال</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {a.lastLoginAt ? timeAgo(a.lastLoginAt) : 'هرگز'}
                    </TableCell>
                    <TableCell>
                      {a.lockedUntil && new Date(a.lockedUntil) > new Date() ? (
                        <Badge variant="outline" className="text-destructive border-destructive/30 bg-destructive/5 text-[10px]">
                          <Lock className="h-3 w-3 ml-1" /> قفل شده
                        </Badge>
                      ) : a.failedAttempts > 0 ? (
                        <Badge variant="outline" className="text-warning border-warning/30 bg-warning/5 text-[10px]">
                          {a.failedAttempts} تلاش ناموفق
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-success border-success/30 bg-success/5 text-[10px]">فعال</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => setEditTarget(a)}>
                            <KeyRound className="h-4 w-4 ml-2" /> مدیریت
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteTarget(a)}>
                            <Trash2 className="h-4 w-4 ml-2" /> حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent>
          {editTarget && <EditAdminDialog admin={editTarget} onSuccess={() => { setEditTarget(null); refetch() }} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف ادمین</AlertDialogTitle>
            <AlertDialogDescription>آیا از حذف ادمین «{deleteTarget?.username}» مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function CreateAdminDialog({ onSuccess }: { onSuccess: () => void }) {
  const [form, setForm] = useState({ username: '', password: '', role: 'ADMIN' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    if (form.username.length < 4) return setError('نام کاربری باید حداقل ۴ کاراکتر باشد')
    if (form.password.length < 12) return setError('رمز عبور باید حداقل ۱۲ کاراکتر باشد')
    setLoading(true)
    setError(null)
    const res = await apiFetch('/api/admins', { method: 'POST', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('ادمین با موفقیت ایجاد شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Plus className="h-4 w-4 text-primary" /> افزودن ادمین جدید</DialogTitle>
        <DialogDescription>یک کاربر ادمین با سطح دسترسی مشخص ایجاد کنید</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="space-y-2">
          <Label>نام کاربری</Label>
          <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="مثلاً operator1" />
          <p className="text-[10px] text-muted-foreground">۴ تا ۳۲ کاراکتر، شامل حروف انگلیسی، عدد، _ و -</p>
        </div>
        <div className="space-y-2">
          <Label>رمز عبور</Label>
          <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="حداقل ۱۲ کاراکتر" />
          <p className="text-[10px] text-muted-foreground">حداقل ۱۲ کاراکتر شامل حروف بزرگ، کوچک، عدد و کاراکتر خاص</p>
        </div>
        <div className="space-y-2">
          <Label>نقش</Label>
          <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="SUPER_ADMIN">ادمین ارشد — دسترسی کامل</SelectItem>
              <SelectItem value="ADMIN">ادمین — مدیریت عملیات</SelectItem>
              <SelectItem value="OPERATOR">اپراتور — فقط عملیات روزمره</SelectItem>
              <SelectItem value="AUDITOR">حسابرسی — فقط مشاهده</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md border border-destructive/20">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ایجاد...' : 'ایجاد ادمین'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}

function EditAdminDialog({ admin, onSuccess }: { admin: Admin; onSuccess: () => void }) {
  const [form, setForm] = useState({
    role: admin.role,
    resetPassword: '',
    unlockAccount: false,
    disable2FA: false,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    setLoading(true)
    setError(null)
    const body: Record<string, unknown> = { role: form.role }
    if (form.resetPassword) body.resetPassword = form.resetPassword
    if (form.unlockAccount) body.unlockAccount = true
    if (form.disable2FA) body.disable2FA = true
    const res = await apiFetch(`/api/admins/${admin.id}`, { method: 'PATCH', body })
    setLoading(false)
    if (res.ok) {
      toast.success('به‌روزرسانی شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><KeyRound className="h-4 w-4 text-primary" /> مدیریت ادمین</DialogTitle>
        <DialogDescription>{admin.username}</DialogDescription>
      </DialogHeader>
      <div className="space-y-4 py-2">
        <div className="space-y-2">
          <Label>نقش</Label>
          <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="SUPER_ADMIN">ادمین ارشد</SelectItem>
              <SelectItem value="ADMIN">ادمین</SelectItem>
              <SelectItem value="OPERATOR">اپراتور</SelectItem>
              <SelectItem value="AUDITOR">حسابرسی</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>بازنشانی رمز عبور (اختیاری)</Label>
          <Input type="password" value={form.resetPassword} onChange={(e) => setForm({ ...form, resetPassword: e.target.value })} placeholder="حداقل ۱۲ کاراکتر — خالی = بدون تغییر" />
          <p className="text-[10px] text-muted-foreground">در صورت تغییر، تمام نشست‌های این کاربر لغو می‌شود</p>
        </div>
        <div className="space-y-2">
          <Label>اقدامات</Label>
          <div className="space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.unlockAccount} onChange={(e) => setForm({ ...form, unlockAccount: e.target.checked })} />
              <span className="text-sm">باز کردن قفل حساب (در صورت قفل بودن)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.disable2FA} onChange={(e) => setForm({ ...form, disable2FA: e.target.checked })} />
              <span className="text-sm">غیرفعال‌سازی 2FA</span>
            </label>
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ذخیره...' : 'ذخیره'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}
