'use client'

import { useState } from 'react'
import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { formatBytes, formatNumber, timeAgo } from '@/lib/format'
import {
  Plus, Server as ServerIcon, MoreVertical, Pencil, Trash2, RefreshCw, Globe2, Cpu, HardDrive,
  Network, Clock, Activity, ArrowDown, ArrowUp, CheckCircle2, XCircle,
} from 'lucide-react'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Server {
  id: string
  name: string
  address: string
  apiHost: string
  apiPort: number
  apiUser: string | null
  apiPath: string
  status: string
  country: string | null
  flag: string | null
  cpuUsage: number | null
  memUsage: number | null
  diskUsage: number | null
  netUpload: number | null
  netDownload: number | null
  uptime: number | null
  lastCheckedAt: string | null
  inboundCount: number
  clientCount: number
  up: string
  down: string
  total: string
}

export function ServersView() {
  const [createOpen, setCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<Server | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Server | null>(null)
  const [checkingId, setCheckingId] = useState<string | null>(null)

  const { data, loading, error, refetch } = useApi<{ servers: Server[] }>('/api/servers')

  async function handleCheck(s: Server) {
    setCheckingId(s.id)
    const res = await apiFetch(`/api/servers/${s.id}`, { method: 'POST' })
    setCheckingId(null)
    if (res.ok) {
      toast.success('بررسی انجام شد')
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    const res = await apiFetch(`/api/servers/${deleteTarget.id}`, { method: 'DELETE' })
    if (res.ok) {
      toast.success('سرور حذف شد')
      setDeleteTarget(null)
      refetch()
    } else {
      toast.error(res.error)
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <ServerIcon className="h-5 w-5 text-primary" />
            سرورها
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">مدیریت چند سرور و نظارت بر وضعیت منابع</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="glow-primary"><Plus className="h-4 w-4 ml-1" /> افزودن سرور</Button>
          </DialogTrigger>
          <CreateServerDialog onSuccess={() => { setCreateOpen(false); refetch() }} />
        </Dialog>
      </div>

      {loading ? (
        <div className="grid md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      ) : error ? (
        <Card><CardContent className="p-6 text-center text-destructive text-sm">{error}</CardContent></Card>
      ) : !data || data.servers.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <ServerIcon className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
            <p className="text-sm text-muted-foreground">هیچ سروری ثبت نشده</p>
            <Button variant="outline" className="mt-3" onClick={() => setCreateOpen(true)}>
              <Plus className="h-4 w-4 ml-1" /> افزودن اولین سرور
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {data.servers.map((s) => (
            <Card key={s.id} className="card-hover overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-xl">
                      {s.flag ? flagEmoji(s.flag) : <Globe2 className="h-5 w-5 text-primary" />}
                    </div>
                    <div>
                      <CardTitle className="text-sm">{s.name}</CardTitle>
                      <p className="text-[10px] text-muted-foreground tabular-nums">{s.address}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className={
                        s.status === 'ONLINE' ? 'text-success border-success/30 bg-success/5' :
                        s.status === 'DEGRADED' ? 'text-warning border-warning/30 bg-warning/5' :
                        'text-destructive border-destructive/30 bg-destructive/5'
                      }
                    >
                      {s.status === 'ONLINE' ? 'آنلاین' : s.status === 'DEGRADED' ? 'ضعیف' : 'آفلاین'}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleCheck(s)} disabled={checkingId === s.id}>
                          <RefreshCw className={`h-4 w-4 ml-2 ${checkingId === s.id ? 'animate-spin' : ''}`} />
                          بررسی وضعیت
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setEditTarget(s)}>
                          <Pencil className="h-4 w-4 ml-2" /> ویرایش
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteTarget(s)}>
                          <Trash2 className="h-4 w-4 ml-2" /> حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Resources */}
                {s.cpuUsage !== null && (
                  <div className="grid grid-cols-3 gap-3">
                    <ResourceBar label="CPU" value={s.cpuUsage} icon={<Cpu className="h-3 w-3" />} />
                    <ResourceBar label="RAM" value={s.memUsage ?? 0} icon={<HardDrive className="h-3 w-3" />} />
                    <ResourceBar label="Disk" value={s.diskUsage ?? 0} icon={<HardDrive className="h-3 w-3" />} />
                  </div>
                )}

                {/* Network */}
                {(s.netUpload !== null || s.netDownload !== null) && (
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-2 bg-muted/40 p-2 rounded-md">
                      <ArrowUp className="h-3.5 w-3.5 text-success" />
                      <span className="text-muted-foreground">آپلود</span>
                      <span className="tabular-nums mr-auto font-medium">{s.netUpload?.toFixed(1)} MB/s</span>
                    </div>
                    <div className="flex items-center gap-2 bg-muted/40 p-2 rounded-md">
                      <ArrowDown className="h-3.5 w-3.5 text-chart-2" />
                      <span className="text-muted-foreground">دانلود</span>
                      <span className="tabular-nums mr-auto font-medium">{s.netDownload?.toFixed(1)} MB/s</span>
                    </div>
                  </div>
                )}

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2 pt-1 border-t border-border">
                  <Stat label="اینباند" value={formatNumber(s.inboundCount)} icon={<Network className="h-3 w-3" />} />
                  <Stat label="کاربران" value={formatNumber(s.clientCount)} icon={<Activity className="h-3 w-3" />} />
                  <Stat label="ترافیک" value={formatBytes(Number(s.total))} icon={<ServerIcon className="h-3 w-3" />} />
                </div>

                {s.uptime !== null && (
                  <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>آپ‌تایم: {formatUptime(s.uptime)}</span>
                    {s.lastCheckedAt && (
                      <span className="mr-auto">آخرین بررسی: {timeAgo(s.lastCheckedAt)}</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent className="max-w-lg">
          {editTarget && <EditServerDialog server={editTarget} onSuccess={() => { setEditTarget(null); refetch() }} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف سرور</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف سرور «{deleteTarget?.name}» مطمئن هستید؟ تمام اینباند‌ها و کاربران مرتبط حذف خواهند شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function ResourceBar({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  const colorClass = value > 80 ? 'text-destructive' : value > 60 ? 'text-warning' : 'text-success'
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[10px]">
        <span className="flex items-center gap-1 text-muted-foreground">{icon}{label}</span>
        <span className={`tabular-nums font-medium ${colorClass}`}>{value.toFixed(0)}%</span>
      </div>
      <Progress value={value} className="h-1.5" />
    </div>
  )
}

function Stat({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 text-[10px] text-muted-foreground mb-0.5">{icon}{label}</div>
      <p className="text-sm font-medium tabular-nums">{value}</p>
    </div>
  )
}

function flagEmoji(code: string): string {
  if (!code || code.length !== 2) return '🌐'
  const base = 0x1f1e6
  const A = 'A'.charCodeAt(0)
  return String.fromCodePoint(base + (code.toUpperCase().charCodeAt(0) - A)) +
         String.fromCodePoint(base + (code.toUpperCase().charCodeAt(1) - A))
}

function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  if (days > 0) return `${days} روز و ${hours} ساعت`
  if (hours > 0) return `${hours} ساعت`
  return `${Math.floor(seconds / 60)} دقیقه`
}

function CreateServerDialog({ onSuccess }: { onSuccess: () => void }) {
  const [form, setForm] = useState({
    name: '', address: '', apiHost: '', apiPort: 2053, apiUser: '', apiPass: '', apiPath: '/',
    country: '', flag: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    if (!form.name.trim() || !form.address.trim()) return setError('نام و آدرس الزامی هستند')
    setLoading(true)
    setError(null)
    const res = await apiFetch('/api/servers', { method: 'POST', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('سرور با موفقیت اضافه شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Plus className="h-4 w-4 text-primary" /> افزودن سرور جدید</DialogTitle>
        <DialogDescription>یک سرور VPN جدید به پنل اضافه کنید</DialogDescription>
      </DialogHeader>
      <div className="space-y-3 py-2 max-h-[60vh] overflow-y-auto pl-1">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>نام</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="سرور فرانکفورت" />
          </div>
          <div className="space-y-2">
            <Label>کشور (کد ۲ حرفی)</Label>
            <Input value={form.flag} onChange={(e) => setForm({ ...form, flag: e.target.value.toLowerCase(), country: e.target.value })} placeholder="de" maxLength={2} />
          </div>
        </div>
        <div className="space-y-2">
          <Label>آدرس سرور</Label>
          <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value, apiHost: e.target.value })} placeholder="185.94.10.20 یا domain.com" />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="space-y-2">
            <Label>API پورت</Label>
            <Input type="number" value={form.apiPort} onChange={(e) => setForm({ ...form, apiPort: parseInt(e.target.value, 10) || 0 })} />
          </div>
          <div className="space-y-2 col-span-2">
            <Label>API مسیر</Label>
            <Input value={form.apiPath} onChange={(e) => setForm({ ...form, apiPath: e.target.value })} placeholder="/" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>API کاربر</Label>
            <Input value={form.apiUser} onChange={(e) => setForm({ ...form, apiUser: e.target.value })} placeholder="اختیاری" />
          </div>
          <div className="space-y-2">
            <Label>API رمز</Label>
            <Input type="password" value={form.apiPass} onChange={(e) => setForm({ ...form, apiPass: e.target.value })} placeholder="اختیاری" />
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md border border-destructive/20">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال افزودن...' : 'افزودن سرور'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}

function EditServerDialog({ server, onSuccess }: { server: Server; onSuccess: () => void }) {
  const [form, setForm] = useState({
    name: server.name, address: server.address, country: server.country ?? '', flag: server.flag ?? '',
    apiUser: server.apiUser ?? '', apiPath: server.apiPath,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function submit() {
    setLoading(true)
    setError(null)
    const res = await apiFetch(`/api/servers/${server.id}`, { method: 'PATCH', body: form })
    setLoading(false)
    if (res.ok) {
      toast.success('سرور به‌روزرسانی شد')
      onSuccess()
    } else {
      setError(res.error)
    }
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2"><Pencil className="h-4 w-4 text-primary" /> ویرایش سرور</DialogTitle>
        <DialogDescription>{server.name}</DialogDescription>
      </DialogHeader>
      <div className="space-y-3 py-2">
        <div className="space-y-2">
          <Label>نام</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>آدرس</Label>
          <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>کد کشور</Label>
            <Input value={form.flag} onChange={(e) => setForm({ ...form, flag: e.target.value.toLowerCase(), country: e.target.value })} maxLength={2} />
          </div>
          <div className="space-y-2">
            <Label>API کاربر</Label>
            <Input value={form.apiUser} onChange={(e) => setForm({ ...form, apiUser: e.target.value })} />
          </div>
        </div>
        {error && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{error}</div>}
      </div>
      <DialogFooter>
        <Button onClick={submit} disabled={loading}>{loading ? 'در حال ذخیره...' : 'ذخیره'}</Button>
      </DialogFooter>
    </DialogContent>
  )
}
