'use client'

import { useApi, apiFetch } from '@/lib/use-api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'
import { ShieldCheck, ShieldAlert, KeyRound, Smartphone, Lock, Fingerprint, AlertTriangle, Activity, Eye, EyeOff, Plus, X, Check, Copy } from 'lucide-react'
import { useState } from 'react'
import { QRCode } from '@/components/qr-code'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'

interface SecurityOverview {
  stats: {
    activeSessions: number
    loginFailures24h: number
    loginAttempts24h: number
    ipWhitelistCount: number
    twoFactorEnabled: boolean
  }
}

export function SecurityView() {
  const admin = useAppStore((s) => s.admin)
  const [show2FASetup, setShow2FASetup] = useState(false)

  const { data, loading, refetch } = useApi<SecurityOverview & {
    stats: { activeSessions: number; loginFailures24h: number; loginAttempts24h: number; ipWhitelistCount: number }
    twoFactor: { enabled: boolean; backupCodesRemaining: number; lastUsed: string | null }
  }>('/api/security/overview')

  // 2FA setup state
  const [twoFAStep, setTwoFAStep] = useState<'password' | 'qr' | 'verify' | 'backup'>('password')
  const [password, setPassword] = useState('')
  const [secret, setSecret] = useState('')
  const [qrUri, setQrUri] = useState('')
  const [verifyCode, setVerifyCode] = useState('')
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [setupLoading, setSetupLoading] = useState(false)
  const [setupError, setSetupError] = useState<string | null>(null)

  async function start2FASetup() {
    setSetupLoading(true)
    setSetupError(null)
    const res = await apiFetch<{ secret: string; uri: string; qrData: string }>('/api/auth/2fa-setup', {
      method: 'POST',
      body: { password },
    })
    setSetupLoading(false)
    if (res.ok) {
      setSecret(res.data.secret)
      setQrUri(res.data.qrData)
      setTwoFAStep('qr')
    } else {
      setSetupError(res.error)
    }
  }

  async function verify2FACode() {
    setSetupLoading(true)
    setSetupError(null)
    const res = await apiFetch<{ ok: boolean; backupCodes: string[] }>('/api/auth/2fa-setup', {
      method: 'PUT',
      body: { secret, code: verifyCode },
    })
    setSetupLoading(false)
    if (res.ok) {
      setBackupCodes(res.data.backupCodes)
      setTwoFAStep('backup')
      toast.success('احراز هویت دومرحله‌ای فعال شد')
    } else {
      setSetupError(res.error)
    }
  }

  function copySecret() {
    navigator.clipboard.writeText(secret)
    toast.success('کلید مخفی کپی شد')
  }

  const twoFAEnabled = admin?.twoFactorEnabled ?? false

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          امنیت حساب
        </h2>
        <p className="text-xs text-muted-foreground mt-0.5">مدیریت احراز هویت، نشست‌ها و حفاظت حساب</p>
      </div>

      {/* Security score */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-primary" />
            امتیاز امنیتی
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SecurityScore twoFAEnabled={twoFAEnabled} loading={loading} />
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* 2FA card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Fingerprint className="h-4 w-4 text-primary" />
              احراز هویت دومرحله‌ای (2FA)
            </CardTitle>
            <CardDescription className="text-xs">
              افزودن لایه امنیتی اضافی با کد یک‌بارمصرف
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${twoFAEnabled ? 'bg-success/15 text-success' : 'bg-warning/15 text-warning'}`}>
                  {twoFAEnabled ? <Check className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                </div>
                <div>
                  <p className="text-sm font-medium">{twoFAEnabled ? 'فعال' : 'غیرفعال'}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {twoFAEnabled ? 'حساب شما با 2FA محافظت می‌شود' : 'توصیه می‌شود فعال کنید'}
                  </p>
                </div>
              </div>
              <Button
                variant={twoFAEnabled ? 'outline' : 'default'}
                size="sm"
                onClick={() => {
                  if (twoFAEnabled) {
                    // Open disable dialog
                    setShow2FASetup(true)
                    setTwoFAStep('password')
                    setPassword('')
                  } else {
                    setShow2FASetup(true)
                    setTwoFAStep('password')
                    setPassword('')
                  }
                }}
              >
                {twoFAEnabled ? 'مدیریت' : 'فعال‌سازی'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats cards */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              آمار امنیتی ۲۴ ساعت
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Row label="تلاش‌های ورود" value={loading ? '...' : (data?.stats.loginAttempts24h ?? 0)} icon={<KeyRound className="h-3.5 w-3.5" />} />
            <Row label="ورود ناموفق" value={loading ? '...' : (data?.stats.loginFailures24h ?? 0)} icon={<AlertTriangle className="h-3.5 w-3.5" />} danger />
            <Row label="نشست‌های فعال" value={loading ? '...' : (data?.stats.activeSessions ?? 0)} icon={<Smartphone className="h-3.5 w-3.5" />} />
            <Row label="IPهای مجاز" value={loading ? '...' : (data?.stats.ipWhitelistCount ?? 0)} icon={<Lock className="h-3.5 w-3.5" />} />
          </CardContent>
        </Card>
      </div>

      {/* Quick links */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">ابزارهای امنیتی</CardTitle>
          <CardDescription className="text-xs">دسترسی سریع به بخش‌های امنیتی</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <QuickLink icon={Activity} label="لاگ‌های امنیتی" view="audit-logs" />
          <QuickLink icon={Lock} label="لیست سفید IP" view="ip-whitelist" />
          <QuickLink icon={Smartphone} label="نشست‌های فعال" view="sessions" />
          <QuickLink icon={KeyRound} label="تغییر رمز" view="profile" />
        </CardContent>
      </Card>

      {/* 2FA setup dialog */}
      <Dialog open={show2FASetup} onOpenChange={(o) => {
        if (!o) {
          setShow2FASetup(false)
          setTwoFAStep('password')
          setPassword('')
          setSecret('')
          setVerifyCode('')
          setBackupCodes([])
          setSetupError(null)
        }
      }}>
        <DialogContent className="max-w-md">
          {twoFAEnabled ? (
            // Disable 2FA flow
            <>
              <DialogHeader>
                <DialogTitle>غیرفعال‌سازی 2FA</DialogTitle>
                <DialogDescription>برای غیرفعال‌سازی، رمز عبور خود را وارد کنید</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="space-y-2">
                  <Label>رمز عبور</Label>
                  <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
                </div>
                {setupError && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{setupError}</div>}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShow2FASetup(false)}>انصراف</Button>
                <Button
                  variant="destructive"
                  disabled={!password || setupLoading}
                  onClick={async () => {
                    setSetupLoading(true)
                    const res = await apiFetch('/api/auth/2fa-disable', { method: 'POST', body: { password } })
                    setSetupLoading(false)
                    if (res.ok) {
                      toast.success('2FA غیرفعال شد')
                      setShow2FASetup(false)
                      // Refresh admin info
                      const checkRes = await apiFetch<{ authenticated: boolean; admin?: { twoFactorEnabled: boolean } }>('/api/auth/login')
                      if (checkRes.ok && checkRes.data.admin) {
                        useAppStore.getState().setAdmin(checkRes.data.admin as never)
                      }
                    } else {
                      setSetupError(res.error)
                    }
                  }}
                >
                  {setupLoading ? 'در حال غیرفعال‌سازی...' : 'غیرفعال‌سازی'}
                </Button>
              </DialogFooter>
            </>
          ) : twoFAStep === 'password' ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><Fingerprint className="h-4 w-4 text-primary" /> فعال‌سازی 2FA</DialogTitle>
                <DialogDescription>برای امنیت، رمز عبور فعلی خود را وارد کنید</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="space-y-2">
                  <Label>رمز عبور فعلی</Label>
                  <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
                </div>
                {setupError && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{setupError}</div>}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShow2FASetup(false)}>انصراف</Button>
                <Button onClick={start2FASetup} disabled={!password || setupLoading}>
                  {setupLoading ? 'در حال بررسی...' : 'ادامه'}
                </Button>
              </DialogFooter>
            </>
          ) : twoFAStep === 'qr' ? (
            <>
              <DialogHeader>
                <DialogTitle>اسکن QR کد</DialogTitle>
                <DialogDescription>با اپلیکیشن Google Authenticator یا Authy اسکن کنید</DialogDescription>
              </DialogHeader>
              <div className="flex flex-col items-center gap-3 py-2">
                <div className="p-3 bg-white rounded-lg">
                  <QRCode text={qrUri} size={200} />
                </div>
                <div className="w-full">
                  <p className="text-[10px] text-muted-foreground mb-1">یا کلید زیر را دستی وارد کنید:</p>
                  <div className="relative">
                    <Input readOnly value={secret} className="pr-9 font-mono text-xs" />
                    <button className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary" onClick={copySecret}>
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                {setupError && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md w-full">{setupError}</div>}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setTwoFAStep('password')}>قبلی</Button>
                <Button onClick={() => setTwoFAStep('verify')}>ادامه</Button>
              </DialogFooter>
            </>
          ) : twoFAStep === 'verify' ? (
            <>
              <DialogHeader>
                <DialogTitle>تأیید کد</DialogTitle>
                <DialogDescription>کد ۶ رقمی از اپلیکیشن خود را وارد کنید</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="space-y-2">
                  <Label>کد تأیید</Label>
                  <Input
                    inputMode="numeric"
                    maxLength={6}
                    value={verifyCode}
                    onChange={(e) => setVerifyCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="text-center text-lg tracking-[0.4em] font-mono"
                    placeholder="000000"
                    autoFocus
                  />
                </div>
                {setupError && <div className="text-xs text-destructive bg-destructive/10 p-2 rounded-md">{setupError}</div>}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setTwoFAStep('qr')}>قبلی</Button>
                <Button onClick={verify2FACode} disabled={verifyCode.length !== 6 || setupLoading}>
                  {setupLoading ? 'در حال تأیید...' : 'تأیید و فعال‌سازی'}
                </Button>
              </DialogFooter>
            </>
          ) : (
            // Backup codes
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-success">
                  <Check className="h-4 w-4" />
                  2FA فعال شد
                </DialogTitle>
                <DialogDescription>کدهای پشتیبان را در جای امن ذخیره کنید</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <p className="text-xs text-muted-foreground">در صورت از دست دادن تلفن، از این کدها برای ورود استفاده کنید. هر کد فقط یک‌بار قابل استفاده است.</p>
                <div className="grid grid-cols-2 gap-2">
                  {backupCodes.map((c, i) => (
                    <div key={i} className="font-mono text-xs bg-muted/40 p-2 rounded text-center tracking-wider">{c}</div>
                  ))}
                </div>
              </div>
              <DialogFooter>
                <Button onClick={() => {
                  setShow2FASetup(false)
                  setTwoFAStep('password')
                  setPassword('')
                  setSecret('')
                  setVerifyCode('')
                  setBackupCodes([])
                  // Refresh admin
                  apiFetch<{ authenticated: boolean; admin?: { twoFactorEnabled: boolean } }>('/api/auth/login').then(r => {
                    if (r.ok && r.data.admin) {
                      useAppStore.getState().setAdmin(r.data.admin as never)
                    }
                  })
                }}>پایان</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function SecurityScore({ twoFAEnabled, loading }: { twoFAEnabled: boolean; loading: boolean }) {
  // Compute security score
  let score = 30 // base
  if (twoFAEnabled) score += 35
  // Other checks (mock for now)
  score += 20 // strong password assumed
  score += 15 // recent login

  const level = score >= 80 ? 'عالی' : score >= 60 ? 'خوب' : score >= 40 ? 'متوسط' : 'ضعیف'
  const color = score >= 80 ? 'text-success' : score >= 60 ? 'text-primary' : score >= 40 ? 'text-warning' : 'text-destructive'

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-2xl font-bold tabular-nums">{loading ? '...' : score}<span className="text-sm text-muted-foreground">/100</span></span>
        <Badge variant="outline" className={color}>{level}</Badge>
      </div>
      <Progress value={score} className="h-2" />
      <div className="grid grid-cols-2 gap-2 mt-3">
        <CheckItem label="احراز هویت دومرحله‌ای" ok={twoFAEnabled} />
        <CheckItem label="رمز عبور قوی" ok={true} />
        <CheckItem label="نشست‌های امن" ok={true} />
        <CheckItem label="IP Whitelist" ok={false} />
      </div>
    </div>
  )
}

function CheckItem({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      <div className={`w-4 h-4 rounded-full flex items-center justify-center ${ok ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
        {ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
      </div>
      <span className={ok ? '' : 'text-muted-foreground'}>{label}</span>
    </div>
  )
}

function Row({ label, value, icon, danger }: { label: string; value: string | number; icon: React.ReactNode; danger?: boolean }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="flex items-center gap-2 text-muted-foreground">{icon}{label}</span>
      <span className={`tabular-nums font-medium ${danger && Number(value) > 0 ? 'text-destructive' : ''}`}>{value}</span>
    </div>
  )
}

function QuickLink({ icon: Icon, label, view }: { icon: React.ComponentType<{ className?: string }>; label: string; view: 'audit-logs' | 'ip-whitelist' | 'sessions' | 'profile' }) {
  const setView = useAppStore((s) => s.setView)
  return (
    <button
      onClick={() => setView(view)}
      className="flex flex-col items-center gap-2 p-4 rounded-lg bg-muted/40 hover:bg-muted transition-colors text-center"
    >
      <Icon className="h-5 w-5 text-primary" />
      <span className="text-xs">{label}</span>
    </button>
  )
}
