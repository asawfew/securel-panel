'use client'

import { useState, useEffect } from 'react'
import { LoginForm } from '@/components/auth/login-form'
import { Sidebar } from '@/components/panel/sidebar'
import { Header } from '@/components/panel/header'
import { DashboardView } from '@/components/panel/views/dashboard-view'
import { InboundsView } from '@/components/panel/views/inbounds-view'
import { ClientsView } from '@/components/panel/views/clients-view'
import { ServersView } from '@/components/panel/views/servers-view'
import { SecurityView } from '@/components/panel/views/security-view'
import { AuditLogsView } from '@/components/panel/views/audit-logs-view'
import { IpWhitelistView } from '@/components/panel/views/ip-whitelist-view'
import { SessionsView } from '@/components/panel/views/sessions-view'
import { AdminsView } from '@/components/panel/views/admins-view'
import { SettingsView } from '@/components/panel/views/settings-view'
import { ProfileView } from '@/components/panel/views/profile-view'
import { useAppStore } from '@/lib/store'
import { apiFetch } from '@/lib/use-api'
import { Skeleton } from '@/components/ui/skeleton'

export default function Home() {
  const [authChecked, setAuthChecked] = useState(false)
  const [authed, setAuthed] = useState(false)
  const view = useAppStore((s) => s.view)
  const setAdmin = useAppStore((s) => s.setAdmin)

  useEffect(() => {
    checkAuth()
  }, [])

  async function checkAuth() {
    const res = await apiFetch<{ authenticated: boolean; admin?: { id: string; username: string; role: string; twoFactorEnabled: boolean } }>('/api/auth/login')
    if (res.ok && res.data.authenticated && res.data.admin) {
      setAdmin(res.data.admin)
      setAuthed(true)
    }
    setAuthChecked(true)
  }

  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Skeleton className="w-96 h-96 rounded-xl" />
      </div>
    )
  }

  if (!authed) {
    return <LoginForm onAuthed={() => setAuthed(true)} />
  }

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        <Header onLogout={() => {
          setAdmin(null)
          setAuthed(false)
        }} />
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-6">
          <div className="max-w-7xl mx-auto">
            <ViewRouter view={view} />
          </div>
        </main>
      </div>
    </div>
  )
}

function ViewRouter({ view }: { view: string }) {
  switch (view) {
    case 'dashboard': return <DashboardView />
    case 'inbounds': return <InboundsView />
    case 'clients': return <ClientsView />
    case 'servers': return <ServersView />
    case 'security': return <SecurityView />
    case 'audit-logs': return <AuditLogsView />
    case 'ip-whitelist': return <IpWhitelistView />
    case 'sessions': return <SessionsView />
    case 'admins': return <AdminsView />
    case 'settings': return <SettingsView />
    case 'profile': return <ProfileView />
    default: return <DashboardView />
  }
}
