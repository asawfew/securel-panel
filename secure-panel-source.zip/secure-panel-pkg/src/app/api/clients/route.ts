import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson, validate, getQueryInt } from '@/lib/api'
import { randomUuid, randomString } from '@/lib/format'

export const runtime = 'nodejs'

/**
 * GET /api/clients?inboundId=&q=&status=
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const url = new URL(req.url)
  const inboundId = url.searchParams.get('inboundId')
  const q = url.searchParams.get('q')
  const status = url.searchParams.get('status')
  const limit = getQueryInt(req, 'limit', 200)

  const where: Record<string, unknown> = {}
  if (inboundId) where.inboundId = inboundId
  if (q) {
    where.OR = [
      { email: { contains: q } },
      { name: { contains: q } },
      { clientId: { contains: q } },
    ]
  }

  const clients = await db.client.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: {
      inbound: {
        select: {
          id: true, protocol: true, remark: true, port: true,
          server: { select: { id: true, name: true, address: true, country: true, flag: true } },
        },
      },
    },
  })

  const now = Date.now()
  const enriched = clients.map(c => {
    const expiryNum = c.expiryTime ? Number(c.expiryTime) : null
    const totalGBNum = c.totalGB ? Number(c.totalGB) : null
    const usedNum = Number(c.total)
    let statusCalc: 'ACTIVE' | 'EXPIRED' | 'LIMIT_EXCEEDED' | 'DISABLED' = 'ACTIVE'
    if (!c.enable) statusCalc = 'DISABLED'
    else if (expiryNum && expiryNum < now) statusCalc = 'EXPIRED'
    else if (totalGBNum && usedNum >= totalGBNum) statusCalc = 'LIMIT_EXCEEDED'

    return {
      ...c,
      totalGB: c.totalGB?.toString() ?? null,
      expiryTime: c.expiryTime?.toString() ?? null,
      up: c.up.toString(),
      down: c.down.toString(),
      total: c.total.toString(),
      status: statusCalc,
      usedPercent: totalGBNum ? Math.min(100, Math.round((usedNum / totalGBNum) * 1000) / 10) : 0,
      daysLeft: expiryNum ? Math.max(0, Math.ceil((expiryNum - now) / (24 * 60 * 60 * 1000))) : null,
    }
  })

  // Filter by status if requested
  const filtered = status ? enriched.filter(c => c.status === status) : enriched

  return json({ clients: serializeForJson(filtered) })
}

/**
 * POST /api/clients
 * Body: { inboundId, name?, email?, totalGB?, expiryTime?, enable?, resetCycle? }
 */
export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  if (!body.inboundId) return json({ error: 'inboundId الزامی است' }, { status: 400 })

  const inbound = await db.inbound.findUnique({ where: { id: body.inboundId }, include: { server: true } })
  if (!inbound) return json({ error: 'اینباند یافت نشد' }, { status: 404 })

  const clientId = randomUuid()
  const email = body.email || `${randomString(8)}@secure-panel.local`
  // Check email uniqueness within inbound
  const existing = await db.client.findFirst({ where: { inboundId: inbound.id, email } })
  if (existing) return json({ error: 'این ایمیل/شناسه در این اینباند قبلاً ثبت شده' }, { status: 400 })

  // Compute totalGB (input in GB) and expiryTime (input in days)
  const totalGB = (typeof body.totalGB === 'number' && body.totalGB > 0)
    ? BigInt(Math.floor(body.totalGB * 1024 * 1024 * 1024))
    : null
  const expiryTime = (typeof body.expiryDays === 'number' && body.expiryDays > 0)
    ? BigInt(Date.now() + body.expiryDays * 24 * 60 * 60 * 1000)
    : null

  const client = await db.client.create({
    data: {
      inboundId: inbound.id,
      clientId,
      email,
      name: body.name || null,
      totalGB,
      expiryTime,
      enable: body.enable ?? true,
      subId: 'sub_' + randomString(12),
      resetCycle: body.resetCycle ?? 0,
      up: BigInt(0),
      down: BigInt(0),
      total: BigInt(0),
    },
  })

  await auditLog({
    adminId: admin.id,
    action: 'CREATE_CLIENT',
    category: 'CLIENT',
    description: `ایجاد کلاینت ${client.name ?? client.email} روی اینباند ${inbound.remark}`,
    targetType: 'CLIENT',
    targetId: client.id,
    request: req,
    metadata: { inboundId: inbound.id, email },
  })

  // Generate config URL based on protocol
  const link = buildClientLink(inbound, client)

  return json({
    ok: true,
    client: serializeForJson({
      ...client,
      totalGB: client.totalGB?.toString() ?? null,
      expiryTime: client.expiryTime?.toString() ?? null,
      up: client.up.toString(),
      down: client.down.toString(),
      total: client.total.toString(),
    }),
    link,
  })
}

function buildClientLink(inbound: { protocol: string; port: number; remark: string; server: { address: string } }, client: { clientId: string; email: string | null }): string {
  const addr = inbound.server.address
  const port = inbound.port
  const remark = encodeURIComponent(inbound.remark + (client.email ? `-${client.email}` : ''))
  switch (inbound.protocol) {
    case 'vless':
      return `vless://${client.clientId}@${addr}:${port}?type=tcp&security=reality&sni=www.microsoft.com&fp=chrome#${remark}`
    case 'vmess':
      return `vmess://${Buffer.from(JSON.stringify({
        v: '2', ps: inbound.remark, add: addr, port: String(port), id: client.clientId,
        aid: '0', scy: 'auto', net: 'tcp', type: 'none', host: '', path: '', tls: 'tls',
      })).toString('base64')}`
    case 'trojan':
      return `trojan://${client.clientId}@${addr}:${port}?security=tls&sni=${addr}#${remark}`
    case 'shadowsocks':
      return `ss://${Buffer.from(`aes-256-gcm:${client.clientId}`).toString('base64')}@${addr}:${port}#${remark}`
    default:
      return ''
  }
}
