import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/clients/[id]
 */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const client = await db.client.findUnique({
    where: { id },
    include: {
      inbound: {
        select: {
          id: true, protocol: true, remark: true, port: true,
          server: { select: { id: true, name: true, address: true } },
        },
      },
      dailyStats: { orderBy: { date: 'asc' }, take: 30 },
    },
  })
  if (!client) return json({ error: 'کلاینت یافت نشد' }, { status: 404 })

  return json({
    client: serializeForJson({
      ...client,
      totalGB: client.totalGB?.toString() ?? null,
      expiryTime: client.expiryTime?.toString() ?? null,
      up: client.up.toString(),
      down: client.down.toString(),
      total: client.total.toString(),
      dailyStats: client.dailyStats.map(s => ({ ...s, up: s.up.toString(), down: s.down.toString(), total: s.total.toString() })),
    }),
  })
}

/**
 * PATCH /api/clients/[id]
 * Body: { name?, enable?, totalGB?, expiryDays?, resetCycle? }
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const client = await db.client.findUnique({ where: { id } })
  if (!client) return json({ error: 'کلاینت یافت نشد' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, unknown> = {}

  if (typeof body.name === 'string') updates.name = body.name || null
  if (typeof body.enable === 'boolean') updates.enable = body.enable
  if (typeof body.email === 'string' && body.email) updates.email = body.email
  if (typeof body.totalGB === 'number') {
    updates.totalGB = body.totalGB > 0 ? BigInt(Math.floor(body.totalGB * 1024 * 1024 * 1024)) : null
  }
  if (typeof body.expiryDays === 'number') {
    updates.expiryTime = body.expiryDays > 0 ? BigInt(Date.now() + body.expiryDays * 24 * 60 * 60 * 1000) : null
  }
  if (typeof body.resetCycle === 'number') updates.resetCycle = body.resetCycle
  if (typeof body.tgId === 'string') updates.tgId = body.tgId || null

  // Reset traffic if requested
  if (body.resetTraffic === true) {
    updates.up = BigInt(0)
    updates.down = BigInt(0)
    updates.total = BigInt(0)
    updates.lastResetAt = new Date()
  }

  const updated = await db.client.update({ where: { id }, data: updates })

  await auditLog({
    adminId: admin.id,
    action: 'UPDATE_CLIENT',
    category: 'CLIENT',
    description: `به‌روزرسانی کلاینت ${updated.name ?? updated.email}`,
    targetType: 'CLIENT',
    targetId: id,
    request: req,
    metadata: { updates: Object.keys(updates) },
  })

  return json({ ok: true, client: serializeForJson({ ...updated, totalGB: updated.totalGB?.toString() ?? null, expiryTime: updated.expiryTime?.toString() ?? null, up: updated.up.toString(), down: updated.down.toString(), total: updated.total.toString() }) })
}

/**
 * DELETE /api/clients/[id]
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const client = await db.client.findUnique({ where: { id } })
  if (!client) return json({ error: 'کلاینت یافت نشد' }, { status: 404 })

  await db.client.delete({ where: { id } })

  await auditLog({
    adminId: admin.id,
    action: 'DELETE_CLIENT',
    category: 'CLIENT',
    description: `حذف کلاینت ${client.name ?? client.email}`,
    targetType: 'CLIENT',
    targetId: id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true })
}
