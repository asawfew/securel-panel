import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/dashboard
 * Aggregated stats for the dashboard.
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const url = new URL(req.url)
  const days = parseInt(url.searchParams.get('days') ?? '14', 10) || 14

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
  since.setHours(0, 0, 0, 0)

  const [
    servers,
    inbounds,
    clients,
    auditLogs,
    trafficStats,
    loginAttempts,
    loginFailures24h,
    activeSessions,
  ] = await Promise.all([
    db.server.findMany({ select: { id: true, status: true, name: true, address: true, country: true, flag: true, cpuUsage: true, memUsage: true, diskUsage: true, netUpload: true, netDownload: true, uptime: true, lastCheckedAt: true } }),
    db.inbound.findMany({ select: { id: true, protocol: true, remark: true, port: true, enable: true, up: true, down: true, total: true, network: true, tls: true, server: { select: { name: true } } } }),
    db.client.findMany({ select: { id: true, name: true, email: true, totalGB: true, expiryTime: true, up: true, down: true, total: true, enable: true, inboundId: true } }),
    db.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { admin: { select: { username: true } } } }),
    db.trafficStat.findMany({ where: { date: { gte: since } }, orderBy: { date: 'asc' } }),
    db.loginAttempt.count({ where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    db.loginAttempt.count({ where: { success: false, createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    db.session.count({ where: { revoked: false, expiresAt: { gt: new Date() } } }),
  ])

  // Aggregate
  const totalUp = inbounds.reduce((s, i) => s + BigInt(i.up ?? 0n), 0n)
  const totalDown = inbounds.reduce((s, i) => s + BigInt(i.down ?? 0n), 0n)
  const totalTraffic = totalUp + totalDown

  const onlineServers = servers.filter(s => s.status === 'ONLINE').length
  const enabledInbounds = inbounds.filter(i => i.enable).length
  const activeClients = clients.filter(c => {
    if (!c.enable) return false
    if (c.expiryTime && BigInt(c.expiryTime) < BigInt(Date.now())) return false
    if (c.totalGB && BigInt(c.total) >= BigInt(c.totalGB)) return false
    return true
  }).length
  const expiredClients = clients.filter(c => c.expiryTime && BigInt(c.expiryTime) < BigInt(Date.now())).length
  const limitedClients = clients.filter(c => c.totalGB !== null).length
  const unlimitedClients = clients.filter(c => c.totalGB === null).length
  const disabledInbounds = inbounds.length - enabledInbounds

  // Traffic per day for chart
  const trafficByDay = new Map<string, { up: bigint; down: bigint; total: bigint }>()
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    d.setHours(0, 0, 0, 0)
    const key = d.toISOString().slice(0, 10)
    trafficByDay.set(key, { up: 0n, down: 0n, total: 0n })
  }
  for (const ts of trafficStats) {
    const key = ts.date.toISOString().slice(0, 10)
    const cur = trafficByDay.get(key)
    if (cur) {
      cur.up += ts.up
      cur.down += ts.down
      cur.total += ts.total
    }
  }
  const dailyTraffic = Array.from(trafficByDay.entries()).map(([date, vals]) => ({
    date,
    up: Number(vals.up),
    down: Number(vals.down),
    total: Number(vals.total),
  }))

  // Top clients by traffic
  const topClients = [...clients]
    .sort((a, b) => Number((BigInt(b.total ?? 0n)) - BigInt(a.total ?? 0n)))
    .slice(0, 5)
    .map(c => ({
      id: c.id,
      name: c.name ?? c.email ?? '—',
      total: c.total,
      up: c.up,
      down: c.down,
    }))

  // Protocol distribution
  const protocolDist = new Map<string, number>()
  for (const ib of inbounds) {
    protocolDist.set(ib.protocol, (protocolDist.get(ib.protocol) ?? 0) + 1)
  }

  return json(serializeForJson({
    stats: {
      totalServers: servers.length,
      onlineServers,
      totalInbounds: inbounds.length,
      enabledInbounds,
      disabledInbounds,
      totalClients: clients.length,
      activeClients,
      expiredClients,
      limitedClients,
      unlimitedClients,
      totalUp: totalUp.toString(),
      totalDown: totalDown.toString(),
      totalTraffic: totalTraffic.toString(),
      loginAttempts24h: loginAttempts,
      loginFailures24h,
      activeSessions,
    },
    servers: servers.map(s => ({
      ...s,
      up: s.up?.toString?.() ?? '0',
    })),
    dailyTraffic,
    topClients: topClients.map(c => ({ ...c, total: c.total.toString(), up: c.up.toString(), down: c.down.toString() })),
    protocolDistribution: Array.from(protocolDist.entries()).map(([proto, count]) => ({ protocol: proto, count })),
    recentAuditLogs: auditLogs.map(l => ({
      id: l.id,
      action: l.action,
      category: l.category,
      description: l.description,
      status: l.status,
      admin: l.admin?.username ?? 'سیستم',
      ip: l.ip,
      createdAt: l.createdAt,
    })),
  }))
}
