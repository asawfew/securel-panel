import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/servers/[id]
 */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const server = await db.server.findUnique({
    where: { id },
    include: {
      inbounds: {
        select: {
          id: true, protocol: true, remark: true, port: true, enable: true,
          up: true, down: true, total: true, _count: { select: { clients: true } },
        },
      },
    },
  })
  if (!server) return json({ error: 'سرور یافت نشد' }, { status: 404 })

  return json({
    server: serializeForJson({
      ...server,
      inbounds: server.inbounds.map(i => ({
        ...i,
        up: i.up.toString(),
        down: i.down.toString(),
        total: i.total.toString(),
      })),
    }),
  })
}

/**
 * PATCH /api/servers/[id]
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const server = await db.server.findUnique({ where: { id } })
  if (!server) return json({ error: 'سرور یافت نشد' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, unknown> = {}
  for (const k of ['name', 'address', 'apiHost', 'apiUser', 'apiPass', 'apiPath', 'country', 'flag', 'status']) {
    if (typeof body[k] === 'string') updates[k] = body[k] || null
  }
  if (typeof body.apiPort === 'number') updates.apiPort = body.apiPort

  const updated = await db.server.update({ where: { id }, data: updates })

  await auditLog({
    adminId: admin.id,
    action: 'UPDATE_SERVER',
    category: 'SERVER',
    description: `به‌روزرسانی سرور ${updated.name}`,
    targetType: 'SERVER',
    targetId: id,
    request: req,
    metadata: { updates: Object.keys(updates) },
  })

  return json({ ok: true, server: serializeForJson(updated) })
}

/**
 * DELETE /api/servers/[id]
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const server = await db.server.findUnique({ where: { id } })
  if (!server) return json({ error: 'سرور یافت نشد' }, { status: 404 })

  await db.server.delete({ where: { id } })

  await auditLog({
    adminId: admin.id,
    action: 'DELETE_SERVER',
    category: 'SERVER',
    description: `حذف سرور ${server.name} (${server.address})`,
    targetType: 'SERVER',
    targetId: id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true })
}

/**
 * POST /api/servers/[id]/check - simulate connectivity check
 */
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const server = await db.server.findUnique({ where: { id } })
  if (!server) return json({ error: 'سرور یافت نشد' }, { status: 404 })

  // Simulated check - in production this would actually connect to the server
  const isOnline = Math.random() > 0.1
  const updated = await db.server.update({
    where: { id },
    data: {
      status: isOnline ? 'ONLINE' : 'OFFLINE',
      lastCheckedAt: new Date(),
      cpuUsage: isOnline ? Math.random() * 30 + 5 : null,
      memUsage: isOnline ? Math.random() * 50 + 20 : null,
      diskUsage: isOnline ? Math.random() * 40 + 10 : null,
      netUpload: isOnline ? Math.random() * 10 : null,
      netDownload: isOnline ? Math.random() * 20 : null,
      uptime: isOnline ? (server.uptime ?? 0) + Math.floor(Math.random() * 60) : null,
    },
  })

  await auditLog({
    adminId: admin.id,
    action: 'SERVER_CHECK',
    category: 'SERVER',
    description: `بررسی سرور ${server.name} - نتیجه: ${isOnline ? 'آنلاین' : 'آفلاین'}`,
    targetType: 'SERVER',
    targetId: id,
    request: req,
  })

  return json({ ok: true, server: serializeForJson(updated) })
}
