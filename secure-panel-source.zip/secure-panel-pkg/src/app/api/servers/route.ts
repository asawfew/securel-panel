import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson, validate } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/servers
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const servers = await db.server.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { inbounds: true } },
    },
  })

  // Aggregate inbound counts per server
  const enriched = await Promise.all(
    servers.map(async s => {
      const inbounds = await db.inbound.findMany({
        where: { serverId: s.id },
        select: { up: true, down: true, total: true, _count: { select: { clients: true } } },
      })
      const totalUp = inbounds.reduce((acc, i) => acc + i.up, 0n)
      const totalDown = inbounds.reduce((acc, i) => acc + i.down, 0n)
      const totalClients = inbounds.reduce((acc, i) => acc + i._count.clients, 0)
      return {
        ...s,
        inboundCount: inbounds.length,
        clientCount: totalClients,
        up: totalUp.toString(),
        down: totalDown.toString(),
        total: (totalUp + totalDown).toString(),
      }
    })
  )

  return json({ servers: serializeForJson(enriched) })
}

/**
 * POST /api/servers
 * Body: { name, address, apiHost?, apiPort?, apiUser?, apiPass?, apiPath?, country?, flag? }
 */
export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const result = validate(body, {
    name: 'string',
    address: 'string',
    apiHost: 'string?',
    apiPort: 'number?',
    apiUser: 'string?',
    apiPass: 'string?',
    apiPath: 'string?',
    country: 'string?',
    flag: 'string?',
  })
  if (!result.ok) return json({ error: result.error }, { status: 400 })
  const data = result.data

  const server = await db.server.create({
    data: {
      name: data.name as string,
      address: data.address as string,
      apiHost: (data.apiHost as string) || (data.address as string),
      apiPort: (data.apiPort as number) ?? 2053,
      apiUser: (data.apiUser as string) ?? null,
      apiPass: (data.apiPass as string) ?? null,
      apiPath: (data.apiPath as string) || '/',
      country: (data.country as string) ?? null,
      flag: (data.flag as string) ?? null,
      status: 'OFFLINE',
    },
  })

  await auditLog({
    adminId: admin.id,
    action: 'CREATE_SERVER',
    category: 'SERVER',
    description: `افزودن سرور ${server.name} (${server.address})`,
    targetType: 'SERVER',
    targetId: server.id,
    request: req,
  })

  return json({ ok: true, server: serializeForJson(server) })
}
