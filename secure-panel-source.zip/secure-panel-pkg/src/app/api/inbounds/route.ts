import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson, validate, getQueryInt } from '@/lib/api'
import { randomUuid } from '@/lib/format'

export const runtime = 'nodejs'

/**
 * GET /api/inbounds?serverId=&protocol=&q=
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const url = new URL(req.url)
  const serverId = url.searchParams.get('serverId')
  const protocol = url.searchParams.get('protocol')
  const q = url.searchParams.get('q')
  const limit = getQueryInt(req, 'limit', 100)

  const where: Record<string, unknown> = {}
  if (serverId) where.serverId = serverId
  if (protocol) where.protocol = protocol
  if (q) where.remark = { contains: q }

  const inbounds = await db.inbound.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: {
      server: { select: { id: true, name: true, address: true, country: true, flag: true } },
      _count: { select: { clients: true } },
    },
  })

  return json({
    inbounds: serializeForJson(inbounds.map(i => ({
      ...i,
      up: i.up.toString(),
      down: i.down.toString(),
      total: i.total.toString(),
    }))),
  })
}

/**
 * POST /api/inbounds
 * Body: { serverId, protocol, remark, port, network, tls, security, settings?, streamSettings?, enable }
 */
export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const result = validate(body, {
    serverId: 'string',
    protocol: 'string',
    remark: 'string',
    port: 'number',
    network: 'string',
    tls: 'string',
    security: 'string',
    enable: 'boolean?',
  })
  if (!result.ok) return json({ error: result.error }, { status: 400 })
  const data = result.data

  // Validate protocol
  const allowedProtocols = ['vless', 'vmess', 'trojan', 'shadowsocks', 'dokodemo-door', 'socks', 'http', 'wireguard']
  if (!allowedProtocols.includes(data.protocol as string)) {
    return json({ error: 'پروتکل نامعتبر' }, { status: 400 })
  }

  // Validate port
  const port = data.port as number
  if (port < 1 || port > 65535) {
    return json({ error: 'پورت باید بین ۱ و ۶۵۵۳۵ باشد' }, { status: 400 })
  }

  // Check server exists
  const server = await db.server.findUnique({ where: { id: data.serverId as string } })
  if (!server) return json({ error: 'سرور یافت نشد' }, { status: 404 })

  // Check port uniqueness on same server
  const existing = await db.inbound.findFirst({ where: { serverId: server.id, port } })
  if (existing) {
    return json({ error: `پورت ${port} روی این سرور قبلاً استفاده شده` }, { status: 400 })
  }

  // Default settings per protocol
  const defaultSettings = getDefaultSettings(data.protocol as string)
  const settings = (body.settings && typeof body.settings === 'object') ? JSON.stringify(body.settings) : JSON.stringify(defaultSettings)
  const streamSettings = (body.streamSettings && typeof body.streamSettings === 'object')
    ? JSON.stringify(body.streamSettings)
    : JSON.stringify({
        network: data.network,
        security: data.security,
        tlsSettings: data.tls === 'tls' ? { serverName: server.address, minVersion: '1.3', maxVersion: '1.3' } : undefined,
        realitySettings: data.security === 'reality' ? { show: false, dest: 'www.microsoft.com:443', serverNames: ['www.microsoft.com'], shortIds: [randomUuid().slice(0, 8)] } : undefined,
      })

  const inbound = await db.inbound.create({
    data: {
      serverId: server.id,
      ownerId: admin.id,
      protocol: data.protocol as string,
      remark: data.remark as string,
      port,
      network: data.network as string,
      tls: data.tls as string,
      security: data.security as string,
      settings,
      streamSettings,
      sniffing: JSON.stringify({ enabled: true, destOverride: ['http', 'tls', 'quic'] }),
      allocate: JSON.stringify({ strategy: 'always', refresh: 5, concurrency: 3 }),
      enable: data.enable ?? true,
      up: BigInt(0),
      down: BigInt(0),
      total: BigInt(0),
    },
    include: { server: { select: { name: true } } },
  })

  await auditLog({
    adminId: admin.id,
    action: 'CREATE_INBOUND',
    category: 'INBOUND',
    description: `ایجاد اینباند ${data.protocol} با پورت ${port} روی سرور ${server.name}`,
    targetType: 'INBOUND',
    targetId: inbound.id,
    request: req,
    metadata: { protocol: data.protocol, port, serverId: server.id },
  })

  return json({ ok: true, inbound: serializeForJson({ ...inbound, up: inbound.up.toString(), down: inbound.down.toString(), total: inbound.total.toString() }) })
}

function getDefaultSettings(protocol: string): Record<string, unknown> {
  switch (protocol) {
    case 'vless':
      return { clients: [], decryption: 'none', fallbacks: [] }
    case 'vmess':
      return { clients: [] }
    case 'trojan':
      return { clients: [] }
    case 'shadowsocks':
      return { method: 'aes-256-gcm', password: randomUuid(), network: 'tcp,udp' }
    case 'dokodemo-door':
      return { address: '', port: 0, network: 'tcp,udp', followRedirect: false }
    case 'socks':
      return { auth: 'noauth', udp: true, user: null, pass: null }
    case 'http':
      return { accounts: [], timeout: 0, allowTransparent: false, userLevel: 0 }
    default:
      return {}
  }
}
