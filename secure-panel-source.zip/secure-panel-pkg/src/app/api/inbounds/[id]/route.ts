import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/inbounds/[id]
 */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const inbound = await db.inbound.findUnique({
    where: { id },
    include: {
      server: { select: { id: true, name: true, address: true, country: true, flag: true } },
      clients: {
        orderBy: { createdAt: 'desc' },
      },
    },
  })
  if (!inbound) return json({ error: 'اینباند یافت نشد' }, { status: 404 })

  return json({
    inbound: serializeForJson({
      ...inbound,
      up: inbound.up.toString(),
      down: inbound.down.toString(),
      total: inbound.total.toString(),
      clients: inbound.clients.map(c => ({
        ...c,
        totalGB: c.totalGB?.toString() ?? null,
        expiryTime: c.expiryTime?.toString() ?? null,
        up: c.up.toString(),
        down: c.down.toString(),
        total: c.total.toString(),
      })),
    }),
  })
}

/**
 * PATCH /api/inbounds/[id]
 * Body: { remark?, enable?, port?, ... }
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const inbound = await db.inbound.findUnique({ where: { id } })
  if (!inbound) return json({ error: 'اینباند یافت نشد' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, unknown> = {}
  if (typeof body.remark === 'string') updates.remark = body.remark
  if (typeof body.enable === 'boolean') updates.enable = body.enable
  if (typeof body.port === 'number' && body.port >= 1 && body.port <= 65535) {
    if (body.port !== inbound.port) {
      const conflict = await db.inbound.findFirst({ where: { serverId: inbound.serverId, port: body.port, NOT: { id } } })
      if (conflict) return json({ error: `پورت ${body.port} قبلاً استفاده شده` }, { status: 400 })
      updates.port = body.port
    }
  }
  if (typeof body.network === 'string') updates.network = body.network
  if (typeof body.tls === 'string') updates.tls = body.tls
  if (typeof body.security === 'string') updates.security = body.security
  if (body.settings && typeof body.settings === 'object') updates.settings = JSON.stringify(body.settings)
  if (body.streamSettings && typeof body.streamSettings === 'object') updates.streamSettings = JSON.stringify(body.streamSettings)
  if (body.sniffing && typeof body.sniffing === 'object') updates.sniffing = JSON.stringify(body.sniffing)

  const updated = await db.inbound.update({
    where: { id },
    data: updates,
  })

  await auditLog({
    adminId: admin.id,
    action: 'UPDATE_INBOUND',
    category: 'INBOUND',
    description: `به‌روزرسانی اینباند ${updated.remark}`,
    targetType: 'INBOUND',
    targetId: id,
    request: req,
    metadata: { updates: Object.keys(updates) },
  })

  return json({ ok: true, inbound: serializeForJson({ ...updated, up: updated.up.toString(), down: updated.down.toString(), total: updated.total.toString() }) })
}

/**
 * DELETE /api/inbounds/[id]
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const inbound = await db.inbound.findUnique({ where: { id } })
  if (!inbound) return json({ error: 'اینباند یافت نشد' }, { status: 404 })

  await db.inbound.delete({ where: { id } })

  await auditLog({
    adminId: admin.id,
    action: 'DELETE_INBOUND',
    category: 'INBOUND',
    description: `حذف اینباند ${inbound.remark} (${inbound.protocol}/${inbound.port})`,
    targetType: 'INBOUND',
    targetId: id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true })
}
