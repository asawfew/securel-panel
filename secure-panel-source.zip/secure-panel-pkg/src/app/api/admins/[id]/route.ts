import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword } from '@/lib/crypto'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * PATCH /api/admins/[id]
 * Body: { role?, resetPassword?, unlockAccount? }
 * Only SUPER_ADMIN can edit other admins.
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })
  if (admin.role !== 'SUPER_ADMIN') {
    return json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const { id } = await params
  const target = await db.admin.findUnique({ where: { id } })
  if (!target) return json({ error: 'ادمین یافت نشد' }, { status: 404 })

  // Prevent self-demotion if last super admin
  if (admin.id === id && target.role === 'SUPER_ADMIN') {
    const superCount = await db.admin.count({ where: { role: 'SUPER_ADMIN' } })
    if (superCount === 1) {
      return json({ error: 'نمی‌توان آخرین ادمین ارشد را ویرایش کرد' }, { status: 400 })
    }
  }

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, unknown> = {}

  if (typeof body.role === 'string' && ['SUPER_ADMIN', 'ADMIN', 'OPERATOR', 'AUDITOR'].includes(body.role)) {
    updates.role = body.role
  }
  if (typeof body.resetPassword === 'string' && body.resetPassword.length >= 12) {
    updates.passwordHash = hashPassword(body.resetPassword)
    updates.failedAttempts = 0
    updates.lockedUntil = null
  }
  if (body.unlockAccount === true) {
    updates.failedAttempts = 0
    updates.lockedUntil = null
  }
  if (typeof body.disable2FA === 'boolean' && body.disable2FA === true) {
    updates.twoFactorSecret = null
    updates.twoFactorEnabled = false
    updates.backupCodes = null
  }

  const updated = await db.admin.update({
    where: { id },
    data: updates,
    select: { id: true, username: true, role: true, twoFactorEnabled: true, failedAttempts: true, lockedUntil: true, updatedAt: true },
  })

  // If password was reset, revoke all sessions
  if (body.resetPassword) {
    await db.session.updateMany({
      where: { adminId: id, revoked: false },
      data: { revoked: true },
    })
  }

  await auditLog({
    adminId: admin.id,
    action: 'UPDATE_ADMIN',
    category: 'SECURITY',
    description: `به‌روزرسانی ادمین ${target.username} - ${Object.keys(updates).join(', ')}`,
    targetType: 'ADMIN',
    targetId: id,
    status: 'WARNING',
    request: req,
    metadata: { updates: Object.keys(updates) },
  })

  return json({ ok: true, admin: serializeForJson(updated) })
}

/**
 * DELETE /api/admins/[id]
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })
  if (admin.role !== 'SUPER_ADMIN') {
    return json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const { id } = await params
  const target = await db.admin.findUnique({ where: { id } })
  if (!target) return json({ error: 'ادمین یافت نشد' }, { status: 404 })

  if (admin.id === id) {
    return json({ error: 'نمی‌توان خودتان را حذف کنید' }, { status: 400 })
  }

  if (target.role === 'SUPER_ADMIN') {
    const superCount = await db.admin.count({ where: { role: 'SUPER_ADMIN' } })
    if (superCount === 1) {
      return json({ error: 'نمی‌توان آخرین ادمین ارشد را حذف کرد' }, { status: 400 })
    }
  }

  await db.admin.delete({ where: { id } })

  await auditLog({
    adminId: admin.id,
    action: 'DELETE_ADMIN',
    category: 'SECURITY',
    description: `حذف ادمین ${target.username}`,
    targetType: 'ADMIN',
    targetId: id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true })
}
