import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, checkPasswordStrength } from '@/lib/crypto'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/admins - only SUPER_ADMIN can list admins
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })
  if (admin.role !== 'SUPER_ADMIN') {
    return json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const admins = await db.admin.findMany({
    select: {
      id: true, username: true, role: true, twoFactorEnabled: true,
      failedAttempts: true, lockedUntil: true, lastLoginAt: true, lastLoginIp: true,
      createdAt: true, updatedAt: true,
    },
    orderBy: { createdAt: 'asc' },
  })

  return json({ admins: serializeForJson(admins) })
}

/**
 * POST /api/admins - create new admin (SUPER_ADMIN only)
 */
export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })
  if (admin.role !== 'SUPER_ADMIN') {
    return json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const body = await req.json().catch(() => ({}))
  if (!body.username || !body.password) {
    return json({ error: 'نام کاربری و رمز عبور الزامی هستند' }, { status: 400 })
  }

  // Validate username (no spaces, min 4 chars, alnum+_-)
  if (!/^[a-zA-Z0-9_-]{4,32}$/.test(body.username)) {
    return json({ error: 'نام کاربری باید ۴ تا ۳۲ کاراکتر و شامل حروف انگلیسی، عدد، خط زیر یا خط تیره باشد' }, { status: 400 })
  }

  const strength = checkPasswordStrength(body.password)
  if (!strength.ok) {
    return json({
      error: 'رمز عبور ضعیف است. باید شامل: ' + strength.reasons.join('، '),
      code: 'WEAK_PASSWORD',
    }, { status: 400 })
  }

  const existing = await db.admin.findUnique({ where: { username: body.username } })
  if (existing) return json({ error: 'نام کاربری قبلاً ثبت شده' }, { status: 400 })

  const allowedRoles = ['SUPER_ADMIN', 'ADMIN', 'OPERATOR', 'AUDITOR']
  const role = allowedRoles.includes(body.role) ? body.role : 'ADMIN'

  const newAdmin = await db.admin.create({
    data: {
      username: body.username,
      passwordHash: hashPassword(body.password),
      role,
      twoFactorEnabled: false,
    },
    select: {
      id: true, username: true, role: true, twoFactorEnabled: true, createdAt: true,
    },
  })

  await auditLog({
    adminId: admin.id,
    action: 'CREATE_ADMIN',
    category: 'SECURITY',
    description: `ایجاد ادمین جدید ${newAdmin.username} با نقش ${newAdmin.role}`,
    targetType: 'ADMIN',
    targetId: newAdmin.id,
    status: 'WARNING',
    request: req,
    metadata: { username: newAdmin.username, role: newAdmin.role },
  })

  return json({ ok: true, admin: serializeForJson(newAdmin) })
}
