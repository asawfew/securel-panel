import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { json, serializeForJson, getQueryInt } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/security/audit-logs?action=&category=&adminId=&page=&limit=
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const url = new URL(req.url)
  const action = url.searchParams.get('action')
  const category = url.searchParams.get('category')
  const adminId = url.searchParams.get('adminId')
  const status = url.searchParams.get('status')
  const page = getQueryInt(req, 'page', 1)
  const limit = Math.min(getQueryInt(req, 'limit', 50), 200)
  const skip = (page - 1) * limit

  const where: Record<string, unknown> = {}
  if (action) where.action = action
  if (category) where.category = category
  if (adminId) where.adminId = adminId
  if (status) where.status = status

  const [logs, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
      include: { admin: { select: { username: true } } },
    }),
    db.auditLog.count({ where }),
  ])

  return json({
    logs: serializeForJson(logs.map(l => ({
      id: l.id,
      action: l.action,
      category: l.category,
      description: l.description,
      status: l.status,
      admin: l.admin?.username ?? 'سیستم',
      ip: l.ip,
      userAgent: l.userAgent,
      createdAt: l.createdAt,
      metadata: l.metadata,
    }))),
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
  })
}
