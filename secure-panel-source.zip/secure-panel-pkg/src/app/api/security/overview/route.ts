import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const [loginAttempts, loginFailures, activeSessions, ipWhitelistCount, adminFull] = await Promise.all([
    db.loginAttempt.count({ where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    db.loginAttempt.count({ where: { success: false, createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    db.session.count({ where: { revoked: false, expiresAt: { gt: new Date() } } }),
    db.ipWhitelist.count(),
    db.admin.findUnique({ where: { id: admin.id }, select: { twoFactorEnabled: true, backupCodes: true } }),
  ])

  return json({
    stats: {
      loginAttempts24h: loginAttempts,
      loginFailures24h: loginFailures,
      activeSessions,
      ipWhitelistCount,
    },
    twoFactor: {
      enabled: adminFull?.twoFactorEnabled ?? false,
      backupCodesRemaining: adminFull?.backupCodes ? adminFull.backupCodes.split(',').filter(Boolean).length : 0,
      lastUsed: null,
    },
  })
}
