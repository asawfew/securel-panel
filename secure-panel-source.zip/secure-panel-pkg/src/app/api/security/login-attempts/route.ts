import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { json, serializeForJson, getQueryInt } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/security/login-attempts
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const limit = Math.min(getQueryInt(req, 'limit', 100), 500)
  const attempts = await db.loginAttempt.findMany({
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return json({ attempts: serializeForJson(attempts) })
}
