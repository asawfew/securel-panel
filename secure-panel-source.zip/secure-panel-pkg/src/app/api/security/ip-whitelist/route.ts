import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/security/ip-whitelist
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const list = await db.ipWhitelist.findMany({ orderBy: { createdAt: 'desc' } })
  return json({ entries: serializeForJson(list) })
}

/**
 * POST /api/security/ip-whitelist
 * Body: { ip, note?, enabled? }
 */
export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  if (!body.ip) return json({ error: 'IP الزامی است' }, { status: 400 })

  // Validate IP/CIDR format
  if (!isValidIpOrCidr(body.ip)) {
    return json({ error: 'فرمت IP یا CIDR نامعتبر است' }, { status: 400 })
  }

  const existing = await db.ipWhitelist.findUnique({ where: { ip: body.ip } })
  if (existing) return json({ error: 'این IP قبلاً ثبت شده' }, { status: 400 })

  const entry = await db.ipWhitelist.create({
    data: {
      ip: body.ip,
      note: body.note || null,
      enabled: body.enabled ?? true,
    },
  })

  await auditLog({
    adminId: admin.id,
    action: 'IP_WHITELIST_ADD',
    category: 'SECURITY',
    description: `افزودن IP ${body.ip} به لیست سفید`,
    targetType: 'IP_WHITELIST',
    targetId: entry.id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true, entry: serializeForJson(entry) })
}

function isValidIpOrCidr(input: string): boolean {
  // CIDR
  if (input.includes('/')) {
    const [ip, bitsStr] = input.split('/')
    const bits = parseInt(bitsStr, 10)
    if (isNaN(bits)) return false
    if (ip.includes(':')) {
      return bits >= 0 && bits <= 128 && isValidIp(ip)
    }
    return bits >= 0 && bits <= 32 && isValidIp(ip)
  }
  return isValidIp(input)
}

function isValidIp(ip: string): boolean {
  // IPv4
  const v4 = ip.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
  if (v4) {
    return v4.slice(1).every(n => parseInt(n, 10) <= 255)
  }
  // IPv6 simplified
  if (ip.includes(':')) {
    return /^[0-9a-fA-F:]+$/.test(ip) && ip.split(':').length <= 8
  }
  return false
}
