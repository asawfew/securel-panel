import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * PATCH /api/security/ip-whitelist/[id] - toggle enabled
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const entry = await db.ipWhitelist.findUnique({ where: { id } })
  if (!entry) return json({ error: 'مدخل یافت نشد' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const updates: Record<string, unknown> = {}
  if (typeof body.enabled === 'boolean') updates.enabled = body.enabled
  if (typeof body.note === 'string') updates.note = body.note || null

  const updated = await db.ipWhitelist.update({ where: { id }, data: updates })

  await auditLog({
    adminId: admin.id,
    action: 'IP_WHITELIST_UPDATE',
    category: 'SECURITY',
    description: `به‌روزرسانی IP ${entry.ip} - فعال: ${updated.enabled}`,
    targetType: 'IP_WHITELIST',
    targetId: id,
    request: req,
  })

  return json({ ok: true, entry: updated })
}

/**
 * DELETE /api/security/ip-whitelist/[id]
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const { id } = await params
  const entry = await db.ipWhitelist.findUnique({ where: { id } })
  if (!entry) return json({ error: 'مدخل یافت نشد' }, { status: 404 })

  await db.ipWhitelist.delete({ where: { id } })

  await auditLog({
    adminId: admin.id,
    action: 'IP_WHITELIST_REMOVE',
    category: 'SECURITY',
    description: `حذف IP ${entry.ip} از لیست سفید`,
    targetType: 'IP_WHITELIST',
    targetId: id,
    status: 'WARNING',
    request: req,
  })

  return json({ ok: true })
}
