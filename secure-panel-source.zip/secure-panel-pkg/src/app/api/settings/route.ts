import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/settings - all settings grouped by category
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const settings = await db.setting.findMany()
  const grouped: Record<string, Record<string, string>> = {}
  for (const s of settings) {
    if (!grouped[s.category]) grouped[s.category] = {}
    grouped[s.category][s.key] = s.value
  }

  return json({ settings: grouped, flat: serializeForJson(settings) })
}

/**
 * PATCH /api/settings - update multiple settings
 * Body: { settings: { key: value, ... } }
 */
export async function PATCH(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const updates = body.settings
  if (!updates || typeof updates !== 'object') {
    return json({ error: 'فرمت درخواست نامعتبر' }, { status: 400 })
  }

  const allowedKeys = new Set([
    'panel.title', 'panel.subtitle', 'panel.theme', 'panel.language',
    'security.ip_whitelist_enabled', 'security.session_timeout',
    'security.min_password_length', 'security.max_login_attempts',
    'security.lock_duration', 'security.rate_limit_per_hour',
    'security.audit_log_retention_days',
  ])

  const updated: string[] = []
  for (const [key, value] of Object.entries(updates)) {
    if (!allowedKeys.has(key)) continue
    const existing = await db.setting.findUnique({ where: { key } })
    if (existing) {
      await db.setting.update({ where: { key }, data: { value: String(value), updatedBy: admin.id } })
    } else {
      const category = key.split('.')[0].toUpperCase()
      await db.setting.create({ data: { key, value: String(value), category, updatedBy: admin.id } })
    }
    updated.push(key)
  }

  await auditLog({
    adminId: admin.id,
    action: 'SETTINGS_UPDATED',
    category: 'SETTINGS',
    description: `به‌روزرسانی ${updated.length} تنظیم: ${updated.join(', ')}`,
    request: req,
    metadata: { keys: updated },
  })

  return json({ ok: true, updated })
}
