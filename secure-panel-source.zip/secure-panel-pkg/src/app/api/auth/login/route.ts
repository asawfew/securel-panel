import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword } from '@/lib/crypto'
import { verifyTotp } from '@/lib/totp'
import { createSession, getClientIp, getUserAgent } from '@/lib/session'
import { auditLog, checkLoginRateLimit, recordLoginAttempt, recordFailedLogin, recordSuccessfulLogin, checkAccountLock } from '@/lib/audit'
import { json, validate } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * POST /api/auth/login
 * Body: { username, password, totpCode? }
 */
export async function POST(req: Request) {
  try {
    const ip = getClientIp(req)
    const userAgent = getUserAgent(req)
    const body = await req.json().catch(() => ({}))
    const result = validate(body, { username: 'string', password: 'string', totpCode: 'string?' })
    if (!result.ok) {
      return json({ error: result.error }, { status: 400 })
    }
    const data = result.data
    const username = data.username as string
    const password = data.password as string
    const totpCode = data.totpCode as string | undefined

    // 1. Rate limit check
    const rl = await checkLoginRateLimit(ip, username)
    if (!rl.allowed) {
      await auditLog({
        action: 'LOGIN_RATE_LIMITED',
        category: 'AUTH',
        description: `تلاش ورود مسدود شده به دلیل محدودیت نرخ - کاربر: ${username}`,
        status: 'WARNING',
        request: req,
        metadata: { username, ip },
      })
      return json({
        error: `تعداد تلاش‌های ورود بیش از حد مجاز است. لطفاً ${Math.ceil(rl.retryAfterSec / 60)} دقیقه بعد تلاش کنید.`,
        code: 'RATE_LIMITED',
        retryAfter: rl.retryAfterSec,
      }, { status: 429 })
    }

    // 2. Find admin
    const admin = await db.admin.findUnique({ where: { username } })
    if (!admin) {
      await recordLoginAttempt(ip, username, false, userAgent)
      await auditLog({
        action: 'LOGIN_FAILED',
        category: 'AUTH',
        description: `ورود ناموفق - کاربر ناموجود: ${username}`,
        status: 'FAILURE',
        request: req,
        metadata: { username },
      })
      return json({ error: 'نام کاربری یا رمز عبور اشتباه است' }, { status: 401 })
    }

    // 3. Account lock check
    const lock = await checkAccountLock(admin.id)
    if (lock.locked) {
      await recordLoginAttempt(ip, username, false, userAgent)
      await auditLog({
        adminId: admin.id,
        action: 'LOGIN_LOCKED',
        category: 'AUTH',
        description: `تلاش ورود روی حساب قفل شده - ${Math.ceil((lock.unlockIn ?? 0) / 60)} دقیقه تا آزاد شدن`,
        status: 'WARNING',
        request: req,
      })
      return json({
        error: `حساب شما به دلیل تلاش‌های ناموفق متعدد قفل شده است. ${Math.ceil((lock.unlockIn ?? 0) / 60)} دقیقه دیگر تلاش کنید.`,
        code: 'ACCOUNT_LOCKED',
        unlockIn: lock.unlockIn,
      }, { status: 423 })
    }

    // 4. Password check
    if (!verifyPassword(password, admin.passwordHash)) {
      await recordLoginAttempt(ip, username, false, userAgent)
      await recordFailedLogin(admin.id)
      await auditLog({
        adminId: admin.id,
        action: 'LOGIN_FAILED',
        category: 'AUTH',
        description: `ورود ناموفق - رمز عبور اشتباه برای ${username}`,
        status: 'FAILURE',
        request: req,
      })
      return json({ error: 'نام کاربری یا رمز عبور اشتباه است' }, { status: 401 })
    }

    // 5. 2FA check
    if (admin.twoFactorEnabled && admin.twoFactorSecret) {
      if (!totpCode) {
        return json({
          requiresTwoFactor: true,
          message: 'کد تأیید دومرحله‌ای را وارد کنید',
        })
      }
      if (!verifyTotp(totpCode, admin.twoFactorSecret)) {
        await recordLoginAttempt(ip, username, false, userAgent)
        await recordFailedLogin(admin.id)
        await auditLog({
          adminId: admin.id,
          action: 'LOGIN_2FA_FAILED',
          category: 'AUTH',
          description: `کد 2FA اشتباه برای ${username}`,
          status: 'FAILURE',
          request: req,
        })
        return json({ error: 'کد تأیید دومرحله‌ای اشتباه است' }, { status: 401 })
      }
    }

    // 6. Create session
    await createSession(admin.id, ip, userAgent)
    await recordLoginAttempt(ip, username, true, userAgent)
    await recordSuccessfulLogin(admin.id, ip)
    await auditLog({
      adminId: admin.id,
      action: 'LOGIN_SUCCESS',
      category: 'AUTH',
      description: `ورود موفق: ${username}`,
      request: req,
    })

    return json({
      ok: true,
      admin: {
        id: admin.id,
        username: admin.username,
        role: admin.role,
        twoFactorEnabled: admin.twoFactorEnabled,
      },
    })
  } catch (e) {
    console.error('Login error:', e)
    return json({ error: 'خطای سرور' }, { status: 500 })
  }
}

/**
 * GET /api/auth/login - check current auth status
 */
export async function GET(req: Request) {
  const { getAuthenticatedAdmin } = await import('@/lib/session')
  const admin = await getAuthenticatedAdmin()
  if (!admin) {
    return json({ authenticated: false })
  }
  return json({ authenticated: true, admin })
}
