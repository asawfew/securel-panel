import { NextResponse } from 'next/server'
import { destroySession, getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

export async function POST(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (admin) {
    await auditLog({
      adminId: admin.id,
      action: 'LOGOUT',
      category: 'AUTH',
      description: `خروج از حساب: ${admin.username}`,
      request: req,
    })
  }
  await destroySession()
  return json({ ok: true })
}
