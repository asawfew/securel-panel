import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword } from '@/lib/crypto'
import { verifyTotp, generateTotpSecret, buildTotpUri, generateBackupCodes, hashBackupCodes } from '@/lib/totp'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * POST /api/auth/2fa-setup
 * Body: { password }
 * Returns: { secret, uri, qrData } to be displayed as QR code
 */
export async function POST(req: Request) {
  try {
    const admin = await getAuthenticatedAdmin()
    if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

    const body = await req.json().catch(() => ({}))
    if (!body.password) return json({ error: 'رمز عبور الزامی است' }, { status: 400 })

    const fullAdmin = await db.admin.findUnique({ where: { id: admin.id } })
    if (!fullAdmin) return json({ error: 'کاربر یافت نشد' }, { status: 404 })

    if (!verifyPassword(body.password, fullAdmin.passwordHash)) {
      await auditLog({
        adminId: admin.id,
        action: '2FA_SETUP_FAILED',
        category: 'SECURITY',
        description: 'تلاش ناموفق فعال‌سازی 2FA - رمز عبور اشتباه',
        status: 'FAILURE',
        request: req,
      })
      return json({ error: 'رمز عبور اشتباه است' }, { status: 401 })
    }

    // Generate new secret (don't save yet - need verification first)
    const secret = generateTotpSecret()
    const uri = buildTotpUri(secret, admin.username, 'SecurePanel')

    return json({
      secret,
      uri,
      qrData: uri,
    })
  } catch (e) {
    console.error('2FA setup error:', e)
    return json({ error: 'خطای سرور' }, { status: 500 })
  }
}

/**
 * POST /api/auth/2fa-setup/verify
 * Body: { secret, code }
 * Saves the secret and enables 2FA.
 */
export async function PUT(req: Request) {
  try {
    const admin = await getAuthenticatedAdmin()
    if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

    const body = await req.json().catch(() => ({}))
    const { secret, code } = body
    if (!secret || !code) return json({ error: 'secret و code الزامی هستند' }, { status: 400 })

    if (!verifyTotp(code, secret)) {
      return json({ error: 'کد تأیید اشتباه است' }, { status: 400 })
    }

    // Generate backup codes
    const backupCodes = generateBackupCodes()
    const backupCodesHash = hashBackupCodes(backupCodes)

    await db.admin.update({
      where: { id: admin.id },
      data: {
        twoFactorSecret: secret,
        twoFactorEnabled: true,
        backupCodes: backupCodesHash,
      },
    })

    await auditLog({
      adminId: admin.id,
      action: '2FA_ENABLED',
      category: 'SECURITY',
      description: 'احراز هویت دو مرحله‌ای فعال شد',
      request: req,
    })

    return json({ ok: true, backupCodes })
  } catch (e) {
    console.error('2FA verify error:', e)
    return json({ error: 'خطای سرور' }, { status: 500 })
  }
}
