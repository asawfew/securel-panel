import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword } from '@/lib/crypto'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * POST /api/auth/2fa-disable
 * Body: { password }
 */
export async function POST(req: Request) {
  try {
    const admin = await getAuthenticatedAdmin()
    if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

    const body = await req.json().catch(() => ({}))
    if (!body.password) return json({ error: 'رمز عبور الزامی است' }, { status: 400 })

    const fullAdmin = await db.admin.findUnique({ where: { id: admin.id } })
    if (!fullAdmin) return json({ error: 'کاربر یافت نشد' }, { status: 404 })

    if (!verifyPassword(body.password, fullAdmin.passwordHash)) {
      await auditLog({
        adminId: admin.id,
        action: '2FA_DISABLE_FAILED',
        category: 'SECURITY',
        description: 'تلاش ناموفق غیرفعال‌سازی 2FA - رمز عبور اشتباه',
        status: 'FAILURE',
        request: req,
      })
      return json({ error: 'رمز عبور اشتباه است' }, { status: 401 })
    }

    await db.admin.update({
      where: { id: admin.id },
      data: {
        twoFactorSecret: null,
        twoFactorEnabled: false,
        backupCodes: null,
      },
    })

    await auditLog({
      adminId: admin.id,
      action: '2FA_DISABLED',
      category: 'SECURITY',
      description: 'احراز هویت دو مرحله‌ای غیرفعال شد',
      status: 'WARNING',
      request: req,
    })

    return json({ ok: true })
  } catch (e) {
    console.error('2FA disable error:', e)
    return json({ error: 'خطای سرور' }, { status: 500 })
  }
}
