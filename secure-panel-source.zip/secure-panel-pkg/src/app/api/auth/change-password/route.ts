import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'
import { verifyPassword, hashPassword, checkPasswordStrength } from '@/lib/crypto'
import { getAuthenticatedAdmin, SESSION_COOKIE } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * POST /api/auth/change-password
 * Body: { currentPassword, newPassword }
 */
export async function POST(req: Request) {
  try {
    const admin = await getAuthenticatedAdmin()
    if (!admin) {
      console.error('[change-password] No authenticated admin found')
      return json({ error: 'احراز هویت نشده. لطفاً دوباره وارد شوید.', code: 'UNAUTHORIZED' }, { status: 401 })
    }

    const body = await req.json().catch(() => ({}))
    const { currentPassword, newPassword } = body
    if (!currentPassword || !newPassword) {
      return json({ error: 'هر دو رمز عبور الزامی هستند' }, { status: 400 })
    }

    const strength = checkPasswordStrength(newPassword)
    if (!strength.ok) {
      return json({
        error: 'رمز عبور ضعیف است. باید شامل موارد زیر باشد: ' + strength.reasons.join('، '),
        code: 'WEAK_PASSWORD',
      }, { status: 400 })
    }

    const fullAdmin = await db.admin.findUnique({ where: { id: admin.id } })
    if (!fullAdmin) return json({ error: 'کاربر یافت نشد' }, { status: 404 })

    if (!verifyPassword(currentPassword, fullAdmin.passwordHash)) {
      await auditLog({
        adminId: admin.id,
        action: 'PASSWORD_CHANGE_FAILED',
        category: 'SECURITY',
        description: 'تلاش ناموفق تغییر رمز عبور - رمز فعلی اشتباه',
        status: 'FAILURE',
        request: req,
      })
      return json({ error: 'رمز عبور فعلی اشتباه است' }, { status: 401 })
    }

    const newHash = hashPassword(newPassword)
    await db.admin.update({
      where: { id: admin.id },
      data: { passwordHash: newHash },
    })

    // Revoke all OTHER sessions (keep current session alive)
    // Get the current session token from the cookie
    const cookieStore = await cookies()
    const currentToken = cookieStore.get(SESSION_COOKIE)?.value

    await db.session.updateMany({
      where: {
        adminId: admin.id,
        revoked: false,
        token: { not: currentToken ?? '' },
      },
      data: { revoked: true },
    })

    await auditLog({
      adminId: admin.id,
      action: 'PASSWORD_CHANGED',
      category: 'SECURITY',
      description: 'رمز عبور با موفقیت تغییر کرد - نشست‌های دیگر لغو شدند',
      request: req,
    })

    return json({ ok: true })
  } catch (e) {
    console.error('Change password error:', e)
    return json({ error: 'خطای سرور' }, { status: 500 })
  }
}
