import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthenticatedAdmin } from '@/lib/session'
import { auditLog } from '@/lib/audit'
import { json, serializeForJson } from '@/lib/api'

export const runtime = 'nodejs'

/**
 * GET /api/auth/sessions - list current admin's active sessions
 */
export async function GET(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const sessions = await db.session.findMany({
    where: { adminId: admin.id, revoked: false, expiresAt: { gt: new Date() } },
    orderBy: { lastUsedAt: 'desc' },
  })

  // Get current session token from cookie
  const { cookies } = await import('next/headers')
  const cookieStore = await cookies()
  const currentToken = cookieStore.get('sp_session')?.value

  return json({
    sessions: serializeForJson(sessions.map(s => ({
      id: s.id,
      ip: s.ip,
      userAgent: s.userAgent,
      createdAt: s.createdAt,
      lastUsedAt: s.lastUsedAt,
      expiresAt: s.expiresAt,
      isCurrent: s.token === currentToken,
    }))),
  })
}

/**
 * DELETE /api/auth/sessions?id=xxx - revoke a specific session (or all if no id)
 */
export async function DELETE(req: Request) {
  const admin = await getAuthenticatedAdmin()
  if (!admin) return json({ error: 'احراز هویت نشده' }, { status: 401 })

  const url = new URL(req.url)
  const id = url.searchParams.get('id')
  const { cookies } = await import('next/headers')
  const cookieStore = await cookies()
  const currentToken = cookieStore.get('sp_session')?.value

  if (id) {
    const session = await db.session.findUnique({ where: { id } })
    if (!session || session.adminId !== admin.id) {
      return json({ error: 'نشست یافت نشد' }, { status: 404 })
    }
    if (session.token === currentToken) {
      return json({ error: 'نمی‌توان نشست فعلی را حذف کرد. از خروج استفاده کنید.' }, { status: 400 })
    }
    await db.session.update({ where: { id }, data: { revoked: true } })
    await auditLog({
      adminId: admin.id,
      action: 'SESSION_REVOKED',
      category: 'SECURITY',
      description: `نشست با آی‌پی ${session.ip} لغو شد`,
      request: req,
    })
  } else {
    // Revoke all other sessions
    await db.session.updateMany({
      where: { adminId: admin.id, revoked: false, token: { not: currentToken ?? '' } },
      data: { revoked: true },
    })
    await auditLog({
      adminId: admin.id,
      action: 'ALL_OTHER_SESSIONS_REVOKED',
      category: 'SECURITY',
      description: 'تمام نشست‌های دیگر لغو شدند',
      request: req,
    })
  }

  return json({ ok: true })
}
